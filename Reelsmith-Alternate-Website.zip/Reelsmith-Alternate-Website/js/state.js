// Core state, ids, history, events
export const uid = (p = 'id') => p + '_' + Math.random().toString(36).slice(2, 9);
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

const listeners = {};
export const on = (ev, fn) => ((listeners[ev] ||= []).push(fn));
export const emit = (ev, data) => (listeners[ev] || []).forEach((f) => f(data));

export const FORMATS = [
  { id: 'yt-video', platform: 'YouTube', name: 'Video', w: 1920, h: 1080, note: '16:9 · 1080p' },
  { id: 'yt-shorts', platform: 'YouTube', name: 'Shorts', w: 1080, h: 1920, note: '9:16 · vertical' },
  { id: 'yt-thumb', platform: 'YouTube', name: 'Thumbnail', w: 1280, h: 720, note: '1280×720' },
  { id: 'yt-banner', platform: 'YouTube', name: 'Channel art', w: 2560, h: 1440, note: '2560×1440' },
  { id: 'ig-reel', platform: 'Instagram', name: 'Reel', w: 1080, h: 1920, note: '9:16 · vertical' },
  { id: 'ig-post', platform: 'Instagram', name: 'Square post', w: 1080, h: 1080, note: '1:1' },
  { id: 'ig-portrait', platform: 'Instagram', name: 'Portrait post', w: 1080, h: 1350, note: '4:5' },
  { id: 'ig-story', platform: 'Instagram', name: 'Story', w: 1080, h: 1920, note: '9:16' },
  { id: 'fb-feed', platform: 'Facebook', name: 'Feed video', w: 1080, h: 1080, note: '1:1' },
  { id: 'fb-portrait', platform: 'Facebook', name: 'Feed portrait', w: 1080, h: 1350, note: '4:5' },
  { id: 'fb-story', platform: 'Facebook', name: 'Story / Reel', w: 1080, h: 1920, note: '9:16' },
  { id: 'fb-cover', platform: 'Facebook', name: 'Cover photo', w: 1640, h: 624, note: '851×315 @2x' },
  { id: 'fb-landscape', platform: 'Facebook', name: 'Landscape', w: 1920, h: 1080, note: '16:9' },
];

export const defaultClip = (o) => ({
  id: uid('clip'),
  trackId: null,
  kind: 'image',
  mediaId: null,
  start: 0,
  dur: 5,
  in: 0,
  speed: 1,
  x: 0, y: 0, w: 100, h: 100,
  scale: 1, rotation: 0, opacity: 1, flipH: false,
  fit: 'cover', radius: 0,
  volume: 1, fadeIn: 0, fadeOut: 0,
  filter: 'none',
  adj: { brightness: 0, contrast: 0, saturation: 0, hue: 0, temp: 0, vignette: 0, blur: 0 },
  animIn: { type: 'none', dur: 0.5 },
  animOut: { type: 'none', dur: 0.5 },
  combo: 'none',
  blend: 'source-over',
  ...o,
});

export const textDefaults = {
  text: 'Your text', font: 'Anton', size: 120, color: '#ffffff', weight: 400, italic: false,
  align: 'center', upper: false, spacing: 0, lineHeight: 1.1,
  stroke: 0, strokeColor: '#000000', bg: '', bgPad: 24, bgRadius: 12,
  shadow: false, shadowColor: 'rgba(0,0,0,0.6)',
};

export const store = {
  project: null,
  selectedId: null,
  history: [],
  future: [],
};

export function newProject(fmt, name) {
  const t = (type, name) => ({ id: uid('trk'), type, name, muted: false, hidden: false, locked: false });
  return {
    id: uid('prj'),
    name: name || 'Untitled ' + fmt.platform + ' ' + fmt.name,
    formatId: fmt.id,
    w: fmt.w, h: fmt.h, fps: 30,
    bg: '#000000',
    tracks: [t('text', 'T1'), t('video', 'V2'), t('video', 'V1'), t('audio', 'A1'), t('audio', 'A2')],
    clips: [],
  };
}

export const project = () => store.project;
export const getClip = (id) => store.project?.clips.find((c) => c.id === id);
export const getTrack = (id) => store.project?.tracks.find((t) => t.id === id);
export const selected = () => getClip(store.selectedId);
export const duration = () => {
  const p = store.project;
  if (!p || !p.clips.length) return 5;
  return Math.max(1, ...p.clips.map((c) => c.start + c.dur));
};

export function select(id) {
  store.selectedId = id;
  emit('select', id);
}

const snap = () => JSON.stringify(store.project);
export function commit() {
  store.history.push(snap());
  if (store.history.length > 80) store.history.shift();
  store.future = [];
}
// Call before a mutation to record the previous state
export function checkpoint() { commit(); }
export function undo() {
  if (!store.history.length) return;
  store.future.push(snap());
  store.project = JSON.parse(store.history.pop());
  if (!getClip(store.selectedId)) store.selectedId = null;
  emit('project', { reason: 'undo' });
}
export function redo() {
  if (!store.future.length) return;
  store.history.push(snap());
  store.project = JSON.parse(store.future.pop());
  emit('project', { reason: 'redo' });
}

export const fmtTime = (s, frames = true) => {
  s = Math.max(0, s);
  const m = Math.floor(s / 60), sec = Math.floor(s % 60), f = Math.floor((s % 1) * 30);
  return String(m).padStart(2, '0') + ':' + String(sec).padStart(2, '0') + (frames ? ':' + String(f).padStart(2, '0') : '');
};

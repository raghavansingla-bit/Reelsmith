# Prompt to use with Claude

I uploaded a ZIP containing my alternate Reelsmith website. Please inspect the whole project and help me run and test it. It is a static site using `index.html`, `styles.css`, JavaScript ES modules under `js/`, and local assets under `assets/` and `vendor/`.

Requirements:
1. Preserve the existing design and all tools: video editor, templates, thumbnail maker, photo editor, collage maker, and project save/open.
2. Run it using a local HTTP server (not by opening `index.html` as a file).
3. Check browser console errors and test navigation, file import, timeline playback, export, save project, and open project.
4. Fix confirmed bugs without removing features.
5. Help deploy it to a static host. Do not claim it is deployed until the host provides a live URL.
6. Explain any step where I must sign in or authorize deployment.

// Media library: samples, imports, generated stock music
import { uid, emit } from './state.js';

export const library = []; // {id,type,name,url,el,w,h,duration,thumb,peaks,sample}
export const getMedia = (id) => library.find((m) => m.id === id);

const SAMPLES = [
  ['travel', 'Mountain ridge'], ['beach', 'Ocean aerial'], ['concert', 'Concert crowd'],
  ['food', 'Street food night'], ['creator', 'Creator on the go'], ['fitness', 'Trainer portrait'],
  ['product', 'Sneaker drop'], ['coffee', 'Coffee flat lay'],
];

function loadImage(url) {
  return new Promise((res, rej) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => res(img);
    img.onerror = rej;
    img.src = url;
  });
}

export async function loadSamples() {
  await Promise.all(
    SAMPLES.map(async ([key, name]) => {
      const url = `./assets/${key}.jpg`;
      const el = await loadImage(url);
      library.push({ id: 'sample_' + key, key, type: 'image', name, url, el, w: el.naturalWidth, h: el.naturalHeight, thumb: url, sample: true });
    })
  );
  // keep sample order stable
  library.sort((a, b) => SAMPLES.findIndex((s) => 'sample_' + s[0] === a.id) - SAMPLES.findIndex((s) => 'sample_' + s[0] === b.id));
  await genMusic();
  emit('library');
}

export const sampleId = (key) => 'sample_' + key;

// ---------- Generated royalty-free music (synthesised in-browser) ----------
function wavFromBuffer(buf) {
  const ch = buf.numberOfChannels, len = buf.length, rate = buf.sampleRate;
  const out = new DataView(new ArrayBuffer(44 + len * ch * 2));
  const w = (o, s) => [...s].forEach((c, i) => out.setUint8(o + i, c.charCodeAt(0)));
  w(0, 'RIFF'); out.setUint32(4, 36 + len * ch * 2, true); w(8, 'WAVE'); w(12, 'fmt ');
  out.setUint32(16, 16, true); out.setUint16(20, 1, true); out.setUint16(22, ch, true);
  out.setUint32(24, rate, true); out.setUint32(28, rate * ch * 2, true); out.setUint16(32, ch * 2, true);
  out.setUint16(34, 16, true); w(36, 'data'); out.setUint32(40, len * ch * 2, true);
  const data = [...Array(ch)].map((_, i) => buf.getChannelData(i));
  let o = 44;
  for (let i = 0; i < len; i++) for (let c = 0; c < ch; c++) { out.setInt16(o, Math.max(-1, Math.min(1, data[c][i])) * 0x7fff, true); o += 2; }
  return new Blob([out], { type: 'audio/wav' });
}

function peaksOf(buf, n = 400) {
  const d = buf.getChannelData(0), step = Math.floor(d.length / n), p = [];
  for (let i = 0; i < n; i++) { let m = 0; for (let j = 0; j < step; j += 16) m = Math.max(m, Math.abs(d[i * step + j] || 0)); p.push(m); }
  return p;
}

async function renderTrack({ bpm, bars, chords, style }) {
  const rate = 22050, beat = 60 / bpm, len = bars * 4 * beat;
  const ctx = new OfflineAudioContext(2, Math.ceil(len * rate), rate);
  const master = ctx.createGain(); master.gain.value = 0.5; master.connect(ctx.destination);
  const note = (f, t, d, type, g, dest = master) => {
    const o = ctx.createOscillator(), gn = ctx.createGain();
    o.type = type; o.frequency.value = f;
    gn.gain.setValueAtTime(0, t); gn.gain.linearRampToValueAtTime(g, t + 0.01); gn.gain.exponentialRampToValueAtTime(0.0008, t + d);
    o.connect(gn).connect(dest); o.start(t); o.stop(t + d + 0.05);
  };
  const noise = ctx.createBuffer(1, rate * 0.3, rate); const nd = noise.getChannelData(0);
  for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
  const hat = (t, g) => { const s = ctx.createBufferSource(); s.buffer = noise; const f = ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 7000; const gn = ctx.createGain(); gn.gain.setValueAtTime(g, t); gn.gain.exponentialRampToValueAtTime(0.001, t + 0.06); s.connect(f).connect(gn).connect(master); s.start(t); s.stop(t + 0.1); };
  const kick = (t) => { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(40, t + 0.15); g.gain.setValueAtTime(0.9, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.3); o.connect(g).connect(master); o.start(t); o.stop(t + 0.35); };
  const snare = (t) => { const s = ctx.createBufferSource(); s.buffer = noise; const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 1800; const g = ctx.createGain(); g.gain.setValueAtTime(0.5, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.18); s.connect(f).connect(g).connect(master); s.start(t); s.stop(t + 0.2); };
  const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = style === 'lofi' ? 1400 : 3200; lp.connect(master);
  for (let bar = 0; bar < bars; bar++) {
    const ch = chords[bar % chords.length], t0 = bar * 4 * beat;
    ch.forEach((f) => note(f, t0, 4 * beat, style === 'lofi' ? 'triangle' : 'sawtooth', style === 'lofi' ? 0.07 : 0.035, lp));
    for (let b = 0; b < 4; b++) {
      const t = t0 + b * beat;
      if (style === 'lofi') { if (b === 0 || b === 2.5) kick(t); if (b === 1 || b === 3) snare(t); hat(t + beat / 2, 0.08); }
      else { kick(t); if (b % 2 === 1) snare(t); hat(t + beat / 2, 0.12); hat(t + beat / 4 * 3, 0.05); note(ch[0] / 2, t, beat * 0.9, 'square', 0.06, lp); }
      if (style !== 'lofi') note(ch[(b + bar) % 3] * 2, t + beat / 2, beat / 2, 'triangle', 0.05);
    }
  }
  return ctx.startRendering();
}

async function genMusic() {
  const C = (n) => 440 * Math.pow(2, (n - 69) / 12);
  const tracks = [
    { name: 'Lo-fi Sunset', bpm: 82, bars: 12, style: 'lofi', chords: [[C(57), C(60), C(64)], [C(53), C(57), C(60)], [C(55), C(59), C(62)], [C(52), C(55), C(59)]] },
    { name: 'Upbeat Drive', bpm: 118, bars: 16, style: 'pop', chords: [[C(60), C(64), C(67)], [C(55), C(59), C(62)], [C(57), C(60), C(64)], [C(53), C(57), C(60)]] },
  ];
  for (const t of tracks) {
    try {
      const buf = await renderTrack(t);
      const url = URL.createObjectURL(wavFromBuffer(buf));
      library.push({ id: 'music_' + t.style, type: 'audio', name: t.name, url, duration: buf.duration, peaks: peaksOf(buf), sample: true, note: t.bpm + ' BPM · generated' });
    } catch (e) { console.warn('music gen failed', e); }
  }
}

// ---------- Imports ----------
export async function importFiles(files) {
  const added = [];
  for (const f of files) {
    const url = URL.createObjectURL(f);
    const id = uid('med');
    try {
      if (f.type.startsWith('image/')) {
        const el = await loadImage(url);
        added.push({ id, type: 'image', name: f.name, url, el, w: el.naturalWidth, h: el.naturalHeight, thumb: url });
      } else if (f.type.startsWith('video/')) {
        const el = document.createElement('video');
        el.src = url; el.muted = true; el.playsInline = true; el.preload = 'auto'; el.crossOrigin = 'anonymous';
        await new Promise((r, j) => { el.onloadeddata = r; el.onerror = j; });
        const thumb = await videoThumb(el);
        added.push({ id, type: 'video', name: f.name, url, el, w: el.videoWidth, h: el.videoHeight, duration: el.duration, thumb });
      } else if (f.type.startsWith('audio/')) {
        const ab = await f.arrayBuffer();
        let peaks = null, duration = 0;
        try { const ac = new OfflineAudioContext(1, 1, 22050); const buf = await ac.decodeAudioData(ab); peaks = peaksOf(buf); duration = buf.duration; } catch (e) {}
        if (!duration) { const a = new Audio(url); await new Promise((r) => (a.onloadedmetadata = r)); duration = a.duration; }
        added.push({ id, type: 'audio', name: f.name, url, duration, peaks });
      }
    } catch (e) { console.warn('import failed', f.name, e); }
  }
  library.push(...added);
  emit('library');
  return added;
}

async function videoThumb(v) {
  try {
    v.currentTime = Math.min(1, v.duration / 3);
    await new Promise((r) => (v.onseeked = r));
    const c = document.createElement('canvas'); c.width = 240; c.height = Math.round(240 * v.videoHeight / v.videoWidth) || 135;
    c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
    v.currentTime = 0;
    return c.toDataURL('image/jpeg', 0.7);
  } catch (e) { return ''; }
}

export async function addDataImage(dataUrl, name) {
  const el = await loadImage(dataUrl);
  const m = { id: uid('med'), type: 'image', name, url: dataUrl, el, w: el.naturalWidth, h: el.naturalHeight, thumb: dataUrl };
  library.push(m); emit('library');
  return m;
}

# Reelsmith — Alternate Website

A standalone, static browser-based creative studio based on the supplied Reelsmith project. It includes the video editor, templates, thumbnail maker, photo editor, collage maker, timeline, and editable project save/open controls.

## Run locally

This site uses JavaScript ES modules, so open it through a local HTTP server instead of opening `index.html` directly.

### Python

```bash
python -m http.server 8000
```

Then visit http://localhost:8000.

### Node.js

```bash
npx serve .
```

## Deploy to a static host

No build step is required. Upload the folder as-is to a static hosting provider such as Netlify, Vercel, or GitHub Pages. Keep `index.html`, `styles.css`, `js/`, `assets/`, and `vendor/` together and preserve their relative paths.

### Netlify

A `netlify.toml` is included. Drag the extracted folder into Netlify Drop, or connect its Git repository. No build command is needed; publish directory is `.`.

### Vercel

A `vercel.json` is included. Import the folder/repository as a static site with no build command and output directory `.`.

## Using with Claude

Claude itself is an AI assistant, not a general-purpose public web host. To use Claude to help deploy this site, upload this ZIP to Claude and ask it to inspect the code, fix any issues, and guide you through deploying it with Claude Code or a static host. Publishing requires you to sign in to the hosting provider and authorize deployment; this package has not been deployed by this script.

Suggested prompt:

> Inspect this Reelsmith alternate website ZIP. Preserve its existing functionality and design. Run it locally, test the main navigation and editing controls, fix any errors you find, and help me deploy it as a static website. Keep all relative asset paths intact. Do not claim it is live until a deployment URL is actually returned by the hosting provider.

## Notes

- Media processing is browser-side; performance depends on the device and file sizes.
- Browser capabilities and codecs affect export formats.
- The save-project feature embeds imported media in a JSON project file, so large projects can create large downloads.
- No backend, user accounts, or cloud project sync is included in this static package.

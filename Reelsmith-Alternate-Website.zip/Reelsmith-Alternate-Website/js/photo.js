// Photo editor: adjust, filters, rotate/flip, draw, crop, and send to collage / thumbnail / video
import { FORMATS, newProject, defaultClip, clamp } from './state.js';
import { library, getMedia, importFiles, addDataImage } from './media.js';
import { FILTERS, effectiveAdj } from './render.js';
import { icon, icons, esc, toast, download } from './ui.js';

const $ = (s, r = document) => r.querySelector(s);
const MAX = 2400; // longest side kept in memory so editing stays fast

const defAdj = () => ({ brightness: 0, contrast: 0, saturation: 0, hue: 0, temp: 0, blur: 0 });
const P = { img: null, base: null, name: 'photo', rot: 0, fh: 0, fv: 0, filter: 'none', adj: defAdj(), strokes: [], mode: '', crop: null, hist: [], fut: [] };
const SLIDERS = [['brightness', 'Brightness', -100, 100], ['contrast', 'Contrast', -100, 100], ['saturation', 'Saturation', -100, 100], ['temp', 'Warmth', -100, 100], ['hue', 'Hue', -180, 180], ['blur', 'Blur', 0, 10]];

function filterStr() {
  const a = effectiveAdj({ filter: P.filter, adj: P.adj }), p = [];
  if (a.brightness) p.push(`brightness(${1 + a.brightness / 100})`);
  if (a.contrast) p.push(`contrast(${1 + a.contrast / 100})`);
  if (a.saturation) p.push(`saturate(${Math.max(0, 1 + a.saturation / 100)})`);
  if (a.hue) p.push(`hue-rotate(${a.hue}deg)`);
  if (a.sepia) p.push(`sepia(${a.sepia / 100})`);
  if (a.temp > 0) p.push(`sepia(${a.temp / 160})`);
  if (a.temp < 0) p.push(`hue-rotate(${a.temp / 4}deg)`);
  if (a.blur) p.push(`blur(${a.blur}px)`);
  return p.join(' ') || 'none';
}

const cv = () => $('#ph-canvas');
function render(overlay = true) {
  const c = cv(); if (!c) return;
  const ctx = c.getContext('2d');
  if (!P.img) { c.width = 960; c.height = 540; ctx.fillStyle = '#18181d'; ctx.fillRect(0, 0, 960, 540); ctx.fillStyle = '#6a6a76'; ctx.font = '600 26px Inter, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('Open a photo to start editing', 480, 270); fit(); return; }
  const w = P.img.width, h = P.img.height, sw = P.rot % 180 !== 0, cw = sw ? h : w, ch = sw ? w : h;
  if (c.width !== cw || c.height !== ch) { c.width = cw; c.height = ch; fit(); }
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.filter = 'none'; ctx.clearRect(0, 0, cw, ch);
  ctx.save(); ctx.translate(cw / 2, ch / 2); ctx.rotate((P.rot * Math.PI) / 180); ctx.scale(P.fh ? -1 : 1, P.fv ? -1 : 1);
  ctx.filter = filterStr(); ctx.drawImage(P.img, -w / 2, -h / 2); ctx.filter = 'none';
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  P.strokes.forEach((q) => {
    if (!q.p.length) return;
    ctx.strokeStyle = ctx.fillStyle = q.c; ctx.lineWidth = q.s; ctx.beginPath();
    if (q.p.length === 1) { ctx.arc(q.p[0][0], q.p[0][1], q.s / 2, 0, 7); ctx.fill(); return; }
    ctx.moveTo(q.p[0][0], q.p[0][1]); q.p.slice(1).forEach((pt) => ctx.lineTo(pt[0], pt[1])); ctx.stroke();
  });
  ctx.restore();
  if (overlay && P.mode === 'crop' && P.crop) {
    const r = P.crop; ctx.save(); ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.beginPath(); ctx.rect(0, 0, cw, ch); ctx.rect(r.x, r.y, r.w, r.h); ctx.fill('evenodd');
    ctx.setLineDash([12, 8]); ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(2, cw / 400); ctx.strokeRect(r.x, r.y, r.w, r.h); ctx.restore();
  }
}
function fit() {
  const c = cv(), st = $('#ph-stage'); if (!c || !st.clientWidth) return;
  const k = Math.min((st.clientWidth - 32) / c.width, (st.clientHeight - 32) / c.height, 1.5);
  c.style.width = Math.round(c.width * Math.max(0.05, k)) + 'px'; c.style.height = Math.round(c.height * Math.max(0.05, k)) + 'px';
}

const snap = () => ({ img: P.img, rot: P.rot, fh: P.fh, fv: P.fv, filter: P.filter, adj: { ...P.adj }, strokes: P.strokes.map((q) => ({ ...q, p: q.p.slice() })) });
function push() { P.hist.push(snap()); if (P.hist.length > 40) P.hist.shift(); P.fut = []; }
function restore(s) { Object.assign(P, s, { crop: null }); panels(); render(); }
function undo() { const s = P.hist.pop(); if (!s) return toast('Nothing to undo'); P.fut.push(snap()); restore(s); }
function redo() { const s = P.fut.pop(); if (!s) return; P.hist.push(snap()); restore(s); }
const need = () => (P.img ? true : (toast('Open a photo first'), false));

function setBase(el, name) {
  const k = Math.min(1, MAX / Math.max(el.naturalWidth || el.width, el.naturalHeight || el.height));
  const t = document.createElement('canvas'); t.width = Math.round((el.naturalWidth || el.width) * k); t.height = Math.round((el.naturalHeight || el.height) * k);
  t.getContext('2d').drawImage(el, 0, 0, t.width, t.height);
  P.base = t; P.name = (name || 'photo').replace(/\.[^.]+$/, ''); P.hist = []; P.fut = []; reset(false);
}
function reset(record = true) {
  if (record && P.img) push();
  Object.assign(P, { img: P.base, rot: 0, fh: 0, fv: 0, filter: 'none', adj: defAdj(), strokes: [], mode: '', crop: null });
  panels(); render();
}
function openMedia(id) { const m = getMedia(id); if (m?.el && m.type === 'image') { setBase(m.el, m.name); toast('Photo opened'); } }

const rng = (label, k, v, min, max) => `<label class="field"><span>${label}</span><div class="range"><input type="range" data-pk="${k}" min="${min}" max="${max}" step="1" value="${v}"><input type="number" data-pk="${k}" min="${min}" max="${max}" step="1" value="${v}"></div></label>`;
function leftHTML() {
  const imgs = library.filter((m) => m.type === 'image');
  return `<div class="panel-head"><h3>Photos</h3><label class="btn btn-primary btn-sm">${icon('upload')}<span>Open</span><input type="file" id="ph-file" accept="image/*"></label></div>
  <p class="hint">Pick a photo from your library or open one from your device. You can also drop a photo onto the canvas.</p>
  <div class="media-grid">${imgs.map((m) => `<div class="media-card" data-pmedia="${m.id}"><img src="${m.thumb}" alt="${esc(m.name)}" crossorigin="anonymous"><span class="name">${esc(m.name)}</span></div>`).join('')}</div>
  <h4 class="sub">Filters</h4>
  <div class="chips">${Object.entries(FILTERS).map(([k, f]) => `<button class="chip ${P.filter === k ? 'on' : ''}" data-pfilter="${k}">${f.label}</button>`).join('')}</div>`;
}
function rightHTML() {
  return `<div class="insp-head"><h3>Photo</h3><div class="insp-actions"><button class="icon-btn" id="ph-undo2" title="Undo">${icon('undo-2')}</button><button class="icon-btn" id="ph-reset" title="Reset all">${icon('rotate-ccw')}</button></div></div><div class="insp-body">
  <h4 class="sub">Adjust</h4>${SLIDERS.map(([k, l, a, b]) => rng(l, k, P.adj[k], a, b)).join('')}
  <h4 class="sub">Transform</h4><div class="btn-row"><button class="btn btn-sm" data-pa="rl">${icon('rotate-ccw')}<span>Left</span></button><button class="btn btn-sm" data-pa="rr">${icon('rotate-cw')}<span>Right</span></button><button class="btn btn-sm" data-pa="fh">${icon('flip-horizontal-2')}<span>Flip H</span></button><button class="btn btn-sm" data-pa="fv">${icon('flip-vertical-2')}<span>Flip V</span></button></div>
  <h4 class="sub">Draw</h4>
  <div class="btn-row"><button class="btn btn-sm ${P.mode === 'draw' ? 'btn-primary' : ''}" data-pa="draw">${icon('pencil')}<span>${P.mode === 'draw' ? 'Drawing' : 'Draw'}</span></button><button class="btn btn-sm" data-pa="cleardraw">Clear drawing</button></div>
  <div class="grid2"><label class="field"><span>Brush size</span><input type="range" id="ph-size" min="1" max="50" value="${P.size || 8}"></label><label class="field field-inline"><span>Color</span><input type="color" id="ph-color" value="${P.color || '#ff2d55'}"></label></div>
  <h4 class="sub">Crop</h4>
  <div class="btn-row"><button class="btn btn-sm ${P.mode === 'crop' ? 'btn-primary' : ''}" data-pa="crop">${icon('crop')}<span>${P.mode === 'crop' ? 'Cropping' : 'Crop'}</span></button><button class="btn btn-sm" data-pa="applycrop">Apply crop</button></div>
  <p class="hint">Choose Crop, drag a box on the photo, then press Apply crop.</p>
  <h4 class="sub">Use this photo in</h4>
  <div class="btn-row"><button class="btn btn-sm" data-send="collage">Collage</button><button class="btn btn-sm" data-send="thumb-bg">Thumbnail background</button><button class="btn btn-sm" data-send="thumb-cut">Thumbnail cutout</button><button class="btn btn-sm" data-send="video">Video</button></div>
  </div>`;
}
function panels() { $('#ph-left').innerHTML = leftHTML(); $('#ph-right').innerHTML = rightHTML(); icons(); }

function bake(overlay = false) { render(overlay); return cv(); }
async function toMedia(name) {
  if (!need()) return null;
  const c = bake(); const m = await addDataImage(c.toDataURL('image/png'), name); render(); return m;
}
function applyCrop() {
  const r = P.crop; if (!need()) return;
  if (!r || r.w < 10 || r.h < 10) return toast('Choose Crop, then drag a box on the photo');
  push(); const c = bake(), t = document.createElement('canvas'); t.width = Math.round(r.w); t.height = Math.round(r.h);
  t.getContext('2d').drawImage(c, r.x, r.y, r.w, r.h, 0, 0, t.width, t.height);
  Object.assign(P, { img: t, rot: 0, fh: 0, fv: 0, filter: 'none', adj: defAdj(), strokes: [], crop: null, mode: '' }); panels(); render(); toast('Cropped');
}

const toSrc = (x, y) => { // canvas point -> source-image space so strokes follow rotate/flip
  const c = cv(), a = (-P.rot * Math.PI) / 180, dx = x - c.width / 2, dy = y - c.height / 2, co = Math.cos(a), si = Math.sin(a), u = dx * co - dy * si, v = dx * si + dy * co;
  return [P.fh ? -u : u, P.fv ? -v : v];
};

export function openPhoto(opts = {}) {
  document.querySelectorAll('.view').forEach((v) => (v.hidden = v.id !== 'view-photo'));
  if (opts.mediaId) openMedia(opts.mediaId); else { panels(); render(); }
  requestAnimationFrame(() => { fit(); render(); });
}

export function initPhoto() {
  const left = $('#ph-left'), right = $('#ph-right'), stage = $('#ph-stage'), c = cv();
  new ResizeObserver(() => { fit(); }).observe(stage);
  left.addEventListener('click', (e) => { const m = e.target.closest('[data-pmedia]'); if (m) openMedia(m.dataset.pmedia); const f = e.target.closest('[data-pfilter]'); if (f && need()) { push(); P.filter = f.dataset.pfilter; panels(); render(); } });
  left.addEventListener('change', async (e) => { if (e.target.id !== 'ph-file') return; const a = await importFiles([...e.target.files].filter((f) => f.type.startsWith('image/'))); if (a[0]) { setBase(a[0].el, a[0].name); toast('Photo opened'); } e.target.value = ''; });
  stage.addEventListener('dragover', (e) => e.preventDefault());
  stage.addEventListener('drop', async (e) => { e.preventDefault(); const a = await importFiles([...e.dataTransfer.files].filter((f) => f.type.startsWith('image/'))); if (a[0]) { setBase(a[0].el, a[0].name); panels(); } });
  right.addEventListener('pointerdown', (e) => { if (e.target.matches('input[type=range][data-pk]') && P.img) push(); });
  right.addEventListener('input', (e) => {
    const t = e.target, k = t.dataset.pk;
    if (k) { const v = parseFloat(t.value); if (isNaN(v)) return; P.adj[k] = v; right.querySelectorAll(`[data-pk="${k}"]`).forEach((o) => o !== t && (o.value = v)); render(); }
    if (t.id === 'ph-size') P.size = +t.value; if (t.id === 'ph-color') P.color = t.value;
  });
  right.addEventListener('click', async (e) => {
    const a = e.target.closest('[data-pa]')?.dataset.pa, s = e.target.closest('[data-send]')?.dataset.send;
    if (e.target.closest('#ph-undo2')) return undo();
    if (e.target.closest('#ph-reset')) { if (need()) reset(true); return; }
    if (a) {
      if (!need()) return;
      if (a === 'applycrop') return applyCrop();
      if (a === 'draw' || a === 'crop') { P.mode = P.mode === a ? '' : a; P.crop = null; panels(); render(); c.style.cursor = P.mode ? 'crosshair' : 'default'; return; }
      push();
      if (a === 'rl') P.rot = (P.rot + 270) % 360; if (a === 'rr') P.rot = (P.rot + 90) % 360; if (a === 'fh') P.fh ^= 1; if (a === 'fv') P.fv ^= 1; if (a === 'cleardraw') P.strokes = [];
      P.crop = null; render(); return;
    }
    if (s) {
      const m = await toMedia('Edited ' + P.name); if (!m) return;
      if (s === 'collage') { const { placeInCollage } = await import('./collage.js'); placeInCollage(m.id); toast('Added to the collage'); }
      if (s === 'thumb-bg' || s === 'thumb-cut') { const { openThumbnail } = await import('./thumbnail.js'); openThumbnail(s === 'thumb-bg' ? { bg: m.id } : { cut: m.id }); toast('Added to the thumbnail'); }
      if (s === 'video') {
        const F = FORMATS[0], pr = newProject(F, 'Photo video'), v1 = pr.tracks.find((t) => t.name === 'V1');
        pr.clips.push(defaultClip({ trackId: v1.id, kind: 'image', mediaId: m.id, x: F.w / 2, y: F.h / 2, w: F.w, h: F.h, dur: 5, fit: 'contain', combo: 'ken-burns' }));
        const { openProject } = await import('./editor.js'); openProject(pr); toast('Photo added to a new video project');
      }
    }
  });
  // drawing and cropping with pointer events (mouse, touch and pen)
  let d = null;
  const pt = (e) => { const r = c.getBoundingClientRect(); return [(e.clientX - r.left) * c.width / r.width, (e.clientY - r.top) * c.height / r.height]; };
  c.addEventListener('pointerdown', (e) => {
    if (!P.img || !P.mode) return; const [x, y] = pt(e); c.setPointerCapture(e.pointerId);
    if (P.mode === 'draw') { push(); const q = { c: P.color || '#ff2d55', s: (P.size || 8) * Math.max(P.img.width, P.img.height) / 1000, p: [toSrc(x, y)] }; P.strokes.push(q); d = q; }
    else { d = { x0: x, y0: y }; P.crop = { x, y, w: 0, h: 0 }; }
    render();
  });
  c.addEventListener('pointermove', (e) => {
    if (!d) return; const [x, y] = pt(e);
    if (P.mode === 'draw') d.p.push(toSrc(x, y));
    else { const X = clamp(x, 0, c.width), Y = clamp(y, 0, c.height); P.crop = { x: Math.min(d.x0, X), y: Math.min(d.y0, Y), w: Math.abs(X - d.x0), h: Math.abs(Y - d.y0) }; }
    render();
  });
  const end = () => (d = null); c.addEventListener('pointerup', end); c.addEventListener('pointercancel', end);
  $('#ph-undo').onclick = undo; $('#ph-redo').onclick = redo;
  document.addEventListener('keydown', (e) => {
    if ($('#view-photo').hidden || /INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); }
  });
  $('#ph-export').onclick = () => { if (!need()) return; bake().toBlob((b) => { download(b, `${P.name}-edited.png`); toast('Photo exported as PNG'); render(); }, 'image/png'); };
  $('#ph-export-jpg').onclick = () => { if (!need()) return; bake().toBlob((b) => { download(b, `${P.name}-edited.jpg`); toast('Photo exported as JPG'); render(); }, 'image/jpeg', 0.92); };
  panels(); render();
}

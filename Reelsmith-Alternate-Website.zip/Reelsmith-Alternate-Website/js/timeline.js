// Multi-track timeline
import { store, project, getClip, getTrack, select, duration, commit, emit, clamp, fmtTime } from './state.js';
import { getMedia } from './media.js';
import { FX_TYPES } from './render.js';
import { icon, icons, esc, toast } from './ui.js';

let api, pps = 60, snapOn = true;
const HEAD = 136;
const $ = (s, r = document) => r.querySelector(s);

export function init(a) {
  api = a;
  const root = $('#timeline');
  root.innerHTML = `
    <div class="tl-toolbar">
      <div class="tl-group">
        <button class="tool" id="tl-blade" title="Cut tool — click any clip to cut it there (B)">${icon('slice')}<span>Cut</span></button>
        <button class="tool" id="tl-split" title="Split selected clip at playhead (S)">${icon('scissors')}<span>Split</span></button>
        <button class="tool" id="tl-splitall" title="Split every track at playhead (Shift+S)">${icon('scissors-line-dashed')}<span>Split all</span></button>
        <button class="tool" id="tl-trimL" title="Delete left of playhead (Q)">${icon('arrow-left-to-line')}</button>
        <button class="tool" id="tl-trimR" title="Delete right of playhead (W)">${icon('arrow-right-to-line')}</button>
        <button class="tool" id="tl-dup" title="Duplicate (Ctrl+D)">${icon('copy')}</button>
        <button class="tool" id="tl-del" title="Delete (Del)">${icon('trash-2')}</button>
        <button class="tool" id="tl-ripple" title="Ripple delete (Shift+Del)">${icon('between-horizontal-start')}<span>Ripple</span></button>
        <button class="tool" id="tl-freeze" title="Freeze frame at playhead (F)">${icon('snowflake')}<span>Freeze</span></button>
        <button class="tool" id="tl-kf" title="Add keyframe at playhead (K)">${icon('diamond')}<span>Keyframe</span></button>
        <span class="sep"></span>
        <button class="tool on" id="tl-snap" title="Snapping">${icon('magnet')}<span>Snap</span></button>
      </div>
      <div class="tl-group">
        <button class="tool" data-addtrack="video" title="Add video track">${icon('plus')}<span>Video</span></button>
        <button class="tool" data-addtrack="text" title="Add text/overlay track">${icon('plus')}<span>Text</span></button>
        <button class="tool" data-addtrack="audio" title="Add audio track">${icon('plus')}<span>Audio</span></button>
        <span class="sep"></span>
        <button class="tool" id="tl-zout" title="Zoom out (−)">${icon('zoom-out')}</button>
        <input type="range" id="tl-zoom" min="8" max="400" value="${pps}" aria-label="Timeline zoom">
        <button class="tool" id="tl-zin" title="Zoom in (+)">${icon('zoom-in')}</button>
        <button class="tool" id="tl-fit" title="Fit timeline">${icon('maximize-2')}<span>Fit</span></button>
      </div>
    </div>
    <div class="tl-scroll" id="tl-scroll"><div class="tl-content" id="tl-content"></div></div>`;
  icons();
  $('#tl-blade').onclick = () => setBlade(!blade);
  $('#tl-splitall').onclick = () => import('./editor.js').then((e) => e.splitAll());
  $('#tl-trimL').onclick = () => import('./editor.js').then((e) => e.trimToPlayhead('left'));
  $('#tl-trimR').onclick = () => import('./editor.js').then((e) => e.trimToPlayhead('right'));
  $('#tl-split').onclick = () => import('./editor.js').then((e) => e.splitAt());
  $('#tl-dup').onclick = () => import('./editor.js').then((e) => e.duplicateSelected());
  $('#tl-del').onclick = () => import('./editor.js').then((e) => e.deleteSelected());
  $('#tl-ripple').onclick = () => import('./editor.js').then((e) => e.deleteSelected(true));
  $('#tl-freeze').onclick = () => import('./editor.js').then((e) => e.freezeFrame());
  $('#tl-kf').onclick = () => import('./editor.js').then((e) => e.addKeyframe());
  $('#tl-snap').onclick = (e) => { snapOn = !snapOn; e.currentTarget.classList.toggle('on', snapOn); };
  root.querySelectorAll('[data-addtrack]').forEach((b) => (b.onclick = () => { commit(); api.addTrack(b.dataset.addtrack); emit('project', {}); }));
  $('#tl-zoom').oninput = (e) => { pps = +e.target.value; render(); };
  $('#tl-zin').onclick = () => zoom(1.25);
  $('#tl-zout').onclick = () => zoom(0.8);
  $('#tl-fit').onclick = fit;
  const sc = $('#tl-scroll');
  sc.addEventListener('wheel', (e) => { if (e.ctrlKey || e.metaKey) { e.preventDefault(); zoom(e.deltaY < 0 ? 1.12 : 0.89); } }, { passive: false });
  setupPointer(sc);
  setupDrop(sc);
}

export function zoom(f) { pps = clamp(pps * f, 8, 400); $('#tl-zoom').value = pps; render(); }
let blade = false;
export function setBlade(v) {
  blade = v;
  $('#tl-blade')?.classList.toggle('on', blade);
  $('#tl-scroll')?.classList.toggle('blade', blade);
  if (blade) toast('Cut tool on — click a clip to cut it. Press B or Esc to turn off');
}
export const isBlade = () => blade;
export function fit() { const sc = $('#tl-scroll'); pps = clamp((sc.clientWidth - HEAD - 40) / duration(), 8, 400); $('#tl-zoom').value = pps; render(); }

function tickStep() {
  for (const s of [0.5, 1, 2, 5, 10, 15, 30, 60, 120]) if (s * pps >= 80) return s;
  return 300;
}

function clipInner(c) {
  const m = getMedia(c.mediaId);
  if (c.kind === 'audio') {
    const peaks = m?.peaks || [];
    const md = m?.duration || c.dur;
    const w = c.dur * pps;
    const bars = Math.max(1, Math.floor(w / 3));
    let svg = '';
    for (let i = 0; i < bars; i++) {
      const tt = c.in + (i / bars) * c.dur * c.speed;
      const p = peaks.length ? peaks[Math.min(peaks.length - 1, Math.floor((tt / md) * peaks.length))] || 0 : 0.3;
      const h = Math.max(1, p * 30);
      svg += `<rect x="${i * 3}" y="${18 - h / 2}" width="2" height="${h}"/>`;
    }
    return `<svg class="wave" width="${w}" height="36" viewBox="0 0 ${w} 36" preserveAspectRatio="none">${svg}</svg><span class="clip-label">${icon('music-2')}${esc(m?.name || 'Audio')}</span>`;
  }
  if (c.kind === 'image' || c.kind === 'video') return `<span class="clip-label">${icon(c.freeze ? 'snowflake' : c.kind === 'video' ? 'film' : 'image')}${c.freeze ? 'Freeze · ' : ''}${esc(m?.name || '')}${c.speed !== 1 ? ` · ${c.speed}×` : ''}</span>`;
  if (c.kind === 'text') return `<span class="clip-label">${icon('type')}${esc((c.upper ? c.text.toUpperCase() : c.text).replace(/\n/g, ' '))}</span>`;
  if (c.kind === 'shape') return `<span class="clip-label">${icon('shapes')}${esc(c.shape)}</span>`;
  if (c.kind === 'solid') return `<span class="clip-label">${icon('palette')}Background</span>`;
  if (c.kind === 'fx') return `<span class="clip-label">${icon('sparkles')}${esc(FX_TYPES[c.fxType] || 'Overlay')}</span>`;
  return '';
}
function badges(c) {
  let h = '';
  if (c.kf?.length) h += c.kf.map((k) => `<i class="kf-dot" style="left:${k.t * pps}px"></i>`).join('');
  const tags = [];
  if (c.effect && c.effect !== 'none') tags.push(c.effect);
  if (c.combo && c.combo !== 'none') tags.push(c.combo);
  if (c.chroma?.on) tags.push('key');
  if (tags.length) h += `<span class="fx-tag">${tags.map((t) => esc(t.replace(/-/g, ' '))).join(' · ')}</span>`;
  return h;
}
function clipStyle(c) {
  const m = getMedia(c.mediaId);
  let s = `left:${c.start * pps}px;width:${Math.max(4, c.dur * pps)}px;`;
  if ((c.kind === 'image' || c.kind === 'video') && m?.thumb) s += `background-image:url('${m.thumb}');`;
  if (c.kind === 'solid') s += `background:${c.color2 ? `linear-gradient(90deg,${c.color},${c.color2})` : c.color};`;
  return s;
}

export function render() {
  const P = project(); if (!P) return;
  const sc = $('#tl-scroll'), content = $('#tl-content');
  const D = duration();
  const laneW = Math.max(sc.clientWidth - HEAD, (D + 15) * pps);
  const step = tickStep();
  let ruler = '';
  for (let t = 0; t <= laneW / pps; t += step) {
    ruler += `<div class="tick major" style="left:${t * pps}px"><span>${fmtTime(t, false)}</span></div>`;
    for (let j = 1; j < 5; j++) ruler += `<div class="tick" style="left:${(t + (step * j) / 5) * pps}px"></div>`;
  }
  const rows = P.tracks.map((tr) => {
    const clips = P.clips.filter((c) => c.trackId === tr.id);
    const kind = tr.type === 'audio' ? 'audio' : tr.type === 'text' ? 'text' : 'video';
    return `<div class="tl-row row-${kind} ${tr.locked ? 'locked' : ''} ${tr.hidden || tr.muted ? 'dim' : ''}">
      <div class="tl-head">
        <span class="trk-name">${tr.name}</span>
        <div class="trk-btns">
          ${tr.type === 'audio' ? `<button data-trk="${tr.id}" data-tog="muted" class="${tr.muted ? 'on' : ''}" title="Mute track">${icon(tr.muted ? 'volume-x' : 'volume-2')}</button>`
            : `<button data-trk="${tr.id}" data-tog="hidden" class="${tr.hidden ? 'on' : ''}" title="Hide track">${icon(tr.hidden ? 'eye-off' : 'eye')}</button>`}
          ${tr.type === 'video' ? `<button data-trk="${tr.id}" data-tog="muted" class="${tr.muted ? 'on' : ''}" title="Mute track audio">${icon(tr.muted ? 'volume-x' : 'volume-2')}</button>` : ''}
          <button data-trk="${tr.id}" data-tog="locked" class="${tr.locked ? 'on' : ''}" title="Lock track">${icon(tr.locked ? 'lock' : 'lock-open')}</button>
          ${!clips.length && P.tracks.filter((t) => t.type === tr.type).length > 1 ? `<button data-trk="${tr.id}" data-tog="remove" title="Remove empty track">${icon('x')}</button>` : ''}
        </div>
      </div>
      <div class="lane" data-track="${tr.id}" data-type="${tr.type}" style="width:${laneW}px">
        ${clips.map((c) => `<div class="clip k-${c.kind} ${c.id === store.selectedId ? 'sel' : ''}" data-clip="${c.id}" style="${clipStyle(c)}"><div class="trim l" data-trim="l"></div>${clipInner(c)}${badges(c)}<div class="trim r" data-trim="r"></div>${c.animIn.type !== 'none' ? `<i class="anim-mark in" style="width:${c.animIn.dur * pps}px"></i>` : ''}${c.animOut.type !== 'none' ? `<i class="anim-mark out" style="width:${c.animOut.dur * pps}px"></i>` : ''}</div>`).join('')}
      </div></div>`;
  }).join('');
  content.style.width = HEAD + laneW + 'px';
  content.innerHTML = `<div class="tl-row tl-ruler-row"><div class="tl-head tl-corner"><span class="mono" id="tl-tc">${fmtTime(api.getT())}</span></div><div class="tl-ruler" id="tl-ruler" style="width:${laneW}px">${ruler}</div></div>${rows}
    <div class="tl-playhead" id="tl-playhead"><i></i></div>
    ${P.clips.length ? '' : `<div class="tl-empty" style="left:${HEAD + 24}px">${icon('mouse-pointer-click')}<span>Add media from the left panel, or drag files straight onto a track</span></div>`}`;
  icons();
  updatePlayhead(api.getT());
}

export function updatePlayhead(t) {
  const ph = $('#tl-playhead'); if (!ph) return;
  const x = HEAD + t * pps;
  ph.style.left = x + 'px';
  const tc = $('#tl-tc'); if (tc) tc.textContent = fmtTime(t);
  const sc = $('#tl-scroll');
  if (!dragging && (x > sc.scrollLeft + sc.clientWidth - 40 || x < sc.scrollLeft + HEAD)) {
    if (document.activeElement?.id !== 'tl-zoom') sc.scrollLeft = Math.max(0, x - HEAD - 60);
  }
}

let dragging = null;
function snapPoints(exclude) {
  const pts = [0, api.getT()];
  project().clips.forEach((c) => { if (c.id !== exclude) pts.push(c.start, c.start + c.dur); });
  return pts;
}
function snapVal(v, pts) {
  if (!snapOn) return v;
  const th = 8 / pps;
  let best = v, bd = th;
  for (const p of pts) { const d = Math.abs(p - v); if (d < bd) { bd = d; best = p; } }
  return best;
}

function setupPointer(sc) {
  const timeAt = (e) => { const r = $('#tl-content').getBoundingClientRect(); return Math.max(0, (e.clientX - r.left - HEAD) / pps); };
  sc.addEventListener('click', (e) => {
    const b = e.target.closest('[data-tog]'); if (!b) return;
    const tr = getTrack(b.dataset.trk); commit();
    if (b.dataset.tog === 'remove') project().tracks = project().tracks.filter((t) => t.id !== tr.id);
    else tr[b.dataset.tog] = !tr[b.dataset.tog];
    emit('project', {});
  });
  sc.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || e.target.closest('.tl-head')) return;
    const clipEl = e.target.closest('.clip');
    if (clipEl && blade) {
      const c = getClip(clipEl.dataset.clip);
      if (getTrack(c.trackId)?.locked) return;
      const t = snapVal(timeAt(e), [api.getT()]);
      import('./editor.js').then((ed) => ed.splitAt(t, [c.id]));
      return;
    }
    if (clipEl) {
      const c = getClip(clipEl.dataset.clip);
      if (store.selectedId !== c.id) { select(c.id); }
      const cel = $(`.clip[data-clip="${c.id}"]`);
      if (getTrack(c.trackId)?.locked) return;
      e.preventDefault();
      sc.setPointerCapture(e.pointerId);
      dragging = { mode: e.target.closest('[data-trim]')?.dataset.trim || 'move', c, el: cel, x0: e.clientX, s0: c.start, d0: c.dur, in0: c.in, tr0: c.trackId, snap: JSON.stringify(project()), moved: false, pts: snapPoints(c.id) };
      return;
    }
    if (e.target.closest('.tl-ruler, .lane, .tl-ruler-row')) {
      if (!e.target.closest('.tl-ruler')) select(null);
      sc.setPointerCapture(e.pointerId);
      dragging = { mode: 'scrub' };
      api.seek(timeAt(e));
    }
  });
  sc.addEventListener('pointermove', (e) => {
    if (blade) {
      const ce = e.target.closest('.clip'); let g = $('#blade-line');
      if (!g) { g = document.createElement('div'); g.id = 'blade-line'; $('#tl-content').appendChild(g); }
      if (ce) { const r = $('#tl-content').getBoundingClientRect(); g.hidden = false; g.style.left = (e.clientX - r.left) + 'px'; const cr = ce.getBoundingClientRect(); g.style.top = (cr.top - r.top) + 'px'; g.style.height = cr.height + 'px'; } else g.hidden = true;
    }
    if (!dragging) return;
    if (dragging.mode === 'scrub') { api.seek(timeAt(e)); return; }
    const d = dragging, c = d.c;
    const dt = (e.clientX - d.x0) / pps;
    if (Math.abs(e.clientX - d.x0) > 2) d.moved = true;
    if (!d.moved) return;
    const m = getMedia(c.mediaId);
    const timed = c.kind === 'video' || c.kind === 'audio';
    if (d.mode === 'move') {
      let ns = Math.max(0, d.s0 + dt);
      const sStart = snapVal(ns, d.pts), sEnd = snapVal(ns + c.dur, d.pts) - c.dur;
      ns = Math.abs(sStart - ns) <= Math.abs(sEnd - ns) ? sStart : sEnd;
      c.start = Math.max(0, +ns.toFixed(3));
      const lane = document.elementFromPoint(e.clientX, e.clientY)?.closest('.lane');
      if (lane && lane.dataset.track !== c.trackId) {
        const isAudio = c.kind === 'audio';
        if ((lane.dataset.type === 'audio') === isAudio && !getTrack(lane.dataset.track).locked) { c.trackId = lane.dataset.track; lane.appendChild(d.el); }
      }
    } else if (d.mode === 'l') {
      let delta = dt;
      delta = Math.max(delta, -d.s0);
      if (timed) delta = Math.max(delta, -d.in0 / c.speed);
      delta = Math.min(delta, d.d0 - 0.1);
      let ns = snapVal(d.s0 + delta, d.pts); delta = ns - d.s0;
      delta = Math.min(Math.max(delta, timed ? -d.in0 / c.speed : -d.s0), d.d0 - 0.1);
      c.start = +(d.s0 + delta).toFixed(3); c.dur = +(d.d0 - delta).toFixed(3);
      if (timed) c.in = +(d.in0 + delta * c.speed).toFixed(3);
    } else if (d.mode === 'r') {
      let nd = Math.max(0.1, d.d0 + dt);
      nd = snapVal(d.s0 + nd, d.pts) - d.s0;
      if (timed && m?.duration) nd = Math.min(nd, (m.duration - c.in) / c.speed);
      c.dur = +Math.max(0.1, nd).toFixed(3);
    }
    d.el.style.left = c.start * pps + 'px';
    d.el.style.width = Math.max(4, c.dur * pps) + 'px';
    api.requestDraw();
  });
  const up = () => {
    if (!dragging) return;
    const d = dragging; dragging = null;
    if (d.mode !== 'scrub' && d.moved) { store.history.push(d.snap); store.future = []; emit('project', {}); }
  };
  sc.addEventListener('pointerup', up);
  sc.addEventListener('pointercancel', up);
}

function setupDrop(sc) {
  sc.addEventListener('dragover', (e) => { const lane = e.target.closest('.lane'); if (lane) { e.preventDefault(); lane.classList.add('drop'); } });
  sc.addEventListener('dragleave', (e) => e.target.closest('.lane')?.classList.remove('drop'));
  sc.addEventListener('drop', async (e) => {
    const lane = e.target.closest('.lane'); if (!lane) return;
    e.preventDefault(); lane.classList.remove('drop');
    const r = $('#tl-content').getBoundingClientRect();
    const start = Math.max(0, (e.clientX - r.left - HEAD) / pps);
    let ids = [];
    const id = e.dataTransfer.getData('text/media');
    if (id) ids = [id];
    else if (e.dataTransfer.files.length) { const { importFiles } = await import('./media.js'); ids = (await importFiles([...e.dataTransfer.files])).map((m) => m.id); }
    let t = start;
    for (const mid of ids) {
      const m = getMedia(mid); if (!m) continue;
      const isAudio = m.type === 'audio';
      const okLane = (lane.dataset.type === 'audio') === isAudio;
      const dur = isAudio ? Math.min(m.duration, 60) : m.type === 'video' ? m.duration : 4;
      const c = api.addMedia(mid, { start: t, trackId: okLane && !api.overlaps(lane.dataset.track, t, dur) ? lane.dataset.track : undefined });
      if (c) t = c.start + c.dur;
    }
    if (!ids.length) toast('Nothing to add');
  });
}

// Collage maker
import { FORMATS, clamp, newProject, defaultClip } from './state.js';
import { library, getMedia, importFiles, addDataImage } from './media.js';
import { FILTERS, effectiveAdj } from './render.js';
import { icon, icons, esc, toast, download } from './ui.js';

const $ = (s, r = document) => r.querySelector(s);

export const LAYOUTS = [
  { id: 'split-v', n: 2, r: [[0, 0, 0.5, 1], [0.5, 0, 0.5, 1]] },
  { id: 'split-h', n: 2, r: [[0, 0, 1, 0.5], [0, 0.5, 1, 0.5]] },
  { id: 'l-big', n: 3, r: [[0, 0, 0.62, 1], [0.62, 0, 0.38, 0.5], [0.62, 0.5, 0.38, 0.5]] },
  { id: 't-big', n: 3, r: [[0, 0, 1, 0.6], [0, 0.6, 0.5, 0.4], [0.5, 0.6, 0.5, 0.4]] },
  { id: 'cols3', n: 3, r: [[0, 0, 1 / 3, 1], [1 / 3, 0, 1 / 3, 1], [2 / 3, 0, 1 / 3, 1]] },
  { id: 'rows3', n: 3, r: [[0, 0, 1, 1 / 3], [0, 1 / 3, 1, 1 / 3], [0, 2 / 3, 1, 1 / 3]] },
  { id: 'grid4', n: 4, r: [[0, 0, 0.5, 0.5], [0.5, 0, 0.5, 0.5], [0, 0.5, 0.5, 0.5], [0.5, 0.5, 0.5, 0.5]] },
  { id: 'hero4', n: 4, r: [[0, 0, 1, 0.62], [0, 0.62, 1 / 3, 0.38], [1 / 3, 0.62, 1 / 3, 0.38], [2 / 3, 0.62, 1 / 3, 0.38]] },
  { id: 'side4', n: 4, r: [[0, 0, 0.62, 1], [0.62, 0, 0.38, 1 / 3], [0.62, 1 / 3, 0.38, 1 / 3], [0.62, 2 / 3, 0.38, 1 / 3]] },
  { id: 'mosaic5', n: 5, r: [[0, 0, 0.5, 0.6], [0.5, 0, 0.5, 0.4], [0.5, 0.4, 0.5, 0.6], [0, 0.6, 0.25, 0.4], [0.25, 0.6, 0.25, 0.4]] },
  { id: 'grid6', n: 6, r: [0, 1, 2, 3, 4, 5].map((i) => [(i % 3) / 3, Math.floor(i / 3) / 2, 1 / 3, 1 / 2]) },
  { id: 'tall6', n: 6, r: [0, 1, 2, 3, 4, 5].map((i) => [(i % 2) / 2, Math.floor(i / 2) / 3, 1 / 2, 1 / 3]) },
  { id: 'strip4', n: 4, r: [0, 1, 2, 3].map((i) => [0, i / 4, 1, 1 / 4]) },
  { id: 'grid9', n: 9, r: [...Array(9)].map((_, i) => [(i % 3) / 3, Math.floor(i / 3) / 3, 1 / 3, 1 / 3]) },
];
const SIZES = ['ig-post', 'ig-portrait', 'ig-story', 'yt-thumb', 'fb-feed', 'fb-cover'];
const BGS = ['#ffffff', '#F3EDE4', '#111114', '#FF5A36', '#FFE600', '#1F3BFF', '#C6FF3D', '#FF3D7F'];
const TITLE_FONTS = ['Anton', 'Playfair Display', 'Pacifico', 'Montserrat', 'Space Grotesk', 'Permanent Marker'];

const S = {
  fmt: 'ig-post', layout: 'grid4', gap: 16, pad: 16, radius: 12, bg: '#ffffff',
  cells: [], sel: 0,
  title: { on: false, text: 'Summer 2026', font: 'Pacifico', color: '#ffffff', size: 9, pos: 'bottom', band: true },
};
const fmt = () => FORMATS.find((f) => f.id === S.fmt);
const layout = () => LAYOUTS.find((l) => l.id === S.layout);
const cell = (i) => (S.cells[i] ||= { mediaId: null, zoom: 1, ox: 0, oy: 0, filter: 'none' });

function cellRects(W, H) {
  const g = S.gap * (W / 1080), p = S.pad * (W / 1080);
  return layout().r.map(([x, y, w, h]) => {
    let cx = p + x * (W - 2 * p), cy = p + y * (H - 2 * p), cw = w * (W - 2 * p), ch = h * (H - 2 * p);
    if (x > 0.001) { cx += g / 2; cw -= g / 2; }
    if (x + w < 0.999) cw -= g / 2;
    if (y > 0.001) { cy += g / 2; ch -= g / 2; }
    if (y + h < 0.999) ch -= g / 2;
    return { x: cx, y: cy, w: Math.max(1, cw), h: Math.max(1, ch) };
  });
}
function rr(ctx, x, y, w, h, r) { r = Math.max(0, Math.min(r, w / 2, h / 2)); ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
function filt(name) {
  const a = effectiveAdj({ filter: name, adj: {} }), p = [];
  if (a.brightness) p.push(`brightness(${1 + a.brightness / 100})`);
  if (a.contrast) p.push(`contrast(${1 + a.contrast / 100})`);
  if (a.saturation) p.push(`saturate(${Math.max(0, 1 + a.saturation / 100)})`);
  if (a.hue) p.push(`hue-rotate(${a.hue}deg)`);
  if (a.sepia) p.push(`sepia(${a.sepia / 100})`);
  if (a.temp > 0) p.push(`sepia(${a.temp / 160})`);
  return p.join(' ') || 'none';
}

function draw(ctx, W, H, preview) {
  ctx.save();
  ctx.fillStyle = S.bg; ctx.fillRect(0, 0, W, H);
  const rects = cellRects(W, H), rad = S.radius * (W / 1080);
  rects.forEach((r, i) => {
    const c = cell(i), m = getMedia(c.mediaId);
    ctx.save(); rr(ctx, r.x, r.y, r.w, r.h, rad); ctx.clip();
    if (m?.el) {
      const s = Math.max(r.w / m.w, r.h / m.h) * c.zoom;
      const dw = m.w * s, dh = m.h * s;
      const mx = (dw - r.w) / 2, my = (dh - r.h) / 2;
      ctx.filter = filt(c.filter);
      ctx.drawImage(m.el, r.x - mx + c.ox * mx, r.y - my + c.oy * my, dw, dh);
      ctx.filter = 'none';
    } else if (preview) {
      ctx.fillStyle = S.bg === '#111114' ? '#1d1d22' : 'rgba(0,0,0,0.06)'; ctx.fillRect(r.x, r.y, r.w, r.h);
      ctx.strokeStyle = 'rgba(128,128,128,0.6)'; ctx.setLineDash([10 * W / 1080, 8 * W / 1080]); ctx.lineWidth = 2 * W / 1080;
      rr(ctx, r.x + 4, r.y + 4, r.w - 8, r.h - 8, rad); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = 'rgba(128,128,128,0.9)'; ctx.font = `600 ${Math.min(r.w, r.h) * 0.18}px "General Sans", sans-serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('+', r.x + r.w / 2, r.y + r.h / 2);
    }
    ctx.restore();
    if (preview && i === S.sel) { ctx.strokeStyle = '#FF5A36'; ctx.lineWidth = 6 * W / 1080; rr(ctx, r.x + 3, r.y + 3, r.w - 6, r.h - 6, rad); ctx.stroke(); }
  });
  if (S.title.on && S.title.text) {
    const fs = (S.title.size / 100) * W;
    ctx.font = `700 ${fs}px "${S.title.font}", sans-serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    const y = S.title.pos === 'top' ? H * 0.1 : S.title.pos === 'center' ? H / 2 : H * 0.9;
    if (S.title.band) {
      const tw = ctx.measureText(S.title.text).width;
      ctx.fillStyle = 'rgba(0,0,0,0.55)'; rr(ctx, W / 2 - tw / 2 - fs * 0.6, y - fs * 0.75, tw + fs * 1.2, fs * 1.5, fs * 0.3); ctx.fill();
    }
    ctx.shadowColor = 'rgba(0,0,0,0.35)'; ctx.shadowBlur = fs * 0.2;
    ctx.fillStyle = S.title.color; ctx.fillText(S.title.text, W / 2, y);
  }
  ctx.restore();
}

let ds = 1;
function redraw() {
  const cv = $('#collage-canvas'), st = $('#collage-stage'), F = fmt();
  if (!cv || !st.clientWidth) return;
  ds = Math.min((st.clientWidth - 48) / F.w, (st.clientHeight - 48) / F.h);
  const dpr = Math.min(2, devicePixelRatio || 1);
  const cw = Math.round(F.w * ds), ch = Math.round(F.h * ds);
  cv.style.width = cw + 'px'; cv.style.height = ch + 'px';
  cv.width = Math.min(F.w, cw * dpr); cv.height = Math.round(cv.width * F.h / F.w);
  const ctx = cv.getContext('2d');
  const k = cv.width / F.w;
  ctx.setTransform(k, 0, 0, k, 0, 0);
  draw(ctx, F.w, F.h, true);
}

function leftHTML() {
  const imgs = library.filter((m) => m.type === 'image').sort((a, b) => (a.sample ? 1 : 0) - (b.sample ? 1 : 0));
  return `<div class="panel-head"><h3>Photos</h3><label class="btn btn-primary btn-sm">${icon('upload')}<span>Import</span><input type="file" id="col-file" multiple accept="image/*"></label></div>
   <p class="hint">Click a cell, then a photo. Drag a photo onto any cell. Drag inside a cell to reposition, scroll to zoom.</p>
   <div class="btn-row"><button class="btn btn-sm" id="col-auto">${icon('wand-sparkles')}<span>Auto-fill</span></button><button class="btn btn-sm" id="col-shuffle">${icon('shuffle')}<span>Shuffle</span></button></div>
   <div class="media-grid">${imgs.map((m) => `<div class="media-card" draggable="true" data-media="${m.id}"><img src="${m.thumb}" alt="${esc(m.name)}" crossorigin="anonymous"><span class="name">${esc(m.name)}</span></div>`).join('')}</div>`;
}
function rightHTML() {
  const c = cell(S.sel);
  const lsvg = (l) => `<svg viewBox="0 0 100 100">${l.r.map(([x, y, w, h]) => `<rect x="${x * 100 + 3}" y="${y * 100 + 3}" width="${w * 100 - 6}" height="${h * 100 - 6}" rx="4"/>`).join('')}</svg>`;
  return `<div class="insp-head"><h3>Collage</h3></div><div class="insp-body">
    <h4 class="sub">Size</h4><div class="chips">${SIZES.map((id) => { const f = FORMATS.find((x) => x.id === id); return `<button class="chip ${S.fmt === id ? 'on' : ''}" data-size="${id}">${f.platform} ${f.name}</button>`; }).join('')}</div>
    <h4 class="sub">Layout</h4><div class="layout-grid">${LAYOUTS.map((l) => `<button class="layout-btn ${S.layout === l.id ? 'on' : ''}" data-layout="${l.id}" title="${l.n} photos">${lsvg(l)}</button>`).join('')}</div>
    <h4 class="sub">Spacing</h4>
    ${rng('Gap', 'gap', S.gap, 0, 80)}${rng('Border', 'pad', S.pad, 0, 120)}${rng('Corner radius', 'radius', S.radius, 0, 120)}
    <h4 class="sub">Background</h4><div class="bg-grid small">${BGS.map((b) => `<button class="bg-sw ${S.bg === b ? 'on' : ''}" data-cbg="${b}" style="background:${b}" aria-label="${b}"></button>`).join('')}<input type="color" id="col-bg" value="${S.bg}" aria-label="Custom background"></div>
    <h4 class="sub">Selected cell · ${S.sel + 1}</h4>
    ${rng('Zoom', 'zoom', c.zoom, 1, 4, 0.01)}
    <label class="field"><span>Filter</span><select id="col-filter">${Object.entries(FILTERS).map(([k, f]) => `<option value="${k}" ${c.filter === k ? 'selected' : ''}>${f.label}</option>`).join('')}</select></label>
    <div class="btn-row"><button class="btn btn-sm" id="col-reset">Reset position</button><button class="btn btn-sm" id="col-clear">Clear cell</button></div>
    <h4 class="sub">Title</h4>
    <label class="toggle"><input type="checkbox" id="col-ton" ${S.title.on ? 'checked' : ''}><span>Show title</span></label>
    ${S.title.on ? `<label class="field"><span>Text</span><input type="text" id="col-ttext" value="${esc(S.title.text)}"></label>
      <div class="grid2"><label class="field"><span>Font</span><select id="col-tfont">${TITLE_FONTS.map((f) => `<option ${f === S.title.font ? 'selected' : ''}>${f}</option>`).join('')}</select></label>
      <label class="field"><span>Position</span><select id="col-tpos">${['top', 'center', 'bottom'].map((p) => `<option ${p === S.title.pos ? 'selected' : ''}>${p}</option>`).join('')}</select></label></div>
      ${rng('Size', 'tsize', S.title.size, 3, 20, 0.5)}
      <div class="grid2"><label class="field field-inline"><span>Color</span><input type="color" id="col-tcolor" value="${S.title.color}"></label><label class="toggle"><input type="checkbox" id="col-tband" ${S.title.band ? 'checked' : ''}><span>Backdrop</span></label></div>` : ''}
  </div>`;
}
const rng = (label, k, v, min, max, step = 1) => `<label class="field"><span>${label}</span><div class="range"><input type="range" data-ck="${k}" min="${min}" max="${max}" step="${step}" value="${v}"><input type="number" data-ck="${k}" min="${min}" max="${max}" step="${step}" value="${v}"></div></label>`;

function renderPanels() {
  $('#collage-left').innerHTML = leftHTML();
  $('#collage-right').innerHTML = rightHTML();
  icons();
}

function fillCell(i, mediaId) { const c = cell(i); c.mediaId = mediaId; c.zoom = 1; c.ox = 0; c.oy = 0; }
function nextEmpty() { const n = layout().n; for (let i = 0; i < n; i++) if (!cell(i).mediaId) return i; return -1; }

function cellAt(e) {
  const r = $('#collage-canvas').getBoundingClientRect(), F = fmt();
  const x = (e.clientX - r.left) / ds, y = (e.clientY - r.top) / ds;
  return cellRects(F.w, F.h).findIndex((c) => x >= c.x && x <= c.x + c.w && y >= c.y && y <= c.y + c.h);
}

export function renderCollage(F, W, H) { const c = document.createElement('canvas'); c.width = W; c.height = H; draw(c.getContext('2d'), W, H, false); return c; }

export function placeInCollage(mediaId) {
  const i = nextEmpty() >= 0 ? nextEmpty() : S.sel;
  fillCell(i, mediaId); S.sel = i; openCollage();
}

export function openCollage(opts = {}) {
  if (opts.fmt) S.fmt = opts.fmt;
  document.querySelectorAll('.view').forEach((v) => (v.hidden = v.id !== 'view-collage'));
  renderPanels();
  requestAnimationFrame(redraw);
}

export function initCollage() {
  const left = $('#collage-left'), right = $('#collage-right'), stage = $('#collage-stage');
  new ResizeObserver(redraw).observe(stage);
  left.addEventListener('click', (e) => {
    const card = e.target.closest('[data-media]');
    if (card) { const i = cell(S.sel).mediaId ? (nextEmpty() >= 0 ? nextEmpty() : S.sel) : S.sel; fillCell(i, card.dataset.media); S.sel = nextEmpty() >= 0 ? nextEmpty() : i; renderPanels(); redraw(); }
    if (e.target.closest('#col-auto')) {
      const imgs = library.filter((m) => m.type === 'image'); let k = 0;
      for (let i = 0; i < layout().n; i++) if (!cell(i).mediaId && imgs.length) fillCell(i, imgs[k++ % imgs.length].id);
      redraw(); renderPanels();
    }
    if (e.target.closest('#col-shuffle')) {
      const n = layout().n, ids = [...Array(n)].map((_, i) => cell(i).mediaId).sort(() => Math.random() - 0.5);
      ids.forEach((id, i) => fillCell(i, id)); redraw();
    }
  });
  left.addEventListener('change', async (e) => {
    if (e.target.id !== 'col-file') return;
    const added = await importFiles([...e.target.files]);
    added.forEach((m) => { const i = nextEmpty(); if (i >= 0) fillCell(i, m.id); });
    toast(`Added ${added.length} photo${added.length === 1 ? '' : 's'}`); renderPanels(); redraw();
  });
  left.addEventListener('dragstart', (e) => { const id = e.target.closest('[data-media]')?.dataset.media; if (id) e.dataTransfer.setData('text/media', id); });
  stage.addEventListener('dragover', (e) => e.preventDefault());
  stage.addEventListener('drop', async (e) => {
    e.preventDefault();
    const i = cellAt(e);
    let id = e.dataTransfer.getData('text/media');
    if (!id && e.dataTransfer.files.length) { const a = await importFiles([...e.dataTransfer.files].filter((f) => f.type.startsWith('image/'))); id = a[0]?.id; renderPanels(); }
    if (id && i >= 0) { fillCell(i, id); S.sel = i; renderPanels(); redraw(); }
  });
  let drag = null;
  stage.addEventListener('pointerdown', (e) => {
    const i = cellAt(e); if (i < 0) return;
    if (S.sel !== i) { S.sel = i; $('#collage-right').innerHTML = rightHTML(); icons(); }
    const c = cell(i);
    redraw();
    if (!c.mediaId) { $('#col-pick').dataset.cell = i; $('#col-pick').click(); return; }
    stage.setPointerCapture(e.pointerId);
    const F = fmt(), r = cellRects(F.w, F.h)[i], m = getMedia(c.mediaId);
    const s = Math.max(r.w / m.w, r.h / m.h) * c.zoom;
    drag = { c, x0: e.clientX, y0: e.clientY, ox: c.ox, oy: c.oy, mx: Math.max(1, (m.w * s - r.w) / 2), my: Math.max(1, (m.h * s - r.h) / 2) };
  });
  stage.addEventListener('pointermove', (e) => {
    if (!drag) return;
    drag.c.ox = clamp(drag.ox - (e.clientX - drag.x0) / ds / drag.mx, -1, 1);
    drag.c.oy = clamp(drag.oy - (e.clientY - drag.y0) / ds / drag.my, -1, 1);
    redraw();
  });
  stage.addEventListener('pointerup', () => (drag = null));
  stage.addEventListener('wheel', (e) => {
    const i = cellAt(e); if (i < 0 || !cell(i).mediaId) return;
    e.preventDefault(); S.sel = i;
    const c = cell(i); c.zoom = clamp(c.zoom * (e.deltaY < 0 ? 1.08 : 0.93), 1, 4); redraw();
    right.querySelectorAll('[data-ck="zoom"]').forEach((x) => (x.value = +c.zoom.toFixed(2)));
  }, { passive: false });
  $('#col-pick').addEventListener('change', async (e) => {
    const a = await importFiles([...e.target.files]); const i = +e.target.dataset.cell;
    if (a[0]) { fillCell(i, a[0].id); renderPanels(); redraw(); }
    e.target.value = '';
  });
  right.addEventListener('input', (e) => {
    const t = e.target, k = t.dataset.ck;
    if (k) {
      const v = parseFloat(t.value); if (isNaN(v)) return;
      if (k === 'zoom') cell(S.sel).zoom = v; else if (k === 'tsize') S.title.size = v; else S[k] = v;
      right.querySelectorAll(`[data-ck="${k}"]`).forEach((o) => o !== t && (o.value = v));
    }
    if (t.id === 'col-bg') S.bg = t.value;
    if (t.id === 'col-ttext') S.title.text = t.value;
    if (t.id === 'col-tcolor') S.title.color = t.value;
    redraw();
  });
  right.addEventListener('change', (e) => {
    const t = e.target;
    if (t.id === 'col-filter') cell(S.sel).filter = t.value;
    if (t.id === 'col-ton') { S.title.on = t.checked; right.innerHTML = rightHTML(); }
    if (t.id === 'col-tband') S.title.band = t.checked;
    if (t.id === 'col-tfont') S.title.font = t.value;
    if (t.id === 'col-tpos') S.title.pos = t.value;
    redraw();
  });
  right.addEventListener('click', (e) => {
    const sz = e.target.closest('[data-size]'), ly = e.target.closest('[data-layout]'), bg = e.target.closest('[data-cbg]');
    if (sz) S.fmt = sz.dataset.size;
    if (ly) { S.layout = ly.dataset.layout; S.sel = Math.min(S.sel, layout().n - 1); }
    if (bg) S.bg = bg.dataset.cbg;
    if (e.target.closest('#col-reset')) { const c = cell(S.sel); c.zoom = 1; c.ox = 0; c.oy = 0; }
    if (e.target.closest('#col-clear')) fillCell(S.sel, null);
    if (sz || ly || bg || e.target.closest('#col-reset, #col-clear')) { right.innerHTML = rightHTML(); icons(); redraw(); }
  });
  $('#col-export').onclick = () => {
    const F = fmt();
    renderCollage(F, F.w, F.h).toBlob((b) => { download(b, `collage-${F.id}.png`); toast('Collage exported as PNG'); }, 'image/png');
  };
  $('#col-to-editor').onclick = async () => {
    const F = fmt();
    const url = renderCollage(F, F.w, F.h).toDataURL('image/jpeg', 0.92);
    const m = await addDataImage(url, 'Collage');
    const P = newProject(F, 'Collage video');
    const v1 = P.tracks.find((t) => t.name === 'V1');
    P.clips.push(defaultClip({ trackId: v1.id, kind: 'image', mediaId: m.id, x: F.w / 2, y: F.h / 2, w: F.w, h: F.h, dur: 6, combo: 'ken-burns', animIn: { type: 'fade', dur: 0.6 } }));
    const { openProject } = await import('./editor.js');
    openProject(P);
    toast('Collage added to a new video project');
  };
}

// Rendering engine: draws a project frame at time t
import { getMedia } from './media.js';
import { textDefaults } from './state.js';

export const FILTERS = {
  none: { label: 'Original' },
  vivid: { label: 'Vivid', saturation: 40, contrast: 12 },
  warm: { label: 'Warm', temp: 35, saturation: 10 },
  cool: { label: 'Cool', temp: -35, brightness: 4 },
  cinema: { label: 'Cinematic', contrast: 18, saturation: -12, temp: 12, vignette: 0.45 },
  mono: { label: 'Mono', saturation: -100, contrast: 10 },
  noir: { label: 'Noir', saturation: -100, contrast: 45, brightness: -8, vignette: 0.6 },
  vintage: { label: 'Vintage', sepia: 45, contrast: -8, saturation: -10, vignette: 0.35 },
  fade: { label: 'Faded', contrast: -22, brightness: 8, saturation: -18 },
  dream: { label: 'Dreamy', brightness: 10, saturation: 15, blur: 0.6, hue: -8 },
  pop: { label: 'Pop', saturation: 70, contrast: 25, hue: 6 },
  teal: { label: 'Teal & Orange', temp: 20, hue: -12, contrast: 15, saturation: 20 },
};

export const ANIMS = ['none', 'fade', 'slide-up', 'slide-down', 'slide-left', 'slide-right', 'zoom-in', 'zoom-out', 'pop', 'spin', 'blur', 'wipe', 'bounce', 'typewriter'];
export const COMBOS = ['none', 'ken-burns', 'zoom-out-slow', 'pan-left', 'pan-right', 'pulse', 'zoom-punch', 'heartbeat', 'sway', 'swing', 'float', 'bounce-loop', 'spin-loop', 'handheld', 'shake', 'earthquake'];
export const EFFECTS = ['none', 'glitch', 'rgb-split', 'vhs', 'pixelate', 'mirror', 'flash', 'strobe', 'blur-pulse', 'invert-flash', 'duotone'];
export const FX_TYPES = { 'light-leak': 'Light leak', grain: 'Film grain', letterbox: 'Cinema bars', scanlines: 'Scanlines', vignette: 'Vignette', flash: 'White flash', bokeh: 'Bokeh', dust: 'Old film', snow: 'Snowfall', 'color-tint': 'Color wash' };
export const MASKS = ['none', 'rect', 'circle', 'heart', 'star', 'triangle'];

const ease = (p) => 1 - Math.pow(1 - p, 3);
const backOut = (p) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2); };
const bounceOut = (x) => { const n = 7.5625, d = 2.75; if (x < 1 / d) return n * x * x; if (x < 2 / d) return n * (x -= 1.5 / d) * x + 0.75; if (x < 2.5 / d) return n * (x -= 2.25 / d) * x + 0.9375; return n * (x -= 2.625 / d) * x + 0.984375; };

function applyAnim(a, type, p, P, dir) {
  if (type === 'none' || p >= 1) return;
  const e = ease(Math.max(0, p));
  const k = 1 - e;
  switch (type) {
    case 'fade': a.alpha *= e; break;
    case 'slide-up': a.dy += k * P.h * 0.18 * (dir === 'out' ? -1 : 1); a.alpha *= e; break;
    case 'slide-down': a.dy -= k * P.h * 0.18 * (dir === 'out' ? -1 : 1); a.alpha *= e; break;
    case 'slide-left': a.dx += k * P.w * 0.3 * (dir === 'out' ? -1 : 1); a.alpha *= Math.min(1, e * 2); break;
    case 'slide-right': a.dx -= k * P.w * 0.3 * (dir === 'out' ? -1 : 1); a.alpha *= Math.min(1, e * 2); break;
    case 'zoom-in': a.scale *= 0.5 + 0.5 * e; a.alpha *= e; break;
    case 'zoom-out': a.scale *= 1 + 0.6 * k; a.alpha *= e; break;
    case 'pop': a.scale *= Math.max(0.01, backOut(Math.max(0, p))); a.alpha *= Math.min(1, p * 3); break;
    case 'spin': a.rot += k * (dir === 'out' ? 1 : -1) * Math.PI * 0.6; a.scale *= 0.4 + 0.6 * e; a.alpha *= e; break;
    case 'blur': a.blur += k * 24; a.alpha *= e; break;
    case 'wipe': a.wipe = Math.min(a.wipe, e); break;
    case 'bounce': a.dy -= (1 - bounceOut(Math.max(0, p))) * P.h * 0.25; a.alpha *= Math.min(1, p * 4); break;
    case 'typewriter': a.chars = Math.min(a.chars, p); break;
  }
}

function applyCombo(a, type, local, dur, P) {
  const p = dur ? local / dur : 0;
  switch (type) {
    case 'ken-burns': a.scale *= 1 + 0.14 * p; a.dx += -P.w * 0.02 * p; break;
    case 'zoom-out-slow': a.scale *= 1.16 - 0.14 * p; break;
    case 'pan-left': a.scale *= 1.15; a.dx += P.w * 0.06 * (0.5 - p); break;
    case 'pan-right': a.scale *= 1.15; a.dx -= P.w * 0.06 * (0.5 - p); break;
    case 'pulse': a.scale *= 1 + 0.05 * Math.sin(local * Math.PI * 2 * 1.2); break;
    case 'sway': a.rot += Math.sin(local * 2.4) * 0.06; break;
    case 'float': a.dy += Math.sin(local * 2) * P.h * 0.012; break;
    case 'shake': a.dx += Math.sin(local * 61) * P.w * 0.004; a.dy += Math.cos(local * 47) * P.h * 0.004; break;
    case 'earthquake': a.dx += Math.sin(local * 83) * P.w * 0.012; a.dy += Math.cos(local * 71) * P.h * 0.012; a.rot += Math.sin(local * 53) * 0.015; break;
    case 'zoom-punch': { const b = (local % 0.5) / 0.5; a.scale *= 1 + 0.1 * Math.pow(1 - b, 3); break; }
    case 'heartbeat': { const b = local % 1; a.scale *= 1 + 0.07 * Math.max(0, Math.sin(b * Math.PI * 4)) * (b < 0.5 ? 1 : 0); break; }
    case 'swing': a.rot += Math.sin(local * 3) * 0.14; break;
    case 'bounce-loop': a.dy -= Math.abs(Math.sin(local * 4)) * P.h * 0.03; break;
    case 'spin-loop': a.rot += local * Math.PI; break;
    case 'handheld': a.scale *= 1.06; a.dx += (Math.sin(local * 1.3) + Math.sin(local * 2.9) * 0.5) * P.w * 0.006; a.dy += (Math.cos(local * 1.7) + Math.sin(local * 3.7) * 0.4) * P.h * 0.006; a.rot += Math.sin(local * 1.1) * 0.006; break;
  }
}

export function effectiveAdj(clip) {
  const f = FILTERS[clip.filter] || {};
  const a = clip.adj || {};
  const g = (k) => (f[k] || 0) + (a[k] || 0);
  return { brightness: g('brightness'), contrast: g('contrast'), saturation: g('saturation'), hue: g('hue'), temp: g('temp'), vignette: g('vignette'), blur: g('blur'), sepia: f.sepia || 0 };
}

function filterString(adj, extraBlur, k) {
  const parts = [];
  if (adj.brightness) parts.push(`brightness(${1 + adj.brightness / 100})`);
  if (adj.contrast) parts.push(`contrast(${1 + adj.contrast / 100})`);
  if (adj.saturation) parts.push(`saturate(${Math.max(0, 1 + adj.saturation / 100)})`);
  if (adj.hue) parts.push(`hue-rotate(${adj.hue}deg)`);
  if (adj.sepia) parts.push(`sepia(${adj.sepia / 100})`);
  const b = (adj.blur || 0) * 4 + extraBlur;
  if (b > 0.1) parts.push(`blur(${b * k}px)`);
  return parts.length ? parts.join(' ') : 'none';
}

function roundRect(ctx, x, y, w, h, r) {
  r = Math.max(0, Math.min(r, w / 2, h / 2));
  ctx.beginPath();
  ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}

export function fontStr(c) {
  const s = { ...textDefaults, ...c };
  return `${s.italic ? 'italic ' : ''}${s.weight} ${s.size}px "${s.font}", "Inter", sans-serif`;
}

const measureCtx = document.createElement('canvas').getContext('2d');
export function measureText(clip) {
  const s = { ...textDefaults, ...clip };
  const ctx = measureCtx;
  ctx.font = fontStr(s);
  try { ctx.letterSpacing = (s.spacing || 0) + 'px'; } catch (e) {}
  const lines = (s.upper ? s.text.toUpperCase() : s.text).split('\n');
  const widths = lines.map((l) => ctx.measureText(l).width);
  const lh = s.size * s.lineHeight;
  const pad = s.bg ? s.bgPad : 0;
  const w = Math.max(10, ...widths) + pad * 2 + s.stroke * 2;
  const h = lines.length * lh + pad * 2 + s.stroke * 2;
  return { lines, widths, lh, w, h, pad };
}

export function clipBox(clip) {
  if (clip.kind === 'text') { const m = measureText(clip); return { w: m.w, h: m.h }; }
  return { w: clip.w, h: clip.h };
}

function drawText(ctx, clip, a) {
  const s = { ...textDefaults, ...clip };
  const m = measureText(s);
  ctx.font = fontStr(s);
  try { ctx.letterSpacing = (s.spacing || 0) + 'px'; } catch (e) {}
  ctx.textBaseline = 'middle';
  ctx.textAlign = s.align;
  if (s.bg) {
    ctx.fillStyle = s.bg;
    roundRect(ctx, -m.w / 2, -m.h / 2, m.w, m.h, s.bgRadius);
    ctx.fill();
  }
  let total = m.lines.reduce((n, l) => n + l.length, 0);
  let budget = a.chars < 1 ? Math.floor(total * a.chars) : Infinity;
  const innerW = m.w - m.pad * 2 - s.stroke * 2;
  const x = s.align === 'left' ? -innerW / 2 : s.align === 'right' ? innerW / 2 : 0;
  m.lines.forEach((line, i) => {
    if (budget <= 0) return;
    const txt = line.slice(0, budget);
    budget -= line.length;
    const y = -m.h / 2 + m.pad + s.stroke + m.lh * (i + 0.5);
    if (s.shadow) { ctx.shadowColor = s.shadowColor; ctx.shadowBlur = s.size * 0.25; ctx.shadowOffsetY = s.size * 0.06; }
    if (s.stroke > 0) {
      ctx.lineJoin = 'round'; ctx.miterLimit = 2;
      ctx.lineWidth = s.stroke * 2; ctx.strokeStyle = s.strokeColor;
      ctx.strokeText(txt, x, y);
      ctx.shadowColor = 'transparent';
    }
    ctx.fillStyle = s.color;
    ctx.fillText(txt, x, y);
    ctx.shadowColor = 'transparent';
  });
}

function shapePath(ctx, shape, w, h, r) {
  ctx.beginPath();
  if (shape === 'circle') ctx.ellipse(0, 0, w / 2, h / 2, 0, 0, Math.PI * 2);
  else if (shape === 'triangle') { ctx.moveTo(0, -h / 2); ctx.lineTo(w / 2, h / 2); ctx.lineTo(-w / 2, h / 2); ctx.closePath(); }
  else if (shape === 'star') {
    for (let i = 0; i < 10; i++) { const ang = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? 0.42 : 1; ctx.lineTo(Math.cos(ang) * w / 2 * rr, Math.sin(ang) * h / 2 * rr); }
    ctx.closePath();
  } else if (shape === 'arrow') {
    const sh = h * 0.36;
    ctx.moveTo(-w / 2, -sh / 2); ctx.lineTo(w / 2 - h / 2, -sh / 2); ctx.lineTo(w / 2 - h / 2, -h / 2); ctx.lineTo(w / 2, 0);
    ctx.lineTo(w / 2 - h / 2, h / 2); ctx.lineTo(w / 2 - h / 2, sh / 2); ctx.lineTo(-w / 2, sh / 2); ctx.closePath();
  } else if (shape === 'heart') {
    ctx.moveTo(0, h * 0.35);
    ctx.bezierCurveTo(-w * 0.55, -h * 0.05, -w * 0.35, -h * 0.55, 0, -h * 0.22);
    ctx.bezierCurveTo(w * 0.35, -h * 0.55, w * 0.55, -h * 0.05, 0, h * 0.35);
    ctx.closePath();
  } else { roundRect(ctx, -w / 2, -h / 2, w, h, r || 0); }
}


// ---------- keyframes ----------
const KF_PROPS = ['x', 'y', 'scale', 'rotation', 'opacity'];
const easeIO = (p) => (p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2);
export function effTransform(c, local) {
  const base = { x: c.x, y: c.y, scale: c.scale ?? 1, rotation: c.rotation || 0, opacity: c.opacity ?? 1 };
  const kf = c.kf;
  if (!kf || !kf.length) return base;
  if (local <= kf[0].t) return { ...base, ...pick(kf[0]) };
  const last = kf[kf.length - 1];
  if (local >= last.t) return { ...base, ...pick(last) };
  for (let i = 0; i < kf.length - 1; i++) {
    const a = kf[i], b = kf[i + 1];
    if (local >= a.t && local <= b.t) {
      const p = easeIO((local - a.t) / Math.max(0.0001, b.t - a.t));
      const o = {};
      KF_PROPS.forEach((k) => (o[k] = (a[k] ?? base[k]) + ((b[k] ?? base[k]) - (a[k] ?? base[k])) * p));
      return o;
    }
  }
  return base;
}
const pick = (k) => { const o = {}; KF_PROPS.forEach((p) => k[p] !== undefined && (o[p] = k[p])); return o; };

// ---------- chroma key ----------
const keyCache = new Map();
const hexRgb = (h) => { const n = parseInt((h || '#00ff00').slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
function keyed(src, sw, sh, ch, cacheKey) {
  const ck = cacheKey && `${cacheKey}|${ch.color}|${ch.tol}|${ch.soft}`;
  if (ck && keyCache.has(ck)) return keyCache.get(ck);
  const s = Math.min(1, 960 / sw), w = Math.max(1, Math.round(sw * s)), h = Math.max(1, Math.round(sh * s));
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  const x = cv.getContext('2d', { willReadFrequently: true });
  x.drawImage(src, 0, 0, w, h);
  try {
    const d = x.getImageData(0, 0, w, h), px = d.data;
    const [kr, kg, kb] = hexRgb(ch.color);
    const t = (ch.tol ?? 35) * 4.4, soft = Math.max(1, (ch.soft ?? 20) * 2.5);
    const greenish = kg > kr && kg > kb, bluish = kb > kr && kb > kg;
    for (let i = 0; i < px.length; i += 4) {
      const r = px[i], g = px[i + 1], b = px[i + 2];
      const dist = Math.sqrt((r - kr) ** 2 + (g - kg) ** 2 + (b - kb) ** 2);
      if (dist < t) px[i + 3] = 0;
      else if (dist < t + soft) px[i + 3] *= (dist - t) / soft;
      if (greenish && g > Math.max(r, b)) px[i + 1] = Math.max(r, b);
      if (bluish && b > Math.max(r, g)) px[i + 2] = Math.max(r, g);
    }
    x.putImageData(d, 0, 0);
  } catch (e) { /* tainted canvas: fall back to unkeyed */ }
  const out = { el: cv, w, h };
  if (ck) { if (keyCache.size > 40) keyCache.clear(); keyCache.set(ck, out); }
  return out;
}

function drawMedia(ctx, src, sw, sh, w, h, fit, radius, mask) {
  ctx.save();
  if (mask && mask !== 'none') shapePath(ctx, mask === 'rect' ? 'rect' : mask, w, h, radius || 0);
  else roundRect(ctx, -w / 2, -h / 2, w, h, radius || 0);
  ctx.clip();
  if (fit === 'fill') ctx.drawImage(src, -w / 2, -h / 2, w, h);
  else {
    const s = fit === 'contain' ? Math.min(w / sw, h / sh) : Math.max(w / sw, h / sh);
    ctx.drawImage(src, -sw * s / 2, -sh * s / 2, sw * s, sh * s);
  }
  ctx.restore();
}

// ---------- procedural overlays ----------
let noiseCv = null;
function noise() {
  if (noiseCv) return noiseCv;
  noiseCv = document.createElement('canvas'); noiseCv.width = noiseCv.height = 256;
  const x = noiseCv.getContext('2d'), d = x.createImageData(256, 256);
  for (let i = 0; i < d.data.length; i += 4) { const v = Math.random() * 255; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 255; }
  x.putImageData(d, 0, 0);
  return noiseCv;
}
const rnd = (n) => { const x = Math.sin(n * 12.9898) * 43758.5453; return x - Math.floor(x); };
function drawFx(ctx, c, local, w, h) {
  const L = -w / 2, T = -h / 2;
  switch (c.fxType) {
    case 'grain': {
      ctx.globalCompositeOperation = 'overlay';
      const pat = ctx.createPattern(noise(), 'repeat');
      ctx.save(); ctx.translate(Math.floor(rnd(Math.floor(local * 24)) * 256), Math.floor(rnd(Math.floor(local * 24) + 7) * 256));
      ctx.fillStyle = pat; ctx.fillRect(L - 256, T - 256, w + 512, h + 512); ctx.restore();
      break;
    }
    case 'light-leak': {
      ctx.globalCompositeOperation = 'screen';
      const cx = Math.sin(local * 0.7) * w * 0.35 - w * 0.2, cy = Math.cos(local * 0.5) * h * 0.3;
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(w, h) * 0.6);
      g.addColorStop(0, c.color || 'rgba(255,140,60,0.95)'); g.addColorStop(0.45, 'rgba(255,60,90,0.45)'); g.addColorStop(1, 'rgba(255,60,90,0)');
      ctx.fillStyle = g; ctx.fillRect(L, T, w, h);
      const g2 = ctx.createRadialGradient(-cx, -cy * 1.2, 0, -cx, -cy, Math.max(w, h) * 0.45);
      g2.addColorStop(0, 'rgba(255,220,120,0.6)'); g2.addColorStop(1, 'rgba(255,220,120,0)');
      ctx.fillStyle = g2; ctx.fillRect(L, T, w, h);
      break;
    }
    case 'letterbox': {
      const bar = w > h ? Math.max(h * 0.06, (h - w / 2.39) / 2) : h * 0.09;
      ctx.fillStyle = c.color || '#000'; ctx.fillRect(L, T, w, bar); ctx.fillRect(L, -T - bar, w, bar);
      break;
    }
    case 'scanlines': {
      ctx.fillStyle = 'rgba(0,0,0,0.28)';
      for (let y = T; y < -T; y += 6) ctx.fillRect(L, y, w, 2);
      const by = T + ((local * 0.35) % 1) * h;
      const g = ctx.createLinearGradient(0, by - 60, 0, by + 60); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(0.5, 'rgba(255,255,255,0.10)'); g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g; ctx.fillRect(L, by - 60, w, 120);
      break;
    }
    case 'vignette': {
      const r = Math.hypot(w, h) / 2, g = ctx.createRadialGradient(0, 0, r * 0.3, 0, 0, r);
      g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, c.color || 'rgba(0,0,0,0.9)');
      ctx.fillStyle = g; ctx.fillRect(L, T, w, h);
      break;
    }
    case 'flash': {
      const p = local / Math.max(0.05, c.dur);
      ctx.globalAlpha *= Math.max(0, 1 - p) ** 2;
      ctx.fillStyle = c.color || '#fff'; ctx.fillRect(L, T, w, h);
      break;
    }
    case 'bokeh': {
      ctx.globalCompositeOperation = 'screen';
      for (let i = 0; i < 22; i++) {
        const px = L + rnd(i) * w + Math.sin(local * 0.4 + i) * 40, py = T + ((rnd(i + 50) + local * 0.03 * (1 + rnd(i + 9))) % 1) * h;
        const r = (0.02 + rnd(i + 3) * 0.06) * Math.max(w, h);
        const g = ctx.createRadialGradient(px, py, 0, px, py, r);
        const hue = 20 + rnd(i + 11) * 50;
        g.addColorStop(0, `hsla(${hue},100%,75%,0.55)`); g.addColorStop(0.7, `hsla(${hue},100%,65%,0.25)`); g.addColorStop(1, `hsla(${hue},100%,60%,0)`);
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(px, py, r, 0, Math.PI * 2); ctx.fill();
      }
      break;
    }
    case 'dust': {
      const f = Math.floor(local * 18);
      ctx.globalCompositeOperation = 'multiply'; ctx.fillStyle = 'rgba(230,200,150,0.35)'; ctx.fillRect(L, T, w, h);
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 2;
      for (let i = 0; i < 3; i++) { if (rnd(f + i * 13) > 0.55) { const x = L + rnd(f * 3 + i) * w; ctx.beginPath(); ctx.moveTo(x, T); ctx.lineTo(x + (rnd(f + i) - 0.5) * 20, -T); ctx.stroke(); } }
      ctx.fillStyle = 'rgba(20,15,10,0.6)';
      for (let i = 0; i < 14; i++) { const x = L + rnd(f * 7 + i) * w, y = T + rnd(f * 11 + i) * h, r = 1 + rnd(f + i * 5) * 3; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill(); }
      break;
    }
    case 'snow': {
      ctx.fillStyle = 'rgba(255,255,255,0.9)';
      for (let i = 0; i < 120; i++) {
        const sp = 0.05 + rnd(i + 2) * 0.12, x = L + ((rnd(i) * w + Math.sin(local + i) * 30) % w + w) % w, y = T + ((rnd(i + 40) + local * sp) % 1) * h, r = 1.5 + rnd(i + 7) * 4;
        ctx.globalAlpha = 0.4 + rnd(i + 9) * 0.6; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
      }
      break;
    }
    case 'color-tint': {
      ctx.globalCompositeOperation = 'soft-light'; ctx.fillStyle = c.color || '#ff5a36'; ctx.fillRect(L, T, w, h);
      break;
    }
  }
}

// ---------- layer pool for per-clip effects ----------
let layerA = null, layerB = null;
function layer(which, w, h) {
  let c = which === 'a' ? layerA : layerB;
  if (!c) { c = document.createElement('canvas'); which === 'a' ? (layerA = c) : (layerB = c); }
  if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
  const x = c.getContext('2d'); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, w, h);
  return c;
}
function tinted(src, color) {
  const c = layer('b', src.width, src.height), x = c.getContext('2d');
  x.drawImage(src, 0, 0); x.globalCompositeOperation = 'multiply'; x.fillStyle = color; x.fillRect(0, 0, c.width, c.height);
  x.globalCompositeOperation = 'destination-in'; x.drawImage(src, 0, 0); x.globalCompositeOperation = 'source-over';
  return c;
}
function compositeEffect(ctx, src, c, local, k) {
  const W = src.width, H = src.height, e = c.effect, amt = c.effectAmt ?? 1;
  ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalCompositeOperation = c.blend || 'source-over';
  const rgb = (o) => {
    const red = tinted(src, '#ff0000');
    const tmp = document.createElement('canvas'); tmp.width = W; tmp.height = H; tmp.getContext('2d').drawImage(red, 0, 0);
    const cy = tinted(src, '#00ffff');
    ctx.drawImage(cy, o, 0);
    ctx.globalCompositeOperation = 'screen'; ctx.drawImage(tmp, -o, 0);
    ctx.globalCompositeOperation = c.blend || 'source-over';
  };
  if (e === 'rgb-split') rgb(Math.round(10 * k * amt + 2));
  else if (e === 'glitch' || e === 'vhs') {
    const f = Math.floor(local * (e === 'vhs' ? 8 : 12));
    const active = e === 'vhs' || rnd(f) < 0.45;
    if (!active) ctx.drawImage(src, 0, 0);
    else {
      const slices = e === 'vhs' ? 3 : 7;
      let y = 0;
      for (let i = 0; i < slices && y < H; i++) {
        const sh = Math.round(H * (0.05 + rnd(f * 9 + i) * 0.25)), off = Math.round((rnd(f * 5 + i) - 0.5) * W * 0.08 * amt * (e === 'vhs' ? 0.3 : 1));
        ctx.drawImage(src, 0, y, W, sh, off, y, W, sh); y += sh;
      }
      if (y < H) ctx.drawImage(src, 0, y, W, H - y, 0, y, W, H - y);
      ctx.globalAlpha = 0.6; ctx.globalCompositeOperation = 'screen';
      ctx.drawImage(tinted(src, '#ff0040'), Math.round(8 * k * amt), 0);
      ctx.globalAlpha = 1; ctx.globalCompositeOperation = c.blend || 'source-over';
      if (e === 'vhs') { ctx.fillStyle = 'rgba(0,0,0,0.2)'; for (let yy = 0; yy < H; yy += Math.max(2, Math.round(4 * k))) ctx.fillRect(0, yy, W, Math.max(1, Math.round(1.5 * k))); }
    }
  } else if (e === 'pixelate') {
    const q = Math.max(2, Math.round((10 + 30 * amt) * k));
    const t = layer('b', Math.max(1, Math.round(W / q)), Math.max(1, Math.round(H / q)));
    t.getContext('2d').drawImage(src, 0, 0, t.width, t.height);
    ctx.imageSmoothingEnabled = false; ctx.drawImage(t, 0, 0, W, H); ctx.imageSmoothingEnabled = true;
  } else if (e === 'mirror') {
    ctx.drawImage(src, 0, 0, W / 2, H, 0, 0, W / 2, H);
    ctx.translate(W, 0); ctx.scale(-1, 1); ctx.drawImage(src, 0, 0, W / 2, H, 0, 0, W / 2, H);
  } else if (e === 'strobe') {
    ctx.globalAlpha = Math.floor(local / 0.12) % 2 ? 0.15 : 1; ctx.drawImage(src, 0, 0);
  } else if (e === 'blur-pulse') {
    ctx.filter = `blur(${(Math.abs(Math.sin(local * 3)) * 14 * amt * k).toFixed(1)}px)`; ctx.drawImage(src, 0, 0); ctx.filter = 'none';
  } else if (e === 'invert-flash') {
    if (Math.floor(local / 0.25) % 4 === 0) ctx.filter = 'invert(1)';
    ctx.drawImage(src, 0, 0); ctx.filter = 'none';
  } else if (e === 'duotone') {
    ctx.filter = 'grayscale(1) contrast(1.2)'; ctx.drawImage(src, 0, 0); ctx.filter = 'none';
    ctx.globalCompositeOperation = 'color'; ctx.globalAlpha = Math.min(1, amt); ctx.drawImage(tinted(src, c.effectColor || '#ff5a36'), 0, 0);
  } else if (e === 'flash') {
    ctx.drawImage(src, 0, 0);
    const p = (local % 0.6) / 0.6;
    ctx.globalCompositeOperation = 'source-atop'; // only over clip pixels? use lighter overlay limited to clip
    ctx.globalAlpha = Math.pow(1 - p, 4) * 0.85 * amt; ctx.globalCompositeOperation = 'lighter';
    ctx.drawImage(tinted(src, '#ffffff'), 0, 0);
  } else ctx.drawImage(src, 0, 0);
  ctx.restore();
}

export function animState(clip, t, P) {
  const local = t - clip.start;
  const a = { alpha: 1, dx: 0, dy: 0, scale: 1, rot: 0, blur: 0, wipe: 1, chars: 1 };
  if (clip.animIn?.type !== 'none') applyAnim(a, clip.animIn.type, local / Math.max(0.05, clip.animIn.dur), P, 'in');
  if (clip.animOut?.type !== 'none') applyAnim(a, clip.animOut.type, (clip.dur - local) / Math.max(0.05, clip.animOut.dur), P, 'out');
  if (clip.combo && clip.combo !== 'none' && inFxWindow(clip, local)) applyCombo(a, clip.combo, local - (clip.fxStart || 0), clip.fxLen || clip.dur, P);
  return a;
}

/**
 * env: { k: render scale, getSource(clip) -> {el,w,h}|null }
 */
export function renderFrame(ctx, P, t, env) {
  const k = env.k || 1;
  ctx.save();
  ctx.setTransform(k, 0, 0, k, 0, 0);
  ctx.fillStyle = P.bg || '#000';
  ctx.fillRect(0, 0, P.w, P.h);
  const order = [...P.tracks].reverse().filter((tr) => tr.type !== 'audio' && !tr.hidden);
  for (const tr of order) {
    const clips = P.clips.filter((c) => c.trackId === tr.id && t >= c.start && t < c.start + c.dur).sort((a, b) => a.start - b.start);
    for (const c of clips) {
      if (c.effect && c.effect !== 'none' && inFxWindow(c, t - c.start)) {
        const L = layer('a', ctx.canvas.width, ctx.canvas.height), lx = L.getContext('2d');
        lx.setTransform(k, 0, 0, k, 0, 0);
        drawClip(lx, { ...c, blend: 'source-over' }, t, P, env, k);
        compositeEffect(ctx, L, c, t - c.start - (c.fxStart || 0), k);
      } else drawClip(ctx, c, t, P, env, k);
    }
  }
  ctx.restore();
}

function drawClip(ctx, c, t, P, env, k) {
  const local = t - c.start;
  const a = animState(c, t, P);
  const tf = effTransform(c, local);
  if (a.alpha <= 0.001 || tf.opacity <= 0.001) return;
  const adj = effectiveAdj(c);
  const box = clipBox(c);
  let src = null;
  if (c.kind === 'image' || c.kind === 'video') {
    src = env.getSource ? env.getSource(c) : null;
    if (!src) { const m = getMedia(c.mediaId); if (m && m.type === 'image') src = { el: m.el, w: m.w, h: m.h }; }
    if (!src) return;
    if (c.chroma?.on) src = keyed(src.el, src.w, src.h, c.chroma, c.kind === 'image' ? c.mediaId : null);
  }
  ctx.save();
  ctx.globalAlpha = tf.opacity * a.alpha;
  ctx.globalCompositeOperation = c.blend || 'source-over';
  ctx.translate(tf.x + a.dx, tf.y + a.dy);
  ctx.rotate((tf.rotation * Math.PI) / 180 + a.rot);
  const s = tf.scale * a.scale;
  ctx.scale(s * (c.flipH ? -1 : 1), s * (c.flipV ? -1 : 1));
  if (a.wipe < 1) { ctx.beginPath(); ctx.rect(-box.w / 2, -box.h / 2, box.w * a.wipe, box.h); ctx.clip(); }
  ctx.filter = filterString(adj, a.blur, k * s);
  if (src) drawMedia(ctx, src.el, src.w, src.h, box.w, box.h, c.fit, c.radius, c.mask);
  else if (c.kind === 'solid') { ctx.fillStyle = grad(ctx, c, box.w, box.h); roundRect(ctx, -box.w / 2, -box.h / 2, box.w, box.h, c.radius || 0); ctx.fill(); }
  else if (c.kind === 'shape') {
    shapePath(ctx, c.shape, box.w, box.h, c.radius);
    if (c.fill) { ctx.fillStyle = grad(ctx, { color: c.fill, color2: c.fill2, angle: c.angle }, box.w, box.h); ctx.fill(); }
    if (c.strokeW) { ctx.lineWidth = c.strokeW; ctx.strokeStyle = c.strokeC || '#fff'; ctx.stroke(); }
  } else if (c.kind === 'text') drawText(ctx, c, a);
  else if (c.kind === 'fx') drawFx(ctx, c, local, box.w, box.h);
  ctx.filter = 'none';
  if ((adj.temp || adj.vignette) && c.kind !== 'fx') {
    ctx.save();
    roundRect(ctx, -box.w / 2, -box.h / 2, box.w, box.h, c.radius || 0); ctx.clip();
    if (adj.temp) {
      ctx.globalCompositeOperation = 'soft-light';
      ctx.globalAlpha *= Math.min(1, Math.abs(adj.temp) / 60);
      ctx.fillStyle = adj.temp > 0 ? '#ff9a3c' : '#3c8cff';
      ctx.fillRect(-box.w / 2, -box.h / 2, box.w, box.h);
    }
    if (adj.vignette) {
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = tf.opacity * a.alpha;
      const r = Math.hypot(box.w, box.h) / 2;
      const g = ctx.createRadialGradient(0, 0, r * 0.35, 0, 0, r);
      g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, `rgba(0,0,0,${Math.min(0.95, adj.vignette)})`);
      ctx.fillStyle = g; ctx.fillRect(-box.w / 2, -box.h / 2, box.w, box.h);
    }
    ctx.restore();
  }
  ctx.restore();
}

// hit test: returns topmost visual clip at point (project coords)
export function hitTest(P, t, px, py) {
  for (const tr of P.tracks) {
    if (tr.type === 'audio' || tr.hidden || tr.locked) continue;
    const clips = P.clips.filter((c) => c.trackId === tr.id && c.kind !== 'fx' && t >= c.start && t < c.start + c.dur).sort((a, b) => b.start - a.start);
    for (const c of clips) {
      const box = clipBox(c), tf = effTransform(c, t - c.start);
      const r = -(tf.rotation * Math.PI) / 180;
      const dx = px - tf.x, dy = py - tf.y;
      const lx = (dx * Math.cos(r) - dy * Math.sin(r)) / tf.scale;
      const ly = (dx * Math.sin(r) + dy * Math.cos(r)) / tf.scale;
      if (Math.abs(lx) <= box.w / 2 && Math.abs(ly) <= box.h / 2) return c;
    }
  }
  return null;
}

function grad(ctx, c, w, h) {
  if (!c.color2) return c.color;
  const ang = ((c.angle ?? 135) * Math.PI) / 180;
  const dx = Math.cos(ang) * w / 2, dy = Math.sin(ang) * h / 2;
  const g = ctx.createLinearGradient(-dx, -dy, dx, dy);
  g.addColorStop(0, c.color); g.addColorStop(1, c.color2);
  return g;
}

export function inFxWindow(c, local) {
  const a = c.fxStart || 0, len = c.fxLen || 0;
  return local >= a - 0.0001 && (len <= 0 || local < a + len);
}

// Designed templates for YouTube, Instagram, Facebook
import { FORMATS, newProject, defaultClip, textDefaults, uid } from './state.js';
import { sampleId, getMedia } from './media.js';

const F = (id) => FORMATS.find((f) => f.id === id);

function builder(fmtId, name) {
  const fmt = F(fmtId);
  const P = newProject(fmt, name);
  P.tracks.unshift({ id: uid('trk'), type: 'text', name: 'T2', muted: false, hidden: false, locked: false });
  const [T2, T1, V2, V1, A1] = P.tracks;
  const W = P.w, H = P.h;
  const add = (track, o) => { const c = defaultClip({ trackId: track.id, ...o }); P.clips.push(c); return c; };
  const img = (track, key, o = {}) => add(track, { kind: 'image', mediaId: sampleId(key), x: W / 2, y: H / 2, w: W, h: H, ...o });
  const text = (track, o) => add(track, { kind: 'text', ...textDefaults, x: W / 2, y: H / 2, ...o });
  const shape = (track, o) => add(track, { kind: 'shape', shape: 'rect', fill: '#ffffff', ...o });
  const solid = (track, o) => add(track, { kind: 'solid', x: W / 2, y: H / 2, w: W, h: H, color: '#111', ...o });
  const music = (key, dur) => { const m = getMedia('music_' + key); if (m) add(A1, { kind: 'audio', mediaId: m.id, start: 0, dur: Math.min(dur, m.duration), fadeOut: 1.5, volume: 0.8 }); };
  return { P, T2, T1, V2, V1, A1, W, H, add, img, text, shape, solid, music };
}

const A = (type, dur = 0.5) => ({ type, dur });

function channelIntro(fmtId, name) {
  const b = builder(fmtId, name);
  const fxT = { id: uid('trk'), type: 'text', name: 'T3', muted: false, hidden: false, locked: false };
  const fxT2 = { id: uid('trk'), type: 'text', name: 'T4', muted: false, hidden: false, locked: false };
  const subT = { id: uid('trk'), type: 'text', name: 'T6', muted: false, hidden: false, locked: false };
  const lineT = { id: uid('trk'), type: 'text', name: 'T5', muted: false, hidden: false, locked: false };
  b.P.tracks.unshift(fxT); b.P.tracks.unshift(fxT2); b.P.tracks.unshift(lineT); b.P.tracks.unshift(subT);
  const W = b.W, H = b.H, v = H > W, D = 8;
  const full = { x: W / 2, y: H / 2, w: W, h: H };
  b.P.bg = '#050507';
  b.solid(b.V1, { start: 0, dur: D, color: '#050507', color2: '#2a0912', angle: 120 });
  b.img(b.V2, 'concert', { start: 0, dur: D, filter: 'noir', opacity: 0.38, combo: 'ken-burns', animIn: A('fade', 1.2), animOut: A('fade', 0.8) });
  b.add(fxT, { kind: 'fx', fxType: 'light-leak', ...full, start: 0, dur: D, opacity: 0.45, color: 'rgba(255,40,70,0.9)' });
  b.add(fxT2, { kind: 'fx', fxType: 'grain', ...full, start: 0, dur: D, opacity: 0.45 });
  b.add(b.T2, { kind: 'fx', fxType: 'flash', ...full, start: 0.8, dur: 0.45, color: '' });
  const nameSize = v ? 200 : 210;
  b.text(b.T1, { text: v ? 'MR DARK\nMEMORY' : 'MR DARK MEMORY', font: 'Anton', size: nameSize, spacing: v ? 10 : 16, lineHeight: 1, color: '#F4F1EE', shadow: true, shadowColor: '#FF2B4E',
    start: 0.8, dur: 6.6, y: H * (v ? 0.44 : 0.45), animIn: A('blur', 0.9), animOut: A('fade', 0.6), effect: 'glitch', fxStart: 0, fxLen: 0.9, effectAmt: 1.2 });
  b.shape(lineT, { shape: 'rect', x: W / 2, y: H * (v ? 0.6 : 0.6), w: v ? W * 0.5 : W * 0.34, h: 8, fill: '#FF2B4E', start: 1.5, dur: 5.9, animIn: A('wipe', 0.6), animOut: A('fade', 0.5) });
  b.text(b.T2, { text: 'STORIES · MYSTERY · MEMORIES', font: 'Space Grotesk', weight: 600, size: v ? 38 : 42, spacing: 12, color: '#FF8A9B', start: 1.9, dur: 5.5, y: H * (v ? 0.645 : 0.68), animIn: A('slide-up', 0.6), animOut: A('fade', 0.5) });
  b.text(subT, { text: 'SUBSCRIBE', font: 'Space Grotesk', weight: 700, size: v ? 50 : 46, color: '#ffffff', bg: '#E5191E', bgPad: 22, bgRadius: 12, start: 4.2, dur: 3.2, y: H * (v ? 0.8 : 0.84), animIn: A('pop', 0.4), animOut: A('fade', 0.4), combo: 'pulse' });
  b.music('lofi', D);
  return b.P;
}

export const TEMPLATES = [
  // ---------------- Featured: channel ----------------
  { id: 'mdm-intro', platform: 'YouTube', name: 'MR DARK MEMORY intro', tag: 'Channel intro · 8s', thumbT: 2.6, featured: true, build: () => channelIntro('yt-video', 'MR DARK MEMORY intro') },
  { id: 'mdm-shorts-intro', platform: 'YouTube', name: 'MR DARK MEMORY Shorts intro', tag: 'Shorts intro · 8s', thumbT: 2.6, featured: true, build: () => channelIntro('yt-shorts', 'MR DARK MEMORY Shorts intro') },
  // ---------------- YouTube ----------------
  {
    id: 'yt-vlog-intro', platform: 'YouTube', name: 'Vlog intro', tag: 'Video · 10s', thumbT: 2.2,
    build() {
      const b = builder('yt-video', 'Vlog intro');
      b.img(b.V1, 'travel', { start: 0, dur: 5, combo: 'ken-burns', filter: 'cinema', animIn: A('fade', 0.8) });
      b.img(b.V1, 'beach', { start: 5, dur: 5, combo: 'zoom-out-slow', filter: 'teal', animIn: A('fade', 0.6), animOut: A('fade', 0.8) });
      b.text(b.T1, { text: 'WEEKEND IN\nTHE HILLS', font: 'Anton', size: 190, start: 0.6, dur: 4.2, y: b.H * 0.46, animIn: A('pop', 0.6), animOut: A('fade', 0.4), shadow: true, spacing: 4 });
      b.text(b.T2, { text: 'EPISODE 07 · HIMACHAL', font: 'Space Grotesk', weight: 600, size: 44, spacing: 10, start: 1.2, dur: 3.6, y: b.H * 0.72, color: '#FFD3C2', animIn: A('slide-up', 0.6), animOut: A('fade', 0.4) });
      b.shape(b.T1, { shape: 'rect', x: 240, y: b.H - 150, w: 12, h: 90, fill: '#FF5A36', start: 5.4, dur: 4.2, animIn: A('wipe', 0.4) });
      b.text(b.T2, { text: 'Day 2 — Ocean road', font: 'Poppins', weight: 600, size: 58, align: 'left', start: 5.6, dur: 4, x: 520, y: b.H - 170, animIn: A('slide-right', 0.5), animOut: A('fade', 0.4) });
      b.text(b.T2, { text: 'Goa coastline · 6:40 AM', font: 'Poppins', weight: 400, size: 34, align: 'left', start: 5.8, dur: 3.8, x: 440, y: b.H - 110, color: '#d9d9d9', animIn: A('slide-right', 0.5), animOut: A('fade', 0.4) });
      b.music('lofi', 10);
      return b.P;
    },
  },
  {
    id: 'yt-thumb-bold', platform: 'YouTube', name: 'Bold thumbnail', tag: 'Thumbnail · PNG', thumbT: 1,
    build() {
      const b = builder('yt-thumb', 'Bold thumbnail');
      b.P.bg = '#FFD400';
      b.solid(b.V1, { start: 0, dur: 5, color: '#FFD400', color2: '#FF7A00', angle: 20 });
      b.img(b.V2, 'creator', { start: 0, dur: 5, x: b.W * 0.76, y: b.H / 2, w: b.W * 0.48, h: b.H, fit: 'cover', filter: 'vivid' });
      b.text(b.T1, { text: 'I FILMED\n30 DAYS', font: 'Anton', size: 150, color: '#ffffff', stroke: 10, strokeColor: '#111111', start: 0, dur: 5, x: b.W * 0.3, y: b.H * 0.42, rotation: -4, shadow: true });
      b.text(b.T2, { text: 'ON A PHONE', font: 'Anton', size: 74, color: '#111', bg: '#ffffff', bgPad: 18, bgRadius: 8, start: 0, dur: 5, x: b.W * 0.3, y: b.H * 0.8, rotation: -4 });
      b.shape(b.T2, { shape: 'arrow', x: b.W * 0.55, y: b.H * 0.28, w: 200, h: 100, fill: '#E5191E', strokeW: 8, strokeC: '#fff', rotation: 20, start: 0, dur: 5 });
      return b.P;
    },
  },
  {
    id: 'yt-shorts-hook', platform: 'YouTube', name: 'Shorts hook', tag: 'Shorts · 9s', thumbT: 1.6,
    build() {
      const b = builder('yt-shorts', 'Shorts hook');
      b.img(b.V1, 'creator', { start: 0, dur: 9, combo: 'ken-burns', filter: 'vivid' });
      const cap = (t, s, d, y = 0.68) => b.text(b.T1, { text: t, font: 'Montserrat', weight: 900, size: 104, color: '#fff', stroke: 9, strokeColor: '#000', start: s, dur: d, y: b.H * y, animIn: A('pop', 0.35), upper: true });
      cap('Stop scrolling', 0, 2.2); cap('3 tricks for\nbetter shots', 2.2, 3.2); cap('Number 3 is wild', 5.4, 3.6);
      b.text(b.T2, { text: 'WATCH TILL THE END', font: 'Space Grotesk', weight: 700, size: 40, color: '#111', bg: '#FFE600', bgPad: 18, bgRadius: 40, start: 0, dur: 9, y: b.H * 0.12, combo: 'pulse' });
      b.shape(b.T2, { shape: 'rect', x: b.W / 2, y: b.H - 30, w: b.W, h: 14, fill: '#FF0033', start: 0, dur: 9, animIn: A('wipe', 9) });
      b.music('pop', 9);
      return b.P;
    },
  },
  {
    id: 'yt-end-screen', platform: 'YouTube', name: 'End screen', tag: 'Video · 8s', thumbT: 2,
    build() {
      const b = builder('yt-video', 'End screen');
      b.solid(b.V1, { start: 0, dur: 8, color: '#0E0E12', color2: '#2A1430', angle: 120 });
      b.img(b.V2, 'concert', { start: 0, dur: 8, x: b.W * 0.3, y: b.H * 0.56, w: 760, h: 428, radius: 24, animIn: A('slide-up', 0.6) });
      b.img(b.V2, 'beach', { start: 0.2, dur: 7.8, x: b.W * 0.7, y: b.H * 0.56, w: 760, h: 428, radius: 24, animIn: A('slide-up', 0.6) });
      b.text(b.T1, { text: 'WATCH NEXT', font: 'Anton', size: 110, start: 0, dur: 8, y: b.H * 0.18, animIn: A('fade', 0.6), spacing: 6 });
      b.shape(b.T1, { shape: 'circle', x: b.W / 2, y: b.H * 0.9, w: 120, h: 120, fill: '#FF5A36', start: 0.6, dur: 7.4, animIn: A('pop', 0.5), combo: 'pulse' });
      b.text(b.T2, { text: 'SUBSCRIBE', font: 'Space Grotesk', weight: 700, size: 38, color: '#fff', bg: '#E5191E', bgPad: 16, bgRadius: 10, start: 0.8, dur: 7.2, x: b.W / 2 + 230, y: b.H * 0.9, animIn: A('slide-left', 0.5) });
      b.music('lofi', 8);
      return b.P;
    },
  },
  // ---------------- Instagram ----------------
  {
    id: 'ig-reel-food', platform: 'Instagram', name: 'Food reel', tag: 'Reel · 9s', thumbT: 1.4,
    build() {
      const b = builder('ig-reel', 'Food reel');
      b.img(b.V1, 'food', { start: 0, dur: 4.5, combo: 'ken-burns', filter: 'warm' });
      b.img(b.V1, 'coffee', { start: 4.5, dur: 4.5, combo: 'pan-left', filter: 'warm', animIn: A('zoom-out', 0.5) });
      b.text(b.T1, { text: 'Delhi after dark', font: 'Pacifico', size: 120, color: '#FFE7C2', start: 0.3, dur: 4, y: b.H * 0.22, shadow: true, animIn: A('typewriter', 1.2), animOut: A('fade', 0.4) });
      b.text(b.T2, { text: '₹60 · BEST TANDOORI', font: 'Space Grotesk', weight: 700, size: 46, color: '#111', bg: '#FFE7C2', bgPad: 20, bgRadius: 999, start: 1.4, dur: 3, y: b.H * 0.78, animIn: A('pop', 0.4), animOut: A('fade', 0.3) });
      b.text(b.T1, { text: 'then coffee.', font: 'Playfair Display', italic: true, weight: 700, size: 130, start: 5, dur: 3.8, y: b.H * 0.5, animIn: A('blur', 0.7), shadow: true });
      b.music('lofi', 9);
      return b.P;
    },
  },
  {
    id: 'ig-post-drop', platform: 'Instagram', name: 'Product drop', tag: 'Post · 1:1', thumbT: 2,
    build() {
      const b = builder('ig-post', 'Product drop');
      b.img(b.V1, 'product', { start: 0, dur: 6, combo: 'pulse' });
      b.text(b.T1, { text: 'NEW DROP', font: 'Anton', size: 170, color: '#fff', start: 0, dur: 6, y: 170, spacing: 8, animIn: A('slide-down', 0.6) });
      b.text(b.T2, { text: 'AIR / 01', font: 'Space Grotesk', weight: 700, size: 40, color: '#fff', spacing: 14, start: 0.3, dur: 5.7, y: 290, animIn: A('fade', 0.6) });
      b.text(b.T2, { text: '₹7,999', font: 'Space Grotesk', weight: 700, size: 54, color: '#FF5A36', bg: '#ffffff', bgPad: 22, bgRadius: 12, start: 0.8, dur: 5.2, x: b.W - 220, y: b.H - 130, rotation: -6, animIn: A('pop', 0.4) });
      b.text(b.T1, { text: 'Link in bio', font: 'Poppins', weight: 600, size: 38, color: '#fff', start: 1, dur: 5, x: 200, y: b.H - 120, animIn: A('slide-right', 0.5) });
      return b.P;
    },
  },
  {
    id: 'ig-story-sale', platform: 'Instagram', name: 'Flash sale story', tag: 'Story · 7s', thumbT: 1.5,
    build() {
      const b = builder('ig-story', 'Flash sale story');
      b.solid(b.V1, { start: 0, dur: 7, color: '#FF3D7F', color2: '#7B2FF7', angle: 60 });
      b.img(b.V2, 'product', { start: 0, dur: 7, x: b.W / 2, y: b.H * 0.62, w: 860, h: 860, radius: 430, combo: 'float', animIn: A('zoom-in', 0.6) });
      b.text(b.T1, { text: 'FLASH\nSALE', font: 'Anton', size: 240, start: 0.2, dur: 6.8, y: b.H * 0.2, lineHeight: 0.95, animIn: A('bounce', 0.8) });
      b.text(b.T2, { text: '40% OFF', font: 'Montserrat', weight: 900, size: 92, color: '#7B2FF7', bg: '#FFE600', bgPad: 26, bgRadius: 20, start: 0.8, dur: 6.2, x: b.W * 0.68, y: b.H * 0.42, rotation: 8, animIn: A('pop', 0.4), combo: 'pulse' });
      b.text(b.T2, { text: 'Ends tonight · swipe up', font: 'Poppins', weight: 600, size: 44, start: 1, dur: 6, y: b.H * 0.92, animIn: A('slide-up', 0.5) });
      b.music('pop', 7);
      return b.P;
    },
  },
  {
    id: 'ig-quote', platform: 'Instagram', name: 'Quote card', tag: 'Portrait · 4:5', thumbT: 2,
    build() {
      const b = builder('ig-portrait', 'Quote card');
      b.solid(b.V1, { start: 0, dur: 6, color: '#F3EDE4' });
      b.text(b.T1, { text: '“', font: 'Playfair Display', weight: 700, size: 360, color: '#FF5A36', start: 0, dur: 6, y: b.H * 0.24 });
      b.text(b.T1, { text: 'Make things\nthat make\npeople feel.', font: 'Playfair Display', weight: 700, size: 116, color: '#1B1B1B', lineHeight: 1.12, start: 0.2, dur: 5.8, y: b.H * 0.5, animIn: A('fade', 0.8) });
      b.shape(b.T2, { shape: 'rect', x: b.W / 2, y: b.H * 0.75, w: 120, h: 6, fill: '#1B1B1B', start: 0.6, dur: 5.4, animIn: A('wipe', 0.5) });
      b.text(b.T2, { text: '@yourhandle', font: 'Space Grotesk', weight: 600, size: 40, color: '#1B1B1B', spacing: 4, start: 0.8, dur: 5.2, y: b.H * 0.81, animIn: A('slide-up', 0.5) });
      return b.P;
    },
  },
  // ---------------- Facebook ----------------
  {
    id: 'fb-event', platform: 'Facebook', name: 'Event promo', tag: 'Feed · 8s', thumbT: 1.8,
    build() {
      const b = builder('fb-feed', 'Event promo');
      b.img(b.V1, 'concert', { start: 0, dur: 8, combo: 'ken-burns', filter: 'pop' });
      b.solid(b.V2, { start: 0, dur: 8, color: 'rgba(10,8,30,0)', color2: 'rgba(10,8,30,0.85)', angle: 90 });
      b.text(b.T1, { text: 'LIVE THIS\nFRIDAY', font: 'Anton', size: 170, start: 0.3, dur: 7.7, y: b.H * 0.64, lineHeight: 0.98, animIn: A('slide-up', 0.7) });
      b.text(b.T2, { text: 'Hauz Khas · 9 PM · Free entry', font: 'Poppins', weight: 600, size: 44, color: '#FFD3C2', start: 0.9, dur: 7.1, y: b.H * 0.86, animIn: A('fade', 0.6) });
      b.text(b.T2, { text: 'GET TICKETS', font: 'Space Grotesk', weight: 700, size: 36, color: '#111', bg: '#ffffff', bgPad: 18, bgRadius: 999, start: 1.4, dur: 6.6, y: b.H * 0.1, animIn: A('pop', 0.4) });
      b.music('pop', 8);
      return b.P;
    },
  },
  {
    id: 'fb-cover', platform: 'Facebook', name: 'Page cover', tag: 'Cover · PNG', thumbT: 1,
    build() {
      const b = builder('fb-cover', 'Page cover');
      b.img(b.V1, 'beach', { start: 0, dur: 5, filter: 'teal' });
      b.solid(b.V2, { start: 0, dur: 5, color: 'rgba(0,0,0,0.55)', color2: 'rgba(0,0,0,0)', angle: 0 });
      b.text(b.T1, { text: 'Coastline Studio', font: 'Playfair Display', weight: 700, size: 120, color: '#fff', align: 'left', start: 0, dur: 5, x: 560, y: b.H * 0.44 });
      b.text(b.T2, { text: 'TRAVEL FILMS · PHOTOGRAPHY · STORIES', font: 'Space Grotesk', weight: 600, size: 30, spacing: 6, color: '#e6f4f4', start: 0, dur: 5, x: 520, y: b.H * 0.62 });
      return b.P;
    },
  },
  {
    id: 'fb-story-ad', platform: 'Facebook', name: 'Gym story ad', tag: 'Story · 8s', thumbT: 1.6,
    build() {
      const b = builder('fb-story', 'Gym story ad');
      b.img(b.V1, 'fitness', { start: 0, dur: 8, combo: 'zoom-out-slow', filter: 'noir' });
      b.text(b.T1, { text: 'NO\nEXCUSES', font: 'Anton', size: 230, color: '#fff', start: 0.2, dur: 7.8, y: b.H * 0.2, lineHeight: 0.95, animIn: A('slide-down', 0.6) });
      b.text(b.T2, { text: 'First month free', font: 'Poppins', weight: 600, size: 56, color: '#C6FF3D', start: 1, dur: 7, y: b.H * 0.74, animIn: A('typewriter', 1) });
      b.text(b.T2, { text: 'JOIN TODAY', font: 'Montserrat', weight: 900, size: 54, color: '#111', bg: '#C6FF3D', bgPad: 28, bgRadius: 999, start: 1.8, dur: 6.2, y: b.H * 0.86, animIn: A('pop', 0.4), combo: 'pulse' });
      b.music('pop', 8);
      return b.P;
    },
  },
  {
    id: 'fb-landscape-cafe', platform: 'Facebook', name: 'Café promo', tag: 'Landscape · 8s', thumbT: 2.2,
    build() {
      const b = builder('fb-landscape', 'Café promo');
      b.img(b.V1, 'coffee', { start: 0, dur: 8, combo: 'pan-right', filter: 'warm' });
      b.solid(b.V2, { start: 0, dur: 8, x: b.W * 0.25, w: b.W * 0.5, color: 'rgba(28,18,12,0.88)' });
      b.text(b.T1, { text: 'Slow\nmornings.', font: 'Playfair Display', weight: 700, italic: true, size: 150, color: '#F6E7D4', align: 'left', lineHeight: 1.02, start: 0.3, dur: 7.7, x: b.W * 0.25, y: b.H * 0.42, animIn: A('fade', 0.9) });
      b.text(b.T2, { text: 'Fresh roast every day · Open 7 AM', font: 'Poppins', weight: 500, size: 38, color: '#E3C9A8', start: 1, dur: 7, x: b.W * 0.25, y: b.H * 0.7, animIn: A('slide-up', 0.5) });
      b.music('lofi', 8);
      return b.P;
    },
  },
];

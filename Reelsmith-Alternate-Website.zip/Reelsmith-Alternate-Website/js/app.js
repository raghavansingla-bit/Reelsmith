// App shell: home screen, routing, boot
import { FORMATS, newProject } from './state.js';
import { loadSamples } from './media.js';
import { renderFrame } from './render.js';
import { TEMPLATES } from './templates.js';
import { initEditor, openProject, seek } from './editor.js';
import { initCollage, openCollage, LAYOUTS } from './collage.js';
import { initThumbnail, openThumbnail } from './thumbnail.js';
import { initPhoto, openPhoto } from './photo.js';
import { icon, icons, esc } from './ui.js';

const $ = (s, r = document) => r.querySelector(s);
const cache = new Map();
const tplProject = (id) => { if (!cache.has(id)) cache.set(id, TEMPLATES.find((t) => t.id === id).build()); return cache.get(id); };

export function drawThumbs(root = document) {
  root.querySelectorAll('canvas[data-thumb]').forEach((cv) => {
    if (cv.dataset.feature) return;
    const tpl = TEMPLATES.find((t) => t.id === cv.dataset.thumb);
    const P = tplProject(tpl.id);
    const W = 360, ar = P.w / P.h;
    const w = ar >= 1 ? W : Math.round(W * 0.62 * ar * 1.0 / 0.62), h = Math.round(w / ar);
    cv.width = w * 1.5; cv.height = h * 1.5;
    cv.style.aspectRatio = `${P.w} / ${P.h}`;
    renderFrame(cv.getContext('2d'), P, tpl.thumbT, { k: cv.width / P.w });
  });
}

function animateThumb(cv) {
  const tpl = TEMPLATES.find((t) => t.id === cv.dataset.thumb);
  const P = tplProject(tpl.id);
  const D = Math.max(...P.clips.map((c) => c.start + c.dur));
  const t0 = performance.now();
  cv._anim = true;
  const step = (now) => {
    if (!cv._anim || !cv.isConnected) { cv._anim = false; return; }
    if ($('#view-home').hidden) { requestAnimationFrame(step); return; }
    const t = ((now - t0) / 1000) % D;
    renderFrame(cv.getContext('2d'), P, t, { k: cv.width / P.w });
    requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

const PLATFORMS = ['All', 'YouTube', 'Instagram', 'Facebook'];
let tplFilter = 'All', fmtFilter = 'YouTube';

function formatShape(f) {
  const max = 54, ar = f.w / f.h;
  const w = ar >= 1 ? max : Math.round(max * ar), h = ar >= 1 ? Math.round(max / ar) : max;
  return `<span class="fmt-shape" style="width:${w}px;height:${h}px"></span>`;
}

function homeHTML() {
  const fmts = FORMATS.filter((f) => f.platform === fmtFilter);
  const tpls = TEMPLATES.filter((t) => tplFilter === 'All' || t.platform === tplFilter);
  return `
  <header class="home-nav">
    <div class="brand">${LOGO}<span>Reelsmith</span></div>
    <nav><button class="btn btn-ghost" id="home-thumb">${icon('image-play')}<span>Thumbnail maker</span></button>
    <button class="btn btn-ghost" id="home-photo">${icon('image')}<span>Photo editor</span></button>
    <button class="btn btn-ghost" id="home-collage">${icon('layout-grid')}<span>Collage maker</span></button>
    <button class="btn btn-primary" id="home-blank">${icon('plus')}<span>New video</span></button></nav>
  </header>
  <div class="home-wrap">
    <section class="home-hero">
      <div>
        <p class="eyebrow">Video editor · Templates · Collages · Thumbnails · Photos · <span class="chan">by MR DARK MEMORY</span></p>
        <h1>Edit like a pro. Post everywhere.</h1>
        <p class="lead">A multi-track timeline, CapCut-style animations, Premiere-style trimming and color grading — with ready-made templates sized for YouTube, Instagram and Facebook. Everything runs in your browser; your files never leave your device.</p>
      </div>
      <div class="hero-stats">
        <div><b>${FORMATS.length}</b><span>platform formats</span></div>
        <div><b>${TEMPLATES.length}</b><span>designed templates</span></div>
        <div><b>${LAYOUTS.length}</b><span>collage layouts</span></div>
      </div>
    </section>

    <section class="feature-intro">
      <div class="feat-copy">
        <p class="eyebrow">Your channel intro</p>
        <h2>MR DARK MEMORY</h2>
        <p class="lead">A ready-made cinematic intro for your channel — glitch title reveal, red light leak, film grain and a subscribe button. Open it, swap the background clip, and export.</p>
        <div class="btn-row">
          <button class="btn btn-primary" data-tpl="mdm-intro">${icon('play')}<span>Use YouTube intro (16:9)</span></button>
          <button class="btn" data-tpl="mdm-shorts-intro">${icon('smartphone')}<span>Shorts version (9:16)</span></button>
        </div>
      </div>
      <div class="feat-preview"><canvas data-thumb="mdm-intro" data-feature="1" aria-label="MR DARK MEMORY intro preview"></canvas></div>
    </section>

    <section class="home-section">
      <div class="section-head"><h2>Start with a blank canvas</h2>
        <div class="seg">${['YouTube', 'Instagram', 'Facebook'].map((p) => `<button class="${p === fmtFilter ? 'on' : ''}" data-fmtf="${p}">${p}</button>`).join('')}</div></div>
      <div class="fmt-grid">${fmts.map((f) => `<button class="fmt-card" data-fmt="${f.id}"><div class="fmt-vis">${formatShape(f)}</div><div><b>${f.name}</b><small>${f.note}</small></div></button>`).join('')}
        <button class="fmt-card collage-card" data-collage="${fmtFilter === 'YouTube' ? 'yt-thumb' : fmtFilter === 'Instagram' ? 'ig-post' : 'fb-feed'}"><div class="fmt-vis">${icon('layout-grid')}</div><div><b>Collage</b><small>${fmtFilter} sized</small></div></button>
      </div>
    </section>

    <section class="home-section">
      <div class="section-head"><h2>Templates</h2>
        <div class="seg">${PLATFORMS.map((p) => `<button class="${p === tplFilter ? 'on' : ''}" data-tplf="${p}">${p}</button>`).join('')}</div></div>
      <div class="tpl-grid">${tpls.map((t) => `<button class="tpl-card" data-tpl="${t.id}">
        <div class="tpl-thumb"><canvas data-thumb="${t.id}" aria-label="${esc(t.name)} preview"></canvas></div>
        <div class="tpl-meta"><span class="plat plat-${t.platform.toLowerCase()}">${t.platform}</span><b>${t.name}</b><small>${t.tag}</small></div></button>`).join('')}</div>
    </section>

    <section class="home-section tools-row">
      <button class="tool-card" id="home-thumb2"><span class="tool-ic">${icon('image-play')}</span><div><b>Thumbnail maker</b><small>32 designed templates for YouTube, Facebook and Instagram. Add your photo, big text and stickers.</small></div></button>
      <button class="tool-card" id="home-photo2"><span class="tool-ic">${icon('image')}</span><div><b>Photo editor</b><small>Adjust colour, apply filters, rotate, crop and draw. Then send the photo to a collage, thumbnail or video.</small></div></button>
    </section>

    <section class="home-section collage-promo">
      <div><h2>Collage maker</h2><p class="lead">${LAYOUTS.length} grid layouts with adjustable gaps, borders, rounded corners, filters and title overlays. Export a PNG or turn it into an animated video.</p>
      <button class="btn btn-primary" id="home-collage2">${icon('layout-grid')}<span>Open collage maker</span></button></div>
      <div class="layout-strip">${LAYOUTS.slice(0, 8).map((l) => `<svg viewBox="0 0 100 100">${l.r.map(([x, y, w, h]) => `<rect x="${x * 100 + 3}" y="${y * 100 + 3}" width="${w * 100 - 6}" height="${h * 100 - 6}" rx="5"/>`).join('')}</svg>`).join('')}</div>
    </section>
    <footer class="home-foot">Reelsmith · Works best in Chrome or Edge on desktop · Exports MP4/WebM video and PNG images</footer>
  </div>`;
}

export const LOGO = `<svg class="logo" viewBox="0 0 32 32" fill="none" aria-label="Reelsmith logo"><rect x="2.5" y="2.5" width="27" height="27" rx="8" stroke="currentColor" stroke-width="2.5"/><path d="M12 10.5v11l9-5.5-9-5.5Z" fill="#FF5A36"/><path d="M7 2.5v27M25 2.5v27" stroke="currentColor" stroke-width="2" stroke-dasharray="2.5 3"/></svg>`;

function renderHome() {
  const v = $('#view-home');
  v.innerHTML = homeHTML();
  icons();
  drawThumbs(v);
  const fc = v.querySelector('canvas[data-feature]'); if (fc) { fc.width = 960; fc.height = 540; animateThumb(fc); }
}

export function goHome() {
  document.querySelectorAll('.view').forEach((x) => (x.hidden = x.id !== 'view-home'));
  renderHome();
}

function bindHome() {
  const v = $('#view-home');
  v.addEventListener('click', (e) => {
    const f = e.target.closest('[data-fmt]');
    if (f) return openProject(newProject(FORMATS.find((x) => x.id === f.dataset.fmt)));
    const t = e.target.closest('[data-tpl]');
    if (t) { cache.delete(t.dataset.tpl); const tp = TEMPLATES.find((x) => x.id === t.dataset.tpl); openProject(tp.build()); return seek(tp.thumbT); }
    const ff = e.target.closest('[data-fmtf]'); if (ff) { fmtFilter = ff.dataset.fmtf; return renderHome(); }
    const tf = e.target.closest('[data-tplf]'); if (tf) { tplFilter = tf.dataset.tplf; return renderHome(); }
    const col = e.target.closest('[data-collage]'); if (col) return openCollage({ fmt: col.dataset.collage });
    if (e.target.closest('#home-collage, #home-collage2')) return openCollage();
    if (e.target.closest('#home-thumb, #home-thumb2')) return openThumbnail();
    if (e.target.closest('#home-photo, #home-photo2')) return openPhoto();
    if (e.target.closest('#home-blank')) return openProject(newProject(FORMATS[0]));
  });
  v.addEventListener('mouseover', (e) => { const cv = e.target.closest('.tpl-card')?.querySelector('canvas'); if (cv && !cv._anim) animateThumb(cv); });
  v.addEventListener('mouseout', (e) => {
    const card = e.target.closest('.tpl-card'); if (!card || card.contains(e.relatedTarget)) return;
    const cv = card.querySelector('canvas'); cv._anim = false;
    const tpl = TEMPLATES.find((t) => t.id === cv.dataset.thumb); const P = tplProject(tpl.id);
    renderFrame(cv.getContext('2d'), P, tpl.thumbT, { k: cv.width / P.w });
  });
}

async function boot() {
  document.querySelectorAll('.logo-slot').forEach((s) => (s.innerHTML = LOGO));
  const fonts = ['Anton', 'Bebas Neue', 'Montserrat', 'Poppins', 'Space Grotesk', 'Inter', 'Playfair Display', 'Pacifico', 'Permanent Marker', 'Oswald', 'Archivo Black', 'DM Serif Display'];
  const loads = [];
  for (const f of fonts) for (const w of ['400', '600', '700', '900']) loads.push(document.fonts.load(`${w} 40px "${f}"`).catch(() => {}));
  loads.push(document.fonts.load('italic 700 40px "Playfair Display"').catch(() => {}));
  await Promise.race([Promise.all(loads), new Promise((r) => setTimeout(r, 4000))]);
  await loadSamples();
  initEditor();
  initCollage();
  initThumbnail();
  initPhoto();
  bindHome();
  document.querySelectorAll('[data-home]').forEach((b) => (b.onclick = goHome));
  $('#boot').remove();
  goHome();
  icons();
  document.fonts.ready.then(() => { if (!$('#view-home').hidden) drawThumbs($('#view-home')); });
}
boot();

// Editor: preview, playback, panels, inspector, export
import { store, project, getClip, getTrack, select, selected, duration, commit, undo, redo, emit, on, uid, clamp, defaultClip, textDefaults, FORMATS, fmtTime } from './state.js';
import { library, getMedia, importFiles } from './media.js';
import { renderFrame, hitTest, clipBox, effTransform, FILTERS, ANIMS, COMBOS, EFFECTS, FX_TYPES, MASKS } from './render.js';
import { addDataImage } from './media.js';
import { TEMPLATES } from './templates.js';
import * as TL from './timeline.js';
import { icon, icons, toast, modal, closeModal, esc, download } from './ui.js';

let T = 0, playing = false, lastTs = 0, dirty = true, ds = 1, exporting = null;
const els = new Map();
const $ = (s, r = document) => r.querySelector(s);
const canvas = () => $('#preview');
let hiddenBox;

export const getT = () => T;
export function seek(t) { T = clamp(t, 0, duration()); dirty = true; }
export const requestDraw = () => (dirty = true);

// ---------- media elements & audio graph ----------
let actx = null, exportDest = null;
function ensureAudio() {
  if (!actx) {
    try {
      actx = new (window.AudioContext || window.webkitAudioContext)();
      exportDest = actx.createMediaStreamDestination();
      els.forEach(connectAudio);
    } catch (e) { console.warn(e); }
  }
  if (actx && actx.state === 'suspended') actx.resume();
}
function connectAudio(e) {
  if (!actx || e._node) return;
  try { e._node = actx.createMediaElementSource(e); e._node.connect(actx.destination); e._node.connect(exportDest); } catch (err) { console.warn(err); }
}
function elFor(c) {
  const m = getMedia(c.mediaId);
  if (!m || (m.type !== 'video' && m.type !== 'audio')) return null;
  let e = els.get(c.id);
  if (e && e._src === m.url) return e;
  e = document.createElement(m.type === 'audio' ? 'audio' : 'video');
  e.crossOrigin = 'anonymous'; e.preload = 'auto'; e.playsInline = true; e.src = m.url; e._src = m.url;
  e.addEventListener('seeked', requestDraw); e.addEventListener('loadeddata', requestDraw);
  hiddenBox.appendChild(e);
  els.set(c.id, e);
  connectAudio(e);
  return e;
}
function gcEls() {
  const ids = new Set(project().clips.map((c) => c.id));
  for (const [id, e] of els) if (!ids.has(id)) { e.pause(); e.remove(); els.delete(id); }
}
function getSource(c) {
  if (c.kind !== 'video') return null;
  const e = elFor(c);
  if (e && e.readyState >= 2) return { el: e, w: e.videoWidth, h: e.videoHeight };
  const m = getMedia(c.mediaId);
  return m?.el && m.el.readyState >= 2 ? { el: m.el, w: m.w, h: m.h } : null;
}
function syncMedia() {
  const P = project();
  for (const c of P.clips) {
    if (c.kind !== 'video' && c.kind !== 'audio') continue;
    const e = elFor(c); if (!e) continue;
    const tr = getTrack(c.trackId);
    const local = T - c.start;
    if (local < 0 || local >= c.dur) { if (!e.paused) e.pause(); continue; }
    const target = c.in + local * c.speed;
    let vol = c.volume ?? 1;
    if (c.fadeIn) vol *= clamp(local / c.fadeIn, 0, 1);
    if (c.fadeOut) vol *= clamp((c.dur - local) / c.fadeOut, 0, 1);
    e.volume = clamp(vol, 0, 1);
    e.muted = !!(tr?.muted || c.mute);
    e.playbackRate = c.speed || 1;
    if (playing) {
      if (e.paused) { e.currentTime = target; e.play().catch(() => {}); }
      else if (Math.abs(e.currentTime - target) > 0.3) e.currentTime = target;
    } else {
      if (!e.paused) e.pause();
      if (Math.abs(e.currentTime - target) > 0.04 && !e.seeking) e.currentTime = target;
    }
  }
}

// ---------- playback ----------
export function play() {
  ensureAudio();
  if (T >= duration() - 0.02) T = 0;
  playing = true; lastTs = performance.now();
  $('#btn-play').innerHTML = icon('pause');
  icons();
}
export function pause() {
  playing = false;
  els.forEach((e) => e.pause());
  const b = $('#btn-play'); if (b) { b.innerHTML = icon('play'); icons(); }
  dirty = true;
}
const toggle = () => (playing ? pause() : play());

function loop(ts) {
  if (store.project && !$('#view-editor').hidden) {
    if (playing) {
      T += (ts - lastTs) / 1000;
      const D = duration();
      if (T >= D) {
        if (exporting) { T = D; drawAll(); finishExport(); }
        else { T = D; pause(); }
      }
      dirty = true;
    }
    lastTs = ts;
    if (dirty) { syncMedia(); drawAll(); inspectorTick(); dirty = playing; }
  }
  requestAnimationFrame(loop);
}

function drawAll() {
  const P = project();
  const cv = canvas(), stage = $('#stage');
  const sw = stage.clientWidth - 32, sh = stage.clientHeight - 32;
  ds = Math.max(0.05, Math.min(sw / P.w, sh / P.h));
  const cw = Math.round(P.w * ds), ch = Math.round(P.h * ds);
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const iw = Math.min(P.w, Math.round(cw * dpr)), ih = Math.round(iw * P.h / P.w);
  if (cv.width !== iw || cv.height !== ih) { cv.width = iw; cv.height = ih; }
  cv.style.width = cw + 'px'; cv.style.height = ch + 'px';
  renderFrame(cv.getContext('2d'), P, T, { k: iw / P.w, getSource });
  if (exporting) renderFrame(exporting.ctx, P, T, { k: exporting.k, getSource });
  drawOverlay();
  TL.updatePlayhead(T);
  $('#timecode').textContent = fmtTime(T);
  $('#totaltime').textContent = fmtTime(duration());
}

// ---------- selection overlay & direct manipulation ----------
function drawOverlay() {
  const ov = $('#overlay'), cv = canvas();
  const c = selected();
  ov.style.left = cv.offsetLeft + 'px'; ov.style.top = cv.offsetTop + 'px';
  ov.style.width = cv.style.width; ov.style.height = cv.style.height;
  const box = $('#selbox');
  if (!c || c.kind === 'audio' || T < c.start || T >= c.start + c.dur || getTrack(c.trackId)?.hidden) { box.hidden = true; return; }
  const b = clipBox(c), tf = effTransform(c, T - c.start);
  box.hidden = false;
  box.classList.toggle('has-kf', !!c.kf?.length);
  box.style.left = tf.x * ds + 'px'; box.style.top = tf.y * ds + 'px';
  box.style.width = b.w * tf.scale * ds + 'px'; box.style.height = b.h * tf.scale * ds + 'px';
  box.style.transform = `translate(-50%,-50%) rotate(${tf.rotation}deg)`;
}

function setupStage() {
  const ov = $('#overlay');
  let drag = null;
  const pt = (e) => { const r = canvas().getBoundingClientRect(); return { x: (e.clientX - r.left) / ds, y: (e.clientY - r.top) / ds }; };
  $('#stage').addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    const P = project();
    const p = pt(e);
    const handle = e.target.closest('[data-h]')?.dataset.h;
    let c = selected();
    if (!handle) {
      const hit = hitTest(P, T, p.x, p.y);
      if (!hit) { select(null); return; }
      if (hit.id !== store.selectedId) select(hit.id);
      c = hit;
    }
    if (!c || getTrack(c.trackId)?.locked) return;
    e.preventDefault();
    $('#stage').setPointerCapture(e.pointerId);
    const snap = JSON.stringify(P);
    const tf = effTransform(c, T - c.start);
    drag = { mode: handle || 'move', c, p0: p, x0: tf.x, y0: tf.y, s0: tf.scale, r0: tf.rotation, snap, moved: false, cx: tf.x, cy: tf.y,
      a0: Math.atan2(p.y - tf.y, p.x - tf.x), d0: Math.hypot(p.x - tf.x, p.y - tf.y) || 1 };
  });
  $('#stage').addEventListener('pointermove', (e) => {
    if (!drag) return;
    const P = project(), c = drag.c, p = pt(e);
    drag.moved = true;
    const gx = $('#guide-x'), gy = $('#guide-y');
    if (drag.mode === 'move') {
      let nx = drag.x0 + (p.x - drag.p0.x), ny = drag.y0 + (p.y - drag.p0.y);
      const th = 8 / ds;
      gx.hidden = Math.abs(nx - P.w / 2) > th; gy.hidden = Math.abs(ny - P.h / 2) > th;
      if (!gx.hidden) nx = P.w / 2; if (!gy.hidden) ny = P.h / 2;
      setTF(c, { x: Math.round(nx), y: Math.round(ny) });
    } else if (drag.mode === 'rot') {
      let r = drag.r0 + ((Math.atan2(p.y - drag.cy, p.x - drag.cx) - drag.a0) * 180) / Math.PI;
      r = ((r + 540) % 360) - 180;
      for (const s of [-180, -90, 0, 90, 180]) if (Math.abs(r - s) < 4) r = s;
      setTF(c, { rotation: Math.round(r) });
    } else {
      setTF(c, { scale: clamp(+(drag.s0 * Math.hypot(p.x - drag.cx, p.y - drag.cy) / drag.d0).toFixed(3), 0.02, 20) });
    }
    dirty = true; syncInspectorTransform();
  });
  const end = () => {
    if (!drag) return;
    if (drag.moved) { store.history.push(drag.snap); store.future = []; }
    $('#guide-x').hidden = $('#guide-y').hidden = true;
    drag = null;
  };
  $('#stage').addEventListener('pointerup', end);
  $('#stage').addEventListener('pointercancel', end);
  // Drop media onto stage
  $('#stage').addEventListener('dragover', (e) => e.preventDefault());
  $('#stage').addEventListener('drop', async (e) => {
    e.preventDefault();
    const id = e.dataTransfer.getData('text/media');
    if (id) addMedia(id);
    else if (e.dataTransfer.files.length) { const added = await importFiles([...e.dataTransfer.files]); added.forEach((m) => addMedia(m.id)); }
  });
  new ResizeObserver(() => (dirty = true)).observe($('#stage'));
}

// ---------- duration / extend ----------
let rippleOn = true;
function maxDur(c) {
  if (c.kind === 'video' || c.kind === 'audio') { const m = getMedia(c.mediaId); if (m?.duration) return Math.max(0.1, (m.duration - c.in) / (c.speed || 1)); }
  return 3600;
}
export function setDur(c, d, ripple = rippleOn) {
  const P = project();
  d = clamp(+(+d).toFixed(3), 0.1, maxDur(c));
  const oldEnd = c.start + c.dur, delta = d - c.dur;
  if (Math.abs(delta) < 0.0005) return;
  if (ripple) P.clips.forEach((x) => { if (x.id !== c.id && x.trackId === c.trackId && x.start >= oldEnd - 0.001) x.start = Math.max(0, x.start + delta); });
  if (c.kf?.length) { const last = c.kf[c.kf.length - 1]; if (Math.abs(last.t - c.dur) < 0.02) last.t = d; }
  if (c.fxLen && c.fxStart + c.fxLen >= c.dur - 0.01) c.fxLen = Math.max(0.1, d - (c.fxStart || 0));
  c.dur = d;
}

// ---------- keyframes ----------
const KFP = ['x', 'y', 'scale', 'rotation', 'opacity'];
export function setTF(c, vals) {
  if (c.kf?.length) {
    const local = +(T - c.start).toFixed(3);
    const cur = effTransform(c, local);
    let k = c.kf.find((f) => Math.abs(f.t - local) < 1 / 60);
    if (!k) { k = { t: local, ...cur }; c.kf.push(k); c.kf.sort((a, b) => a.t - b.t); }
    Object.assign(k, vals);
  } else Object.assign(c, vals);
}
export function addKeyframe() {
  const c = selected();
  if (!c || c.kind === 'audio') return toast('Select a visual clip first');
  if (T < c.start || T > c.start + c.dur) return toast('Move the playhead over the clip to add a keyframe');
  commit();
  const local = +(T - c.start).toFixed(3);
  const cur = effTransform(c, local);
  c.kf = c.kf || [];
  const ex = c.kf.find((f) => Math.abs(f.t - local) < 1 / 60);
  if (ex) Object.assign(ex, cur); else c.kf.push({ t: local, ...cur });
  c.kf.sort((a, b) => a.t - b.t);
  toast(`Keyframe added at ${fmtTime(T)}${c.kf.length === 1 ? ' — move the playhead and change position/scale to animate' : ''}`);
  emit('project', {});
}

// ---------- freeze frame / detach audio / overlay ----------
export async function freezeFrame(holdDur = 2, style = 'plain') {
  const P = project();
  let c = selected();
  if (!c || (c.kind !== 'video' && c.kind !== 'image') || T < c.start || T >= c.start + c.dur)
    c = P.clips.find((x) => (x.kind === 'video' || x.kind === 'image') && T >= x.start && T < x.start + x.dur && !getTrack(x.trackId)?.hidden);
  if (!c) return toast('Put the playhead over a video clip to freeze a frame');
  let src;
  if (c.kind === 'video') { const e = elFor(c); if (!e || e.readyState < 2) return toast('Video frame not ready yet — try again'); src = { el: e, w: e.videoWidth, h: e.videoHeight }; }
  else { const m = getMedia(c.mediaId); src = { el: m.el, w: m.w, h: m.h }; }
  const s = Math.min(1, 1920 / src.w);
  const cv = document.createElement('canvas'); cv.width = Math.round(src.w * s); cv.height = Math.round(src.h * s);
  cv.getContext('2d').drawImage(src.el, 0, 0, cv.width, cv.height);
  let url;
  try { url = cv.toDataURL('image/jpeg', 0.92); } catch (e) { return toast('Could not capture this frame'); }
  const m = await addDataImage(url, 'Freeze ' + fmtTime(T, false));
  commit();
  const t = T;
  // split the clip at the playhead (if inside), then push everything after on that track
  if (t > c.start + 0.03 && t < c.start + c.dur - 0.03) {
    const b = JSON.parse(JSON.stringify(c)); b.id = uid('clip');
    const total = c.dur; c.dur = t - c.start; b.start = t; b.dur = total - c.dur; b.in = c.in + c.dur * (c.speed || 1);
    if (b.kf) b.kf = b.kf.map((k) => ({ ...k, t: k.t - c.dur }));
    c.animOut = { type: 'none', dur: 0.5 }; b.animIn = { type: 'none', dur: 0.5 };
    P.clips.push(b);
  }
  P.clips.forEach((x) => { if (x.trackId === c.trackId && x.start >= t - 0.001) x.start += holdDur; });
  const fz = JSON.parse(JSON.stringify(c));
  Object.assign(fz, { id: uid('clip'), kind: 'image', mediaId: m.id, start: t, dur: holdDur, in: 0, speed: 1, combo: 'none', animIn: { type: 'none', dur: 0.5 }, animOut: { type: 'none', dur: 0.5 }, volume: 1, fadeIn: 0, fadeOut: 0, effect: c.effect || 'none' });
  if (fz.kf) { const tf = effTransform(c, t - c.start); fz.kf = null; Object.assign(fz, tf); }
  fz.freeze = true; fz.freezeStyle = style;
  if (style === 'bw' || style === 'bw-zoom') fz.filter = 'mono';
  if (style === 'zoom' || style === 'bw-zoom' || style === 'flash-zoom') fz.kf = [{ t: 0, x: fz.x, y: fz.y, scale: fz.scale, rotation: fz.rotation || 0, opacity: fz.opacity ?? 1 }, { t: holdDur, x: fz.x, y: fz.y, scale: fz.scale * 1.18, rotation: fz.rotation || 0, opacity: fz.opacity ?? 1 }];
  if (style === 'shake') fz.combo = 'shake';
  if (style === 'glitch') fz.effect = 'glitch';
  P.clips.push(fz);
  if (style === 'flash' || style === 'flash-zoom') {
    const tr = findTrack('text', t, 0.45);
    P.clips.push(defaultClip({ kind: 'fx', fxType: 'flash', trackId: tr.id, start: t, dur: 0.45, x: P.w / 2, y: P.h / 2, w: P.w, h: P.h, color: '' }));
  }
  emit('project', {}); select(fz.id);
  toast(`Freeze frame added (${holdDur}s) — change its length under Timing`);
}
export function detachAudio() {
  const c = selected(); if (!c || c.kind !== 'video') return;
  commit();
  const tr = findTrack('audio', c.start, c.dur);
  const a = defaultClip({ kind: 'audio', mediaId: c.mediaId, trackId: tr.id, start: c.start, dur: c.dur, in: c.in, speed: c.speed, volume: c.volume, fadeIn: c.fadeIn, fadeOut: c.fadeOut });
  c.mute = true;
  project().clips.push(a);
  emit('project', {}); toast('Audio detached to its own track');
}
const LAYOUTS = {
  full: 'Full', left: 'Left half', right: 'Right half', top: 'Top half', bottom: 'Bottom half',
  'pip-tl': 'PIP ↖', 'pip-tr': 'PIP ↗', 'pip-bl': 'PIP ↙', 'pip-br': 'PIP ↘', center: 'Center card',
};
function applyLayout(c, key) {
  const P = project(), W = P.w, H = P.h;
  const m = getMedia(c.mediaId); const ar = m ? m.w / m.h : 16 / 9;
  c.scale = 1; c.rotation = 0; c.kf = null;
  const set = (x, y, w, h, r = 0) => Object.assign(c, { x, y, w, h, radius: r, fit: 'cover' });
  if (key === 'full') set(W / 2, H / 2, W, H);
  if (key === 'left') set(W / 4, H / 2, W / 2, H);
  if (key === 'right') set(W * 0.75, H / 2, W / 2, H);
  if (key === 'top') set(W / 2, H / 4, W, H / 2);
  if (key === 'bottom') set(W / 2, H * 0.75, W, H / 2);
  if (key === 'center') { const w = Math.min(W, H) * 0.7; set(W / 2, H / 2, w, w / Math.max(0.6, Math.min(1.8, ar)), 28); }
  if (key.startsWith('pip')) {
    const w = Math.min(W, H * 1.2) * 0.36, h = w / ar, mx = W * 0.04 + w / 2, my = H * 0.04 + h / 2;
    set(key.endsWith('l') ? mx : W - mx, key.includes('-t') ? my : H - my, w, h, 22);
  }
}
export function addOverlay(mediaId) {
  const m = getMedia(mediaId); if (!m || m.type === 'audio') return;
  commit();
  const P = project();
  const tr = addTrack('video');
  const c = defaultClip({ kind: m.type, mediaId, trackId: tr.id, start: T, dur: m.type === 'video' ? m.duration : 4, x: 0, y: 0, w: 100, h: 100 });
  P.clips.push(c);
  applyLayout(c, 'pip-tr');
  emit('project', {}); select(c.id);
  toast('Added as overlay — drag it, resize it, or pick a layout');
}

// ---------- track placement ----------
function overlaps(trackId, start, dur, ignore) {
  return project().clips.some((c) => c.trackId === trackId && c.id !== ignore && c.start < start + dur - 0.001 && c.start + c.dur > start + 0.001);
}
export function findTrack(type, start, dur) {
  const P = project();
  const want = type === 'audio' ? ['audio'] : type === 'text' ? ['text'] : ['video'];
  const list = P.tracks.filter((t) => want.includes(t.type) && !t.locked);
  const order = type === 'video' ? [...list].reverse() : list;
  for (const t of order) if (!overlaps(t.id, start, dur)) return t;
  return addTrack(want[0]);
}
export function addTrack(type) {
  const P = project();
  const n = P.tracks.filter((t) => t.type === type).length + 1;
  const tr = { id: uid('trk'), type, name: (type === 'audio' ? 'A' : type === 'text' ? 'T' : 'V') + n, muted: false, hidden: false, locked: false };
  if (type === 'audio') P.tracks.push(tr);
  else if (type === 'text') P.tracks.unshift(tr);
  else { const i = P.tracks.findIndex((t) => t.type === 'video'); P.tracks.splice(i < 0 ? 0 : i, 0, tr); }
  return tr;
}

function placeClip(o, type) {
  commit();
  const start = o.start ?? T;
  const tr = o.trackId ? getTrack(o.trackId) : findTrack(type, start, o.dur);
  const c = defaultClip({ ...o, start, trackId: tr.id });
  project().clips.push(c);
  emit('project', {}); select(c.id);
  return c;
}

export function addMedia(mediaId, at = {}) {
  const m = getMedia(mediaId), P = project();
  if (!m) return;
  if (m.type === 'audio') return placeClip({ kind: 'audio', mediaId, dur: Math.min(m.duration, 60), ...at }, 'audio');
  const base = { kind: m.type, mediaId, x: P.w / 2, y: P.h / 2, w: P.w, h: P.h, fit: 'cover' };
  if (m.type === 'video') return placeClip({ ...base, dur: m.duration, ...at }, 'video');
  return placeClip({ ...base, dur: 4, combo: 'ken-burns', ...at }, 'video');
}

// ---------- editing ops ----------
export function splitAt(t = T, ids = null) {
  const P = project();
  let targets = ids ? P.clips.filter((c) => ids.includes(c.id)) : selected() ? [selected()] : P.clips.filter((c) => t > c.start && t < c.start + c.dur);
  targets = targets.filter((c) => !getTrack(c.trackId)?.locked);
  targets = targets.filter((c) => t > c.start + 0.05 && t < c.start + c.dur - 0.05);
  if (!targets.length) return toast('Move the playhead over a clip to split it');
  commit();
  for (const c of targets) {
    const a = c.dur;
    const b = JSON.parse(JSON.stringify(c));
    b.id = uid('clip');
    c.dur = t - c.start;
    b.start = t; b.dur = a - c.dur; b.in = c.in + c.dur * (c.speed || 1);
    if (b.kf) b.kf = b.kf.map((k) => ({ ...k, t: k.t - c.dur }));
    c.animOut = { type: 'none', dur: 0.5 }; b.animIn = { type: 'none', dur: 0.5 };
    if (c.fadeOut) { b.fadeOut = c.fadeOut; c.fadeOut = 0; } b.fadeIn = 0;
    P.clips.push(b);
  }
  emit('project', {});
}
export function deleteSelected(ripple = false) {
  const c = selected(); if (!c) return;
  commit();
  const P = project();
  P.clips = P.clips.filter((x) => x.id !== c.id);
  if (ripple) P.clips.forEach((x) => { if (x.trackId === c.trackId && x.start >= c.start + c.dur - 0.001) x.start -= c.dur; });
  select(null); emit('project', {});
}
export function duplicateSelected() {
  const c = selected(); if (!c) return;
  commit();
  const d = JSON.parse(JSON.stringify(c)); d.id = uid('clip'); d.start = c.start + c.dur;
  if (overlaps(d.trackId, d.start, d.dur)) d.trackId = findTrack(c.kind === 'audio' ? 'audio' : (c.kind === 'text' || c.kind === 'shape') ? 'text' : 'video', d.start, d.dur).id;
  project().clips.push(d); emit('project', {}); select(d.id);
}

export function splitAll() {
  const P = project();
  const ids = P.clips.filter((c) => T > c.start + 0.05 && T < c.start + c.dur - 0.05 && !getTrack(c.trackId)?.locked).map((c) => c.id);
  if (!ids.length) return toast('Nothing under the playhead to split');
  splitAt(T, ids); toast(`Split ${ids.length} clip${ids.length === 1 ? '' : 's'} at ${fmtTime(T)}`);
}
// CapCut-style: delete the part of the selected clip left/right of the playhead
export function trimToPlayhead(side) {
  const c = selected() || project().clips.find((x) => T > x.start && T < x.start + x.dur && x.kind !== 'fx');
  if (!c || T <= c.start + 0.03 || T >= c.start + c.dur - 0.03) return toast('Put the playhead inside a clip first');
  commit();
  if (side === 'left') {
    const cut = T - c.start;
    c.in += cut * (c.speed || 1); c.start = T; c.dur -= cut;
    if (c.kf) c.kf = c.kf.map((k) => ({ ...k, t: k.t - cut }));
  } else c.dur = T - c.start;
  emit('project', {}); toast(side === 'left' ? 'Deleted everything before the playhead' : 'Deleted everything after the playhead');
}
let clipboard = null;
export function copySelected(cut = false) {
  const c = selected(); if (!c) return toast('Select a clip first');
  clipboard = JSON.parse(JSON.stringify(c));
  if (cut) { deleteSelected(); toast('Cut — press Ctrl+V to paste at the playhead'); }
  else toast('Copied — press Ctrl+V to paste at the playhead');
}
export function paste() {
  if (!clipboard) return toast('Nothing to paste yet');
  commit();
  const d = JSON.parse(JSON.stringify(clipboard)); d.id = uid('clip'); d.start = T;
  if (!getTrack(d.trackId) || overlaps(d.trackId, d.start, d.dur)) d.trackId = findTrack(d.kind === 'audio' ? 'audio' : ['text', 'shape', 'fx'].includes(d.kind) ? 'text' : 'video', d.start, d.dur).id;
  project().clips.push(d); emit('project', {}); select(d.id);
}
// clip to apply panel effects to: selection, else topmost visual clip under playhead
function targetClip() {
  const P = project(), c = selected();
  if (c && c.kind !== 'audio' && c.kind !== 'fx') return c;
  for (const tr of P.tracks) {
    if (tr.type === 'audio' || tr.hidden) continue;
    const hit = P.clips.find((x) => x.trackId === tr.id && x.kind !== 'fx' && T >= x.start && T < x.start + x.dur && (x.kind === 'image' || x.kind === 'video'));
    if (hit) return hit;
  }
  return P.clips.find((x) => x.kind !== 'audio' && x.kind !== 'fx' && T >= x.start && T < x.start + x.dur);
}
const EFFECT_INFO = { none: ['circle-off', 'None'], glitch: ['zap', 'Glitch'], 'rgb-split': ['layers-3', 'RGB split'], vhs: ['cassette-tape', 'VHS'], pixelate: ['grid-3x3', 'Pixelate'], mirror: ['flip-horizontal-2', 'Mirror'], flash: ['sun', 'Flash'], strobe: ['lightbulb', 'Strobe'], 'blur-pulse': ['circle-dashed', 'Blur pulse'], 'invert-flash': ['contrast', 'Invert flash'], duotone: ['paint-bucket', 'Duotone'] };
const MOTION_INFO = { none: 'circle-off', 'ken-burns': 'zoom-in', 'zoom-out-slow': 'zoom-out', 'pan-left': 'arrow-left', 'pan-right': 'arrow-right', pulse: 'activity', 'zoom-punch': 'maximize', heartbeat: 'heart-pulse', sway: 'waves', swing: 'rotate-ccw', float: 'cloud', 'bounce-loop': 'arrow-up-down', 'spin-loop': 'refresh-cw', handheld: 'camera', shake: 'vibrate', earthquake: 'mountain' };
const TRANSITIONS = [['fade', 'Fade', 'fade'], ['slide-left', 'Slide', 'slide-left'], ['zoom-in', 'Zoom', 'zoom-out'], ['spin', 'Spin', 'spin'], ['blur', 'Blur', 'blur'], ['wipe', 'Wipe', 'fade'], ['pop', 'Pop', 'zoom-out'], ['slide-up', 'Push up', 'slide-up']];

const FREEZE_STYLES = [['plain', 'snowflake', 'Freeze'], ['flash', 'sun', 'Flash freeze'], ['zoom', 'zoom-in', 'Zoom freeze'], ['flash-zoom', 'sparkles', 'Flash + zoom'], ['bw', 'contrast', 'B&W freeze'], ['bw-zoom', 'scan-search', 'B&W + zoom'], ['shake', 'vibrate', 'Shake freeze'], ['glitch', 'zap', 'Glitch freeze']];
let freezeDur = 2;
const freezeHTML = () => `<h4 class="sub">Freeze effect</h4>
  <p class="hint">Holds the frame at the playhead, then the video carries on. Pick how long to hold it:</p>
  <div class="chips">${[1, 2, 3, 5, 8].map((d) => `<button class="chip ${freezeDur === d ? 'on' : ''}" data-fdur="${d}">${d}s</button>`).join('')}</div>
  <div class="tile-grid">${FREEZE_STYLES.map(([k, ic, n]) => `<button class="fx-tile" data-freeze="${k}">${icon(ic)}<span>${n}</span></button>`).join('')}</div>`;
const fxTimingHTML = (c) => (c.effect && c.effect !== 'none') || (c.combo && c.combo !== 'none') ? `<h4 class="sub">Effect timing</h4>
  <p class="hint">Choose when the effect and motion play inside this clip — extend them to the whole clip or just a moment.</p>
  ${num('Starts at', 'fxStart', c.fxStart || 0, 0, Math.max(0.1, c.dur - 0.1), 0.05, 's')}
  ${num('Lasts', 'fxLen', c.fxLen || c.dur, 0.1, c.dur, 0.05, 's')}
  <div class="chips"><button class="chip" data-fxlen="0.5">0.5s</button><button class="chip" data-fxlen="1">1s</button><button class="chip" data-fxlen="2">2s</button><button class="chip" data-fxlen="3">3s</button><button class="chip" data-fxlen="all">Whole clip</button></div>` : '';

// ---------- Left panels ----------
const TEXT_PRESETS = [
  { name: 'Title', o: { text: 'BIG TITLE', font: 'Anton', size: 160, spacing: 2, shadow: true } },
  { name: 'Subtitle', o: { text: 'Subtitle goes here', font: 'Poppins', weight: 600, size: 64 } },
  { name: 'Caption', o: { text: 'auto style caption', font: 'Montserrat', weight: 900, size: 90, stroke: 8, strokeColor: '#000000', upper: true } },
  { name: 'Box label', o: { text: 'NEW VIDEO', font: 'Space Grotesk', weight: 700, size: 56, color: '#111111', bg: '#FFE600', bgPad: 22, bgRadius: 10 } },
  { name: 'Pill', o: { text: 'Link in bio', font: 'Poppins', weight: 600, size: 48, color: '#ffffff', bg: '#FF5A36', bgPad: 22, bgRadius: 999 } },
  { name: 'Neon', o: { text: 'Neon nights', font: 'Pacifico', size: 110, color: '#FFE3FF', shadow: true, shadowColor: '#FF2BD6' } },
  { name: 'Editorial', o: { text: 'Slow mornings.', font: 'Playfair Display', weight: 700, italic: true, size: 120 } },
  { name: 'Handwritten', o: { text: 'with love', font: 'Permanent Marker', size: 100, color: '#FFD3C2' } },
  { name: 'Lower third', o: { text: 'Alex Rivera\nTravel filmmaker', font: 'Poppins', weight: 600, size: 52, align: 'left', bg: 'rgba(12,12,16,0.82)', bgPad: 28, bgRadius: 6, lineHeight: 1.3 }, pos: 'lower' },
  { name: 'Subscribe', o: { text: 'SUBSCRIBE', font: 'Space Grotesk', weight: 700, size: 52, color: '#ffffff', bg: '#E5191E', bgPad: 22, bgRadius: 12 }, anim: 'pop', combo: 'pulse' },
];
const SHAPES = [
  ['rect', 'Rectangle', { w: 600, h: 340, fill: '#FF5A36' }], ['round', 'Rounded', { shape: 'rect', radius: 60, w: 600, h: 340, fill: '#ffffff' }],
  ['circle', 'Circle', { w: 360, h: 360, fill: '#FFE600' }], ['ring', 'Highlight ring', { shape: 'circle', w: 360, h: 360, fill: '', strokeW: 16, strokeC: '#FF2B2B' }],
  ['triangle', 'Triangle', { w: 360, h: 320, fill: '#3DDC97' }], ['star', 'Star', { w: 380, h: 380, fill: '#FFC83D' }],
  ['arrow', 'Arrow', { w: 420, h: 200, fill: '#E5191E', strokeW: 8, strokeC: '#ffffff' }], ['heart', 'Heart', { w: 360, h: 340, fill: '#FF3D7F' }],
  ['line', 'Bar', { shape: 'rect', w: 800, h: 14, fill: '#ffffff' }], ['progress', 'Progress bar', { shape: 'rect', w: 0, h: 16, fill: '#FF0033', anim: 'wipe' }],
];
const BACKGROUNDS = [
  ['#0E0E12'], ['#F3EDE4'], ['#FF5A36'], ['#FFE600'], ['#1F3BFF'], ['#C6FF3D'],
  ['#FF3D7F', '#7B2FF7', 60], ['#FFD400', '#FF7A00', 20], ['#00C6FF', '#0072FF', 135], ['#0E0E12', '#2A1430', 120], ['#F6D365', '#FDA085', 45], ['#43E97B', '#38F9D7', 90],
];

function panelHTML(name) {
  if (name === 'media') {
    const items = library.filter((m) => m.type !== 'audio').sort((a, b) => (a.sample ? 1 : 0) - (b.sample ? 1 : 0));
    return `<div class="panel-head"><h3>Media</h3><label class="btn btn-primary btn-sm">${icon('upload')}<span>Import</span><input type="file" id="file-in" multiple accept="video/*,image/*,audio/*"></label></div>
      <div class="dropzone" id="dropzone">${icon('film')}<span>Drop videos, photos or audio here</span></div>
      <div class="media-grid">${items.map(mediaCard).join('')}</div>`;
  }
  if (name === 'audio') {
    const items = library.filter((m) => m.type === 'audio').sort((a, b) => (a.sample ? 1 : 0) - (b.sample ? 1 : 0));
    return `<div class="panel-head"><h3>Audio</h3><label class="btn btn-sm">${icon('upload')}<span>Import</span><input type="file" id="file-in" multiple accept="audio/*"></label></div>
      <p class="hint">Royalty-free beats generated right in your browser. Drag onto an audio track or press +.</p>
      <div class="audio-list">${items.map((m) => `<div class="audio-item" draggable="true" data-media="${m.id}"><div class="audio-wave">${(m.peaks || []).filter((_, i) => i % 8 === 0).map((p) => `<i style="height:${Math.max(8, p * 100)}%"></i>`).join('')}</div><div class="audio-meta"><b>${esc(m.name)}</b><span>${m.note || ''} · ${fmtTime(m.duration, false)}</span></div><button class="icon-btn" data-add="${m.id}" aria-label="Add">${icon('plus')}</button></div>`).join('') || '<p class="hint">No audio yet.</p>'}</div>`;
  }
  if (name === 'text') {
    return `<div class="panel-head"><h3>Text</h3></div><div class="text-presets">${TEXT_PRESETS.map((p, i) => `<button class="text-preset" data-tp="${i}" style="font-family:'${p.o.font}';font-weight:${p.o.weight || 400};${p.o.italic ? 'font-style:italic;' : ''}${p.o.bg ? `background:${p.o.bg};color:${p.o.color};` : ''}${p.o.stroke ? 'color:#fff;-webkit-text-stroke:1px #000;paint-order:stroke;' : ''}">${esc(p.name === 'Lower third' ? 'Lower third' : p.o.text.split('\n')[0])}</button>`).join('')}</div>`;
  }
  if (name === 'elements') {
    return `<div class="panel-head"><h3>Elements</h3></div><div class="shape-grid">${SHAPES.map(([k, n, o], i) => `<button class="shape-btn" data-sh="${i}" title="${n}"><svg viewBox="-60 -60 120 120">${shapeSvg(o.shape || k, o)}</svg><span>${n}</span></button>`).join('')}</div>`;
  }
  if (name === 'effects') {
    const c = targetClip();
    const tile = (attr, k, ic, n, on) => `<button class="fx-tile ${on ? 'on' : ''}" ${attr}="${k}">${icon(ic)}<span>${n}</span></button>`;
    return `<div class="panel-head"><h3>Effects</h3></div>
      <div class="hint-box">${c ? `Applying to <b>${esc(c.kind === 'text' ? (c.text || 'Text').split('\n')[0] : getMedia(c.mediaId)?.name || nice(c.kind))}</b>. Select another clip on the timeline to change it.` : 'Select a clip on the timeline, or move the playhead over one.'}</div>
      ${freezeHTML()}
      <h4 class="sub">Video effects</h4>
      <div class="tile-grid">${EFFECTS.map((k) => tile('data-peffect', k, EFFECT_INFO[k][0], EFFECT_INFO[k][1], (c?.effect || 'none') === k)).join('')}</div>
      <h4 class="sub">Motion</h4>
      <div class="tile-grid">${COMBOS.map((k) => tile('data-pcombo', k, MOTION_INFO[k] || 'move', nice(k), (c?.combo || 'none') === k)).join('')}</div>
      <h4 class="sub">Transitions</h4>
      <p class="hint">Applies to the start of the clip and the end of the clip before it on the same track.</p>
      <div class="tile-grid">${TRANSITIONS.map(([k, n]) => tile('data-ptrans', k, 'between-vertical-start', n, c?.animIn?.type === k)).join('')}</div>
      ${c ? `<div class="hint-box">To make an effect last longer, open the clip's Effects tab on the right → Effect timing, or extend the clip under Edit → Timing.</div>` : ''}`;
  }
  if (name === 'overlays') {
    const prev = {
      'light-leak': 'radial-gradient(circle at 30% 40%, #ff9a3c, #ff3d7f 45%, #1a1a22 80%)', grain: 'repeating-radial-gradient(circle at 20% 30%, #777 0 1px, #333 1px 3px)',
      letterbox: 'linear-gradient(#000 0 22%, #3a5ea8 22% 78%, #000 78%)', scanlines: 'repeating-linear-gradient(#2a2a35 0 3px, #111 3px 6px)',
      vignette: 'radial-gradient(circle, #8aa 0 30%, #000 85%)', flash: 'linear-gradient(90deg, #fff, #3a3a44)', bokeh: 'radial-gradient(circle at 25% 40%, #ffcf6a 0 10%, transparent 11%), radial-gradient(circle at 70% 60%, #ff8a5c 0 14%, transparent 15%), #1a1a22',
      dust: 'linear-gradient(90deg, #6b5a45, #a89070)', snow: 'radial-gradient(circle at 30% 30%, #fff 0 3%, transparent 4%), radial-gradient(circle at 70% 60%, #fff 0 2%, transparent 3%), #2a3a55', 'color-tint': 'linear-gradient(135deg, #ff5a36, #7b2ff7)',
    };
    const vids = library.filter((m) => m.type !== 'audio').sort((a, b) => (a.sample ? 1 : 0) - (b.sample ? 1 : 0));
    return `<div class="panel-head"><h3>Overlays</h3></div>
      <p class="hint">Full-frame effect layers. They sit on top and affect everything below them on the timeline.</p>
      <div class="fx-grid">${Object.entries(FX_TYPES).map(([k, n]) => `<button class="fx-btn" data-fx="${k}"><i style="background:${prev[k]}"></i><span>${n}</span></button>`).join('')}</div>
      <h4 class="sub">Picture-in-picture</h4>
      <p class="hint">Layer a photo or video on top of your main clip. Tip: turn on Chroma key in the inspector to remove a green screen.</p>
      <div class="media-grid">${vids.map((m) => mediaCard(m, true)).join('')}</div>`;
  }
  if (name === 'bg') {
    return `<div class="panel-head"><h3>Backgrounds</h3></div><p class="hint">Adds a full-frame color layer on the bottom video track.</p><div class="bg-grid">${BACKGROUNDS.map(([a, b, ang], i) => `<button class="bg-sw" data-bg="${i}" style="background:${b ? `linear-gradient(${(ang || 0) + 90}deg, ${a}, ${b})` : a}" aria-label="Background ${i + 1}"></button>`).join('')}</div>`;
  }
  if (name === 'templates') {
    return `<div class="panel-head"><h3>Templates</h3></div><p class="hint">Replaces the current project.</p><div class="tpl-mini">${TEMPLATES.map((t) => `<button class="tpl-mini-item" data-tpl="${t.id}"><canvas data-thumb="${t.id}"></canvas><span><b>${t.name}</b><small>${t.platform} · ${t.tag}</small></span></button>`).join('')}</div>`;
  }
  return '';
}
function shapeSvg(shape, o) {
  const f = o.fill || 'none', s = o.strokeC || 'none', sw = o.strokeW ? 6 : 0;
  if (shape === 'circle') return `<circle r="44" fill="${f}" stroke="${s}" stroke-width="${sw}"/>`;
  if (shape === 'triangle') return `<path d="M0-44 50 40H-50Z" fill="${f}"/>`;
  if (shape === 'star') return `<path d="M0-48 12-15 46-15 18 6 29 40 0 19-29 40-18 6-46-15-12-15Z" fill="${f}"/>`;
  if (shape === 'arrow') return `<path d="M-50-10H15V-28L50 0 15 28V10H-50Z" fill="${f}" stroke="${s}" stroke-width="3"/>`;
  if (shape === 'heart') return `<path d="M0 36C-60-6-30-52 0-20 30-52 60-6 0 36Z" fill="${f}"/>`;
  if (o.h <= 16) return `<rect x="-50" y="-5" width="100" height="10" rx="3" fill="${f}"/>`;
  return `<rect x="-50" y="-30" width="100" height="60" rx="${o.radius ? 16 : 2}" fill="${f}"/>`;
}
function mediaCard(m, ovlOnly = false) {
  if (ovlOnly) return `<div class="media-card" data-ovl="${m.id}" title="Add as overlay"><img src="${m.thumb}" alt="${esc(m.name)}" loading="lazy" crossorigin="anonymous"><span class="badge">${m.type === 'video' ? fmtTime(m.duration, false) : 'Photo'}</span><span class="name">${esc(m.name)}</span></div>`;
  return `<div class="media-card" draggable="true" data-media="${m.id}">
    <button class="ovl" data-ovl="${m.id}" aria-label="Add as overlay" title="Add as overlay (picture-in-picture)">${icon('layers')}</button>
    <img src="${m.thumb}" alt="${esc(m.name)}" loading="lazy" crossorigin="anonymous">
    <span class="badge">${m.type === 'video' ? fmtTime(m.duration, false) : m.sample ? 'Stock' : 'Photo'}</span>
    <button class="add" data-add="${m.id}" aria-label="Add to timeline">${icon('plus')}</button>
    <span class="name">${esc(m.name)}</span></div>`;
}

let currentPanel = 'media';
export function showPanel(name) {
  currentPanel = name;
  document.querySelectorAll('.rail button').forEach((b) => b.classList.toggle('active', b.dataset.panel === name));
  const p = $('#panel');
  p.innerHTML = panelHTML(name);
  icons();
  if (name === 'templates') import('./app.js').then((a) => a.drawThumbs(p));
}
function setupPanels() {
  document.querySelectorAll('.rail button').forEach((b) => b.addEventListener('click', () => showPanel(b.dataset.panel)));
  const p = $('#panel');
  p.addEventListener('change', async (e) => {
    if (e.target.id === 'file-in') { const added = await importFiles([...e.target.files]); toast(`Imported ${added.length} file${added.length === 1 ? '' : 's'}`); showPanel(currentPanel); }
  });
  p.addEventListener('dragstart', (e) => { const id = e.target.closest('[data-media]')?.dataset.media; if (id) e.dataTransfer.setData('text/media', id); });
  p.addEventListener('dragover', (e) => { if (e.target.closest('#dropzone')) { e.preventDefault(); e.target.closest('#dropzone').classList.add('over'); } });
  p.addEventListener('dragleave', (e) => e.target.closest('#dropzone')?.classList.remove('over'));
  p.addEventListener('drop', async (e) => {
    if (!e.target.closest('#dropzone')) return;
    e.preventDefault();
    const added = await importFiles([...e.dataTransfer.files]);
    toast(`Imported ${added.length} file${added.length === 1 ? '' : 's'}`); showPanel(currentPanel);
  });
  p.addEventListener('click', (e) => {
    const P = project();
    const add = e.target.closest('[data-add]');
    if (add) return addMedia(add.dataset.add);
    const ovl = e.target.closest('[data-ovl]');
    if (ovl) return addOverlay(ovl.dataset.ovl);
    const fd = e.target.closest('[data-fdur]');
    if (fd) { freezeDur = +fd.dataset.fdur; return showPanel(currentPanel); }
    const fzb = e.target.closest('[data-freeze]');
    if (fzb) return freezeFrame(freezeDur, fzb.dataset.freeze);
    const pe = e.target.closest('[data-peffect], [data-pcombo], [data-ptrans]');
    if (pe) {
      const c = targetClip(); if (!c) return toast('Select a clip on the timeline first');
      commit();
      if (pe.dataset.peffect) c.effect = pe.dataset.peffect;
      if (pe.dataset.pcombo) c.combo = pe.dataset.pcombo;
      if (pe.dataset.ptrans) {
        const tr = TRANSITIONS.find((x) => x[0] === pe.dataset.ptrans);
        c.animIn = { type: tr[0], dur: 0.5 };
        const prev = P.clips.filter((x) => x.trackId === c.trackId && x.id !== c.id && Math.abs(x.start + x.dur - c.start) < 0.1)[0];
        if (prev) prev.animOut = { type: tr[2], dur: 0.5 };
      }
      if (store.selectedId !== c.id) select(c.id);
      emit('project', {});
      seek(Math.max(0, c.start - (pe.dataset.ptrans ? 0.6 : 0))); if (!playing) play();
      return showPanel('effects');
    }
    const fx = e.target.closest('[data-fx]');
    if (fx) {
      const k = fx.dataset.fx;
      return placeClip({ kind: 'fx', fxType: k, x: P.w / 2, y: P.h / 2, w: P.w, h: P.h, dur: k === 'flash' ? 0.5 : 5, opacity: k === 'grain' ? 0.5 : k === 'color-tint' ? 0.6 : 1, color: '' }, 'text');
    }
    const card = e.target.closest('.media-card');
    if (card) return addMedia(card.dataset.media);
    const tp = e.target.closest('[data-tp]');
    if (tp) {
      const pr = TEXT_PRESETS[+tp.dataset.tp];
      const lower = pr.pos === 'lower';
      return placeClip({ kind: 'text', ...textDefaults, ...pr.o, x: lower ? P.w * 0.3 : P.w / 2, y: lower ? P.h * 0.82 : P.h / 2, dur: 3, animIn: { type: pr.anim || (lower ? 'slide-right' : 'fade'), dur: 0.5 }, animOut: { type: 'fade', dur: 0.4 }, combo: pr.combo || 'none' }, 'text');
    }
    const sh = e.target.closest('[data-sh]');
    if (sh) {
      const [k, , o] = SHAPES[+sh.dataset.sh];
      const prog = k === 'progress';
      return placeClip({ kind: 'shape', shape: o.shape || k, x: P.w / 2, y: prog ? P.h - 24 : P.h / 2, radius: 0, ...o, w: prog ? P.w : o.w, start: prog ? 0 : T, dur: prog ? duration() : 3, animIn: { type: prog ? 'wipe' : 'pop', dur: prog ? duration() : 0.4 } }, 'text');
    }
    const bg = e.target.closest('[data-bg]');
    if (bg) {
      const [a, b, ang] = BACKGROUNDS[+bg.dataset.bg];
      const v = [...P.tracks].reverse().find((t) => t.type === 'video');
      const tr = overlaps(v.id, T, 5) ? addTrackBottomVideo() : v;
      return placeClip({ kind: 'solid', color: a, color2: b || '', angle: ang ?? 135, x: P.w / 2, y: P.h / 2, w: P.w, h: P.h, dur: 5, trackId: tr.id }, 'video');
    }
    const tpl = e.target.closest('[data-tpl]');
    if (tpl) {
      const t = TEMPLATES.find((x) => x.id === tpl.dataset.tpl);
      modal(`<h3>Replace project?</h3><p>Load the “${esc(t.name)}” template. You can undo this.</p><div class="modal-actions"><button class="btn" data-close>Cancel</button><button class="btn btn-primary" id="tpl-go">Load template</button></div>`);
      $('#tpl-go').onclick = () => { commit(); store.project = t.build(); select(null); T = t.thumbT; closeModal(); emit('project', { reason: 'load' }); };
    }
  });
}
function addTrackBottomVideo() {
  const P = project();
  const n = P.tracks.filter((t) => t.type === 'video').length + 1;
  const tr = { id: uid('trk'), type: 'video', name: 'V' + n, muted: false, hidden: false, locked: false };
  const lastV = P.tracks.map((t) => t.type).lastIndexOf('video');
  P.tracks.splice(lastV + 1, 0, tr);
  return tr;
}

// ---------- Inspector ----------
let inspTab = 'edit';
const FONTS = ['Anton', 'Bebas Neue', 'Montserrat', 'Poppins', 'Space Grotesk', 'Inter', 'Playfair Display', 'Pacifico', 'Permanent Marker', 'Oswald', 'Archivo Black', 'DM Serif Display'];
const num = (label, k, v, min, max, step = 1, unit = '') => `<label class="field"><span>${label}</span><div class="range"><input type="range" data-k="${k}" min="${min}" max="${max}" step="${step}" value="${v}"><input type="number" data-k="${k}" min="${min}" max="${max}" step="${step}" value="${+(+v).toFixed(2)}"><em>${unit}</em></div></label>`;
const color = (label, k, v) => `<label class="field field-inline"><span>${label}</span><input type="color" data-k="${k}" value="${toHex(v)}"></label>`;
const sel = (label, k, v, opts) => `<label class="field"><span>${label}</span><select data-k="${k}">${opts.map((o) => { const [val, txt] = Array.isArray(o) ? o : [o, o]; return `<option value="${val}" ${String(val) === String(v) ? 'selected' : ''}>${txt}</option>`; }).join('')}</select></label>`;
const chk = (label, k, v) => `<label class="toggle"><input type="checkbox" data-k="${k}" ${v ? 'checked' : ''}><span>${label}</span></label>`;
function toHex(c) { if (!c) return '#000000'; if (c.startsWith('#') && c.length === 7) return c; const d = document.createElement('canvas').getContext('2d'); d.fillStyle = c; return d.fillStyle.startsWith('#') ? d.fillStyle : '#000000'; }
const nice = (s) => s.replace(/-/g, ' ').replace(/^\w/, (m) => m.toUpperCase());

function renderInspector() {
  const el = $('#inspector'), c = selected(), P = project();
  if (!c) {
    el.innerHTML = `<div class="insp-head"><h3>Project</h3></div><div class="insp-body">
      <label class="field"><span>Name</span><input type="text" data-p="name" value="${esc(P.name)}"></label>
      <label class="field"><span>Format</span><select data-p="formatId">${FORMATS.map((f) => `<option value="${f.id}" ${f.id === P.formatId ? 'selected' : ''}>${f.platform} — ${f.name} (${f.w}×${f.h})</option>`).join('')}</select></label>
      <label class="field field-inline"><span>Canvas color</span><input type="color" data-p="bg" value="${toHex(P.bg)}"></label>
      <div class="stat-row"><div><small>Duration</small><b>${fmtTime(duration(), false)}</b></div><div><small>Clips</small><b>${P.clips.length}</b></div><div><small>Size</small><b>${P.w}×${P.h}</b></div></div>
      <div class="shortcuts"><h4>Shortcuts</h4>
      ${[['Space', 'Play / pause'], ['B', 'Cut tool (click clips)'], ['S', 'Split at playhead'], ['Shift+S', 'Split all tracks'], ['Q / W', 'Delete left / right of playhead'], ['Ctrl+X / C / V', 'Cut / copy / paste'], ['F', 'Freeze frame'], ['K', 'Add keyframe'], ['Del', 'Delete clip'], ['Shift+Del', 'Ripple delete'], ['Ctrl+D', 'Duplicate'], ['Ctrl+Z / Y', 'Undo / redo'], ['← →', 'Step one frame'], ['+ / −', 'Zoom timeline']].map(([k, d]) => `<div><kbd>${k}</kbd><span>${d}</span></div>`).join('')}</div>
      </div>`;
    icons();
    return;
  }
  const visual = c.kind !== 'audio';
  const tabs = [['edit', 'Edit']];
  if (c.kind === 'image' || c.kind === 'video' || c.kind === 'solid') tabs.push(['color', 'Color']);
  if (visual && c.kind !== 'fx') tabs.push(['effects', 'Effects']);
  if (visual) tabs.push(['animate', 'Animate']);
  if (c.kind === 'video' || c.kind === 'audio') tabs.push(['audio', 'Audio']);
  if (!tabs.find((t) => t[0] === inspTab)) inspTab = 'edit';
  const label = { image: 'Photo', video: 'Video', text: 'Text', shape: 'Shape', solid: 'Background', audio: 'Audio', fx: 'Overlay' }[c.kind] + (c.freeze ? ' · Freeze frame' : '');
  const tf = effTransform(c, clamp(T - c.start, 0, c.dur));
  let body = '';
  if (inspTab === 'edit') {
    if (c.kind === 'text') {
      body += `<label class="field"><span>Text</span><textarea data-k="text" rows="3">${esc(c.text)}</textarea></label>
        ${sel('Font', 'font', c.font, FONTS)}
        <div class="grid2">${sel('Weight', 'weight', c.weight, [[300, 'Light'], [400, 'Regular'], [500, 'Medium'], [600, 'Semibold'], [700, 'Bold'], [800, 'Extra bold'], [900, 'Black']])}${sel('Align', 'align', c.align, ['left', 'center', 'right'])}</div>
        ${num('Size', 'size', c.size, 12, 400)}
        ${num('Letter spacing', 'spacing', c.spacing, -10, 40)}
        ${num('Line height', 'lineHeight', c.lineHeight, 0.7, 2, 0.05)}
        <div class="grid2">${color('Color', 'color', c.color)}${chk('UPPERCASE', 'upper', c.upper)}</div>
        <div class="grid2">${chk('Italic', 'italic', c.italic)}${chk('Shadow / glow', 'shadow', c.shadow)}</div>
        ${c.shadow ? color('Glow color', 'shadowColor', c.shadowColor) : ''}
        <h4 class="sub">Outline</h4>${num('Stroke', 'stroke', c.stroke, 0, 30)}${c.stroke ? color('Stroke color', 'strokeColor', c.strokeColor) : ''}
        <h4 class="sub">Background box</h4>${chk('Show box', '_bgOn', !!c.bg)}${c.bg ? color('Box color', 'bg', c.bg) + num('Padding', 'bgPad', c.bgPad, 0, 80) + num('Corner radius', 'bgRadius', Math.min(c.bgRadius, 200), 0, 200) : ''}`;
    }
    if (c.kind === 'shape') {
      body += `${sel('Shape', 'shape', c.shape, ['rect', 'circle', 'triangle', 'star', 'arrow', 'heart'])}
        <div class="grid2">${num('Width', 'w', c.w, 2, P.w * 2)}${num('Height', 'h', c.h, 2, P.h * 2)}</div>
        ${chk('Fill', '_fillOn', !!c.fill)}${c.fill ? color('Fill color', 'fill', c.fill) : ''}
        ${num('Outline', 'strokeW', c.strokeW || 0, 0, 40)}${c.strokeW ? color('Outline color', 'strokeC', c.strokeC || '#ffffff') : ''}
        ${c.shape === 'rect' ? num('Corner radius', 'radius', c.radius || 0, 0, 400) : ''}`;
    }
    if (c.kind === 'solid') {
      body += `${color('Color', 'color', c.color)}${chk('Gradient', '_gradOn', !!c.color2)}${c.color2 ? color('Color 2', 'color2', c.color2) + num('Angle', 'angle', c.angle ?? 135, 0, 360, 1, '°') : ''}
       <div class="grid2">${num('Width', 'w', c.w, 2, P.w * 2)}${num('Height', 'h', c.h, 2, P.h * 2)}</div>${num('Corner radius', 'radius', c.radius || 0, 0, 600)}`;
    }
    if (c.kind === 'image' || c.kind === 'video') {
      body += `${sel('Fit', 'fit', c.fit, [['cover', 'Fill frame (crop)'], ['contain', 'Fit (letterbox)'], ['fill', 'Stretch']])}
       <div class="grid2">${num('Box width', 'w', c.w, 2, P.w * 2)}${num('Box height', 'h', c.h, 2, P.h * 2)}</div>
       ${num('Corner radius', 'radius', c.radius || 0, 0, 600)}
       <div class="grid2">${chk('Flip horizontal', 'flipH', c.flipH)}${chk('Flip vertical', 'flipV', c.flipV)}</div>
       <h4 class="sub">Layout · split screen · PIP</h4>
       <div class="layout-grid">${Object.entries(LAYOUTS).map(([k, n]) => `<button class="layout-btn" data-layout="${k}" title="${n}"><b style="${layoutIcon(k)}"></b></button>`).join('')}</div>
       ${sel('Mask', 'mask', c.mask || 'none', MASKS.map((m) => [m, nice(m)]))}
       <h4 class="sub">Chroma key (green screen)</h4>
       ${chk('Remove background color', 'chroma.on', c.chroma?.on)}
       ${c.chroma?.on ? color('Key color', 'chroma.color', c.chroma.color || '#00ff00') + num('Tolerance', 'chroma.tol', c.chroma.tol ?? 35, 0, 100) + num('Edge softness', 'chroma.soft', c.chroma.soft ?? 20, 0, 100) : ''}
       <h4 class="sub">Tools</h4>
       <div class="btn-row"><button class="btn btn-sm" data-act="freeze">${icon('snowflake')}<span>Freeze frame</span></button><button class="btn btn-sm" data-act="split">${icon('scissors')}<span>Split</span></button>${c.kind === 'video' ? `<button class="btn btn-sm" data-act="detach">${icon('audio-lines')}<span>Detach audio</span></button>` : ''}</div>`;
    }
    if (c.kind === 'fx') {
      body += `${sel('Overlay', 'fxType', c.fxType, Object.entries(FX_TYPES))}
        ${['light-leak', 'letterbox', 'vignette', 'flash', 'color-tint'].includes(c.fxType) ? color('Color', 'color', c.color || ({ 'light-leak': '#ff8c3c', letterbox: '#000000', vignette: '#000000', flash: '#ffffff', 'color-tint': '#ff5a36' })[c.fxType]) : ''}
        ${num('Intensity', 'opacity', c.opacity, 0, 1, 0.01)}
        ${sel('Blend', 'blend', c.blend || 'source-over', [['source-over', 'Normal'], ['screen', 'Screen'], ['overlay', 'Overlay'], ['soft-light', 'Soft light'], ['multiply', 'Multiply']])}
        <div class="btn-row"><button class="btn btn-sm" data-act="fx-full">Stretch to whole video</button></div>`;
    }
    if (visual && c.kind !== 'fx') {
      body += `<h4 class="sub">Transform${c.kf?.length ? ' <small style="color:#FFE600">· keyframed</small>' : ''}</h4>
        <div class="grid2">${num('X', 'x', Math.round(tf.x), -P.w, P.w * 2)}${num('Y', 'y', Math.round(tf.y), -P.h, P.h * 2)}</div>
        ${num('Scale', 'scale', tf.scale, 0.05, 5, 0.01, '×')}${num('Rotation', 'rotation', tf.rotation, -180, 180, 1, '°')}${num('Opacity', 'opacity', tf.opacity, 0, 1, 0.01)}
        ${sel('Blend', 'blend', c.blend || 'source-over', [['source-over', 'Normal'], ['multiply', 'Multiply'], ['screen', 'Screen'], ['overlay', 'Overlay'], ['soft-light', 'Soft light'], ['lighten', 'Lighten'], ['darken', 'Darken'], ['difference', 'Difference']])}
        <div class="btn-row"><button class="btn btn-sm" data-act="center">Center</button><button class="btn btn-sm" data-act="reset-t">Reset transform</button></div>`;
    }
    body += timingHTML(c) + `${c.kind === 'video' ? num('Speed', 'speed', c.speed, 0.25, 4, 0.05, '×') : ''}`;
  }
  if (inspTab === 'color') {
    const m = getMedia(c.mediaId);
    const thumb = m?.thumb;
    body += `<h4 class="sub">Filters</h4><div class="filter-grid">${Object.entries(FILTERS).map(([k, f]) => `<button class="filter-chip ${c.filter === k ? 'on' : ''}" data-filter="${k}">${thumb ? `<img src="${thumb}" alt="" style="filter:${cssFilter(f)}">` : `<i style="background:${c.color || '#888'};filter:${cssFilter(f)}"></i>`}<span>${f.label}</span></button>`).join('')}</div>
      <h4 class="sub">Adjust</h4>
      ${num('Brightness', 'adj.brightness', c.adj.brightness, -100, 100)}${num('Contrast', 'adj.contrast', c.adj.contrast, -100, 100)}${num('Saturation', 'adj.saturation', c.adj.saturation, -100, 100)}
      ${num('Hue', 'adj.hue', c.adj.hue, -180, 180, 1, '°')}${num('Temperature', 'adj.temp', c.adj.temp, -60, 60)}${num('Vignette', 'adj.vignette', c.adj.vignette, 0, 1, 0.01)}${num('Blur', 'adj.blur', c.adj.blur, 0, 10, 0.1)}
      <div class="btn-row"><button class="btn btn-sm" data-act="reset-color">Reset color</button></div>`;
  }
  if (inspTab === 'animate') {
    const chips = (k, v, list) => `<div class="chips">${list.map((a) => `<button class="chip ${v === a ? 'on' : ''}" data-anim="${k}" data-v="${a}">${nice(a)}</button>`).join('')}</div>`;
    const inList = c.kind === 'text' ? ANIMS : ANIMS.filter((a) => a !== 'typewriter');
    body += `<h4 class="sub">In</h4>${chips('animIn', c.animIn.type, inList)}${num('In duration', 'animIn.dur', c.animIn.dur, 0.1, Math.max(0.2, c.dur), 0.05, 's')}
      <h4 class="sub">Out</h4>${chips('animOut', c.animOut.type, inList)}${num('Out duration', 'animOut.dur', c.animOut.dur, 0.1, Math.max(0.2, c.dur), 0.05, 's')}

      <h4 class="sub">Keyframes</h4>
      <div class="hint-box">Animate position, scale, rotation and opacity: add a keyframe, move the playhead, then drag the clip or change values — Reelsmith creates the motion in between.</div>
      <div class="btn-row"><button class="btn btn-sm btn-primary" data-act="kf-add">${icon('diamond')}<span>Add keyframe</span></button>${c.kf?.length ? `<button class="btn btn-sm" data-act="kf-clear">Clear all</button>` : ''}</div>
      ${c.kf?.length ? `<div class="kf-list">${c.kf.map((k, i) => `<div class="kf-row"><span class="d"></span><button class="go" data-kfgo="${i}">${fmtTime(c.start + k.t)}</button><small>${Math.round(k.x)}, ${Math.round(k.y)} · ${(+k.scale).toFixed(2)}×</small><button class="icon-btn" data-kfdel="${i}" aria-label="Delete keyframe">${icon('x')}</button></div>`).join('')}</div>` : ''}
      <div class="btn-row"><button class="btn btn-sm" data-kfpreset="zoom-in">Zoom in</button><button class="btn btn-sm" data-kfpreset="zoom-out">Zoom out</button><button class="btn btn-sm" data-kfpreset="pan">Pan across</button><button class="btn btn-sm" data-kfpreset="fly">Fly in</button></div>`;
  }
  if (inspTab === 'effects') {
    const chips = (attr, v, list) => `<div class="chips">${list.map((a) => `<button class="chip ${v === a ? 'on' : ''}" ${attr}="${a}">${nice(a)}</button>`).join('')}</div>`;
    body += `<h4 class="sub">Video effects</h4>${chips('data-effect', c.effect || 'none', EFFECTS)}
      ${c.effect && c.effect !== 'none' ? num('Effect intensity', 'effectAmt', c.effectAmt ?? 1, 0, 2, 0.05) : ''}
      ${c.effect === 'duotone' ? color('Duotone color', 'effectColor', c.effectColor || '#ff5a36') : ''}
      <h4 class="sub">Motion effects</h4>${chips('data-combo', c.combo || 'none', COMBOS)}
      ${fxTimingHTML(c)}
      ${c.kind === 'video' || c.kind === 'image' ? freezeHTML() : ''}
      <div class="hint-box">Effects stack with filters, animations and keyframes. Add an overlay from the Overlays panel for light leaks, grain and cinema bars.</div>`;
  }
  if (inspTab === 'audio') {
    body += `${num('Volume', 'volume', c.volume, 0, 1, 0.01)}${num('Fade in', 'fadeIn', c.fadeIn, 0, 10, 0.1, 's')}${num('Fade out', 'fadeOut', c.fadeOut, 0, 10, 0.1, 's')}
     ${c.kind === 'video' ? chk('Mute clip audio', 'mute', c.mute) : ''}
     ${timingHTML(c)}${num('Source in', 'in', c.in, 0, 3600, 0.01, 's')}`;
  }
  el.innerHTML = `<div class="insp-head"><h3>${label}</h3><div class="insp-actions"><button class="icon-btn" data-act="dup" title="Duplicate (Ctrl+D)">${icon('copy')}</button><button class="icon-btn" data-act="del" title="Delete">${icon('trash-2')}</button></div></div>
    <div class="tabs">${tabs.map(([k, n]) => `<button class="tab ${k === inspTab ? 'on' : ''}" data-tab="${k}">${n}</button>`).join('')}</div>
    <div class="insp-body">${body}</div>`;
  icons();
}
function cssFilter(f) {
  const p = [];
  if (f.brightness) p.push(`brightness(${1 + f.brightness / 100})`);
  if (f.contrast) p.push(`contrast(${1 + f.contrast / 100})`);
  if (f.saturation) p.push(`saturate(${Math.max(0, 1 + f.saturation / 100)})`);
  if (f.hue) p.push(`hue-rotate(${f.hue}deg)`);
  if (f.sepia) p.push(`sepia(${f.sepia / 100})`);
  if (f.temp > 0) p.push(`sepia(${f.temp / 200})`);
  return p.join(' ') || 'none';
}
function timingHTML(c) {
  const what = c.freeze ? 'freeze' : c.kind === 'text' ? 'text' : c.kind === 'fx' ? 'overlay' : 'clip';
  return `<h4 class="sub">Timing · extend ${what}</h4>
    <div class="grid2">${num('Start', 'start', c.start, 0, 3600, 0.01, 's')}${num('Duration', 'dur', c.dur, 0.1, Math.min(3600, maxDur(c)), 0.01, 's')}</div>
    <div class="chips dur-chips">${[1, 2, 3, 5, 10].map((d) => `<button class="chip ${Math.abs(c.dur - d) < 0.01 ? 'on' : ''}" data-dur="${d}">${d}s</button>`).join('')}
      <button class="chip" data-dadd="-0.5">−0.5s</button><button class="chip" data-dadd="0.5">+0.5s</button><button class="chip" data-dadd="1">+1s</button></div>
    <div class="btn-row"><button class="btn btn-sm" data-act="dur-end">${icon('arrow-right-to-line')}<span>Extend to end</span></button><button class="btn btn-sm" data-act="dur-match">${icon('align-horizontal-justify-center')}<span>Match clip below</span></button></div>
    ${chk('Push later clips when extending', '_ripple', rippleOn)}
    <p class="hint">You can also drag the right edge of the clip on the timeline to stretch it.</p>`;
}
function layoutIcon(k) {
  const m = { full: 'inset:3px', left: 'left:3px;top:3px;bottom:3px;width:44%', right: 'right:3px;top:3px;bottom:3px;width:44%', top: 'left:3px;right:3px;top:3px;height:44%', bottom: 'left:3px;right:3px;bottom:3px;height:44%',
    'pip-tl': 'left:4px;top:4px;width:40%;height:34%', 'pip-tr': 'right:4px;top:4px;width:40%;height:34%', 'pip-bl': 'left:4px;bottom:4px;width:40%;height:34%', 'pip-br': 'right:4px;bottom:4px;width:40%;height:34%', center: 'inset:22%;border-radius:4px' };
  return m[k];
}
function syncInspectorTransform() {
  const c = selected(); if (!c) return;
  const tf = effTransform(c, clamp(T - c.start, 0, c.dur));
  ['x', 'y', 'scale', 'rotation', 'opacity'].forEach((k) => document.querySelectorAll(`#inspector [data-k="${k}"]`).forEach((i) => (i.value = i.type === 'number' ? +(+tf[k]).toFixed(2) : tf[k])));
}
let lastInspT = -1;
export function inspectorTick() {
  const c = selected();
  if (c?.kf?.length && Math.abs(T - lastInspT) > 1 / 120) { lastInspT = T; syncInspectorTransform(); }
}

function setupInspector() {
  const el = $('#inspector');
  let pending = null;
  el.addEventListener('focusin', () => { pending = JSON.stringify(project()); });
  el.addEventListener('pointerdown', () => { pending = JSON.stringify(project()); });
  const setVal = (c, k, v) => {
    if (k.includes('.')) { const [a, b] = k.split('.'); c[a] = { ...c[a], [b]: v }; } else c[k] = v;
  };
  el.addEventListener('input', (e) => {
    const t = e.target, c = selected(), P = project();
    if (t.dataset.p) {
      if (t.dataset.p === 'name') { P.name = t.value; $('#proj-name').value = t.value; }
      if (t.dataset.p === 'bg') P.bg = t.value;
      dirty = true; return;
    }
    const k = t.dataset.k; if (!k || !c) return;
    let v = t.type === 'checkbox' ? t.checked : t.type === 'range' || t.type === 'number' ? parseFloat(t.value) : t.value;
    if (typeof v === 'number' && isNaN(v)) return;
    if (k === '_bgOn') { c.bg = v ? 'rgba(0,0,0,0.75)' : ''; renderInspector(); }
    else if (k === '_fillOn') { c.fill = v ? '#ffffff' : ''; renderInspector(); }
    else if (k === '_gradOn') { c.color2 = v ? '#7B2FF7' : ''; renderInspector(); }
    else if (k === 'weight') setVal(c, k, +v);
    else if (k === '_ripple') { rippleOn = v; return; }
    else if (k === 'dur') { setDur(c, v); TL.render(); }
    else if (['x', 'y', 'scale', 'rotation', 'opacity'].includes(k) && c.kf?.length && c.kind !== 'fx') setTF(c, { [k]: v });
    else setVal(c, k, v);
    // mirror range <-> number
    el.querySelectorAll(`[data-k="${k}"]`).forEach((o) => { if (o !== t && o.type !== 'checkbox') o.value = o.type === 'number' ? +(+v).toFixed(2) : v; });
    if (['start', 'dur', 'speed', 'in'].includes(k)) TL.render();
    if (t.type === 'checkbox' && !k.startsWith('_')) renderInspector();
    if (k === 'text') TL.render();
    dirty = true;
  });
  el.addEventListener('change', (e) => {
    const t = e.target;
    if (t.dataset.p === 'formatId') {
      const f = FORMATS.find((x) => x.id === t.value), P = project();
      store.history.push(pending || JSON.stringify(P)); store.future = [];
      const sx = f.w / P.w, sy = f.h / P.h;
      P.clips.forEach((c) => { if (c.kind === 'audio') return; c.x *= sx; c.y *= sy; const full = Math.abs(c.w - P.w) < 2 && Math.abs(c.h - P.h) < 2; if (full) { c.w = f.w; c.h = f.h; } else c.scale *= Math.min(sx, sy); });
      P.w = f.w; P.h = f.h; P.formatId = f.id;
      emit('project', {}); toast(`Canvas changed to ${f.platform} ${f.name}`);
      pending = null; return;
    }
    if (pending && pending !== JSON.stringify(project())) { store.history.push(pending); store.future = []; }
    pending = JSON.stringify(project());
    if (['shape', 'stroke', 'strokeW', 'fxType', 'mask'].includes(t.dataset.k)) renderInspector();
    TL.render();
  });
  el.addEventListener('click', (e) => {
    const c = selected(), P = project();
    const tab = e.target.closest('[data-tab]');
    if (tab) { inspTab = tab.dataset.tab; return renderInspector(); }
    const f = e.target.closest('[data-filter]');
    if (f && c) { commit(); c.filter = f.dataset.filter; dirty = true; return renderInspector(); }
    const fd2 = e.target.closest('[data-fdur]');
    if (fd2) { freezeDur = +fd2.dataset.fdur; return renderInspector(); }
    const fz2 = e.target.closest('[data-freeze]');
    if (fz2) return freezeFrame(freezeDur, fz2.dataset.freeze);
    const fl = e.target.closest('[data-fxlen]');
    if (fl && c) { commit(); if (fl.dataset.fxlen === 'all') { c.fxStart = 0; c.fxLen = 0; } else { c.fxStart = Math.min(c.fxStart || 0, Math.max(0, c.dur - 0.1)); c.fxLen = Math.min(+fl.dataset.fxlen, c.dur - (c.fxStart || 0)); } dirty = true; return renderInspector(); }
    const dch = e.target.closest('[data-dur], [data-dadd]');
    if (dch && c) {
      commit();
      setDur(c, dch.dataset.dur ? +dch.dataset.dur : c.dur + +dch.dataset.dadd);
      emit('project', {}); toast(`Duration: ${c.dur.toFixed(1)}s`); return;
    }
    const lay = e.target.closest('[data-layout]');
    if (lay && c) { commit(); applyLayout(c, lay.dataset.layout); dirty = true; TL.render(); return renderInspector(); }
    const ef = e.target.closest('[data-effect]');
    if (ef && c) { commit(); c.effect = ef.dataset.effect; dirty = true; TL.render(); if (!playing && c.effect !== 'none') { if (T < c.start || T >= c.start + c.dur) seek(c.start); play(); } return renderInspector(); }
    const cb = e.target.closest('[data-combo]');
    if (cb && c) { commit(); c.combo = cb.dataset.combo; dirty = true; TL.render(); if (!playing && c.combo !== 'none') { seek(c.start); play(); } return renderInspector(); }
    const kg = e.target.closest('[data-kfgo]');
    if (kg && c) { pause(); seek(c.start + c.kf[+kg.dataset.kfgo].t); return renderInspector(); }
    const kd = e.target.closest('[data-kfdel]');
    if (kd && c) { commit(); c.kf.splice(+kd.dataset.kfdel, 1); if (!c.kf.length) c.kf = null; dirty = true; TL.render(); return renderInspector(); }
    const kp = e.target.closest('[data-kfpreset]');
    if (kp && c) {
      commit();
      const d = c.dur, cur = effTransform(c, 0), base = { x: c.kf?.length ? cur.x : c.x, y: c.kf?.length ? cur.y : c.y, scale: c.scale || 1, rotation: c.rotation || 0, opacity: c.opacity ?? 1 };
      const pr = kp.dataset.kfpreset;
      if (pr === 'zoom-in') c.kf = [{ t: 0, ...base }, { t: d, ...base, scale: base.scale * 1.35 }];
      if (pr === 'zoom-out') c.kf = [{ t: 0, ...base, scale: base.scale * 1.35 }, { t: d, ...base }];
      if (pr === 'pan') c.kf = [{ t: 0, ...base, scale: base.scale * 1.25, x: base.x + P.w * 0.1 }, { t: d, ...base, scale: base.scale * 1.25, x: base.x - P.w * 0.1 }];
      if (pr === 'fly') c.kf = [{ t: 0, ...base, x: base.x - P.w * 0.6, rotation: -12, opacity: 0 }, { t: Math.min(0.8, d / 2), ...base }, { t: d, ...base }];
      c.combo = 'none'; dirty = true; TL.render(); seek(c.start); if (!playing) play();
      toast('Keyframe motion applied'); return renderInspector();
    }
    const an = e.target.closest('[data-anim]');
    if (an && c) {
      commit();
      const k = an.dataset.anim, v = an.dataset.v;
      if (k === 'combo') c.combo = v; else c[k] = { ...c[k], type: v };
      // preview the animation
      if (k === 'animIn') seek(c.start); else if (k === 'animOut') seek(Math.max(c.start, c.start + c.dur - c[k].dur - 0.3)); else seek(c.start);
      if (!playing) play();
      return renderInspector();
    }
    const act = e.target.closest('[data-act]')?.dataset.act;
    if (!act) return;
    if (act === 'del') return deleteSelected();
    if (act === 'dup') return duplicateSelected();
    if (act === 'freeze') return freezeFrame();
    if (act === 'split') return splitAt();
    if (act === 'detach') return detachAudio();
    if (act === 'kf-add') { addKeyframe(); return renderInspector(); }
    if (!c) return;
    if (act === 'kf-clear') { commit(); const tf = effTransform(c, clamp(T - c.start, 0, c.dur)); c.kf = null; Object.assign(c, tf); dirty = true; TL.render(); return renderInspector(); }
    commit();
    if (act === 'center') { c.x = P.w / 2; c.y = P.h / 2; }
    if (act === 'reset-t') { c.rotation = 0; c.scale = 1; c.opacity = 1; c.x = P.w / 2; c.y = P.h / 2; }
    if (act === 'dur-end') {
      const end = Math.max(...P.clips.filter((x) => x.id !== c.id && x.trackId !== c.trackId).map((x) => x.start + x.dur), c.start + c.dur);
      const next = P.clips.filter((x) => x.trackId === c.trackId && x.id !== c.id && x.start >= c.start + c.dur - 0.001).sort((a, b) => a.start - b.start)[0];
      const lim = next ? Math.min(next.start, Math.max(end, next.start)) : end;
      if (lim - c.start > c.dur + 0.01) setDur(c, lim - c.start, false); else if (next) return toast('The next clip on this track is in the way — move it or extend with the duration buttons'); else return toast('Already reaches the end of the video');
      emit('project', {}); return toast(`Extended to ${fmtTime(c.start + c.dur, false)}`);
    }
    if (act === 'dur-match') {
      const idx = P.tracks.findIndex((t) => t.id === c.trackId);
      const below = P.clips.filter((x) => x.id !== c.id && P.tracks.findIndex((t) => t.id === x.trackId) > idx && x.kind !== 'audio' && x.start < c.start + c.dur && x.start + x.dur > c.start).sort((a, b) => P.tracks.findIndex((t) => t.id === a.trackId) - P.tracks.findIndex((t) => t.id === b.trackId))[0];
      if (!below) return toast('No clip below this one');
      c.start = below.start; setDur(c, below.dur); emit('project', {}); return toast('Matched the clip below');
    }
    if (act === 'fx-full') { c.start = 0; c.dur = Math.max(1, duration()); TL.render(); }
    if (act === 'fill') { c.x = P.w / 2; c.y = P.h / 2; c.w = P.w; c.h = P.h; c.scale = 1; c.rotation = 0; c.radius = 0; c.fit = 'cover'; }
    if (act === 'pip') { const m = getMedia(c.mediaId); const ar = m ? m.w / m.h : 16 / 9; c.w = P.w * 0.36; c.h = c.w / ar; c.scale = 1; c.x = P.w - c.w / 2 - P.w * 0.04; c.y = P.h - c.h / 2 - P.h * 0.05; c.radius = 24; c.fit = 'cover'; }
    if (act === 'reset-color') { c.filter = 'none'; c.adj = { brightness: 0, contrast: 0, saturation: 0, hue: 0, temp: 0, vignette: 0, blur: 0 }; }
    dirty = true; renderInspector();
  });
}

// ---------- Export ----------
function pickMime() {
  const list = ['video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4;codecs=avc1', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4'];
  return window.MediaRecorder ? list.find((m) => MediaRecorder.isTypeSupported(m)) : null;
}
export function openExport() {
  pause();
  const P = project();
  const mime = pickMime();
  const ext = mime?.includes('mp4') ? 'MP4' : 'WebM';
  const still = P.clips.every((c) => c.kind !== 'video' && c.kind !== 'audio') && ['yt-thumb', 'fb-cover', 'yt-banner'].includes(P.formatId);
  modal(`<h3>Export</h3><p class="muted">${esc(P.name)} · ${P.w}×${P.h} · ${fmtTime(duration(), false)}</p>
    <div class="export-opts">
      <label class="opt"><input type="radio" name="ex" value="video" ${!still ? 'checked' : ''} ${mime ? '' : 'disabled'}><div><b>Video (${ext})</b><small>${mime ? 'Records in real time with audio — keep this tab open.' : 'Video recording is not supported in this browser.'}</small></div></label>
      <label class="opt"><input type="radio" name="ex" value="png" ${still || !mime ? 'checked' : ''}><div><b>Image (PNG)</b><small>Current frame at ${fmtTime(T)} — ideal for thumbnails, covers and posts.</small></div></label>
    </div>
    <label class="field"><span>Resolution</span><select id="ex-res"><option value="1">Full — ${P.w}×${P.h}</option><option value="0.6667">Medium — ${Math.round(P.w * 0.6667)}×${Math.round(P.h * 0.6667)}</option><option value="0.5">Small — ${Math.round(P.w / 2)}×${Math.round(P.h / 2)}</option></select></label>
    <div class="modal-actions"><button class="btn" data-close>Cancel</button><button class="btn btn-primary" id="ex-go">${icon('download')}<span>Export</span></button></div>`);
  icons();
  $('#ex-go').onclick = () => {
    const type = document.querySelector('input[name=ex]:checked').value;
    const r = parseFloat($('#ex-res').value);
    if (type === 'png') exportPNG(r); else startExport(r, mime);
  };
}
function exportPNG(r) {
  const P = project();
  const c = document.createElement('canvas'); c.width = Math.round(P.w * r); c.height = Math.round(P.h * r);
  renderFrame(c.getContext('2d'), P, T, { k: c.width / P.w, getSource });
  c.toBlob((b) => { download(b, slug(P.name) + '.png'); closeModal(); toast('PNG exported'); }, 'image/png');
}
const slug = (s) => (s || 'reelsmith').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'reelsmith';
function startExport(r, mime) {
  ensureAudio();
  const P = project();
  const c = document.createElement('canvas'); c.width = Math.round(P.w * r / 2) * 2; c.height = Math.round(P.h * r / 2) * 2;
  const ctx = c.getContext('2d');
  const stream = c.captureStream(30);
  if (exportDest) exportDest.stream.getAudioTracks().forEach((t) => stream.addTrack(t));
  const chunks = [];
  const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: Math.round(12e6 * r * r) });
  rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
  exporting = { ctx, k: c.width / P.w, rec, chunks, mime, cancelled: false };
  rec.onstop = () => {
    const ex = exporting; exporting = null;
    seek(0);
    if (ex.cancelled) return;
    const blob = new Blob(ex.chunks, { type: mime.split(';')[0] });
    const name = slug(P.name) + (mime.includes('mp4') ? '.mp4' : '.webm');
    download(blob, name);
    $('#modal-root .modal').innerHTML = `<h3>Export complete</h3><p>${esc(name)} · ${(blob.size / 1048576).toFixed(1)} MB</p><p class="muted">If the download didn't start, use the button below.</p><div class="modal-actions"><a class="btn" href="${URL.createObjectURL(blob)}" download="${name}" target="_blank">Download again</a><button class="btn btn-primary" data-close>Done</button></div>`;
  };
  $('#modal-root .modal').innerHTML = `<h3>Exporting…</h3><p class="muted">Rendering in real time. Keep this tab visible.</p><div class="progress"><i id="ex-bar"></i></div><p id="ex-pct" class="mono">0%</p><div class="modal-actions"><button class="btn" id="ex-cancel">Cancel</button></div>`;
  $('#ex-cancel').onclick = () => { if (exporting) { exporting.cancelled = true; exporting.rec.stop(); } pause(); closeModal(); toast('Export cancelled'); };
  select(null);
  T = 0; renderFrame(ctx, P, 0, { k: exporting.k, getSource });
  rec.start(250);
  setTimeout(() => play(), 150);
  const tick = () => { if (!exporting) return; const p = Math.min(100, (T / duration()) * 100); const b = $('#ex-bar'); if (b) { b.style.width = p + '%'; $('#ex-pct').textContent = Math.round(p) + '%'; } requestAnimationFrame(tick); };
  tick();
}
function finishExport() {
  pause();
  if (exporting && exporting.rec.state === 'recording') setTimeout(() => exporting?.rec.stop(), 200);
}

// ---------- portable editable project files ----------
function blobAsDataURL(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = () => reject(r.error || new Error('Could not read media')); r.readAsDataURL(blob);
  });
}
function dataURLToBlob(dataURL) {
  const [head, body] = dataURL.split(',');
  const mime = head.match(/data:([^;]+)/)?.[1] || 'application/octet-stream';
  const raw = atob(body), bytes = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}
async function saveEditableProject() {
  const P = project(); if (!P) return toast('Open a project first');
  const ids = [...new Set(P.clips.map(c => c.mediaId).filter(Boolean))];
  const media = [];
  try {
    for (const id of ids) {
      const m = getMedia(id); if (!m) continue;
      const res = await fetch(m.url); if (!res.ok) throw new Error(`Could not read ${m.name}`);
      const blob = await res.blob();
      media.push({ id: m.id, name: m.name, type: m.type, mime: blob.type || (m.type === 'video' ? 'video/mp4' : m.type === 'audio' ? 'audio/mpeg' : 'image/png'), data: await blobAsDataURL(blob) });
    }
    const payload = { format: 'reelsmith-project', version: 1, savedAt: new Date().toISOString(), project: P, media };
    const safe = (P.name || 'reelsmith-project').replace(/[^a-z0-9_-]+/gi, '-').replace(/^-|-$/g, '') || 'reelsmith-project';
    download(new Blob([JSON.stringify(payload)], { type: 'application/json' }), `${safe}.reelsmith.json`);
    toast('Editable project saved with its media');
  } catch (err) {
    console.error(err); toast('Could not package project media. Try smaller files or re-import the missing media.');
  }
}
async function loadEditableProject(file) {
  try {
    const payload = JSON.parse(await file.text());
    if (payload.format !== 'reelsmith-project' || !payload.project || !Array.isArray(payload.media)) throw new Error('This is not a Reelsmith project file');
    const mapping = new Map();
    for (const item of payload.media) {
      const blob = dataURLToBlob(item.data);
      const f = new File([blob], item.name || 'media', { type: item.mime || blob.type || 'application/octet-stream' });
      const added = await importFiles([f]);
      if (!added.length) throw new Error(`Could not restore ${item.name || 'media'}`);
      const m = added[0];
      library.splice(library.indexOf(m), 1);
      const old = library.findIndex(x => x.id === item.id); if (old >= 0) library.splice(old, 1);
      m.id = item.id; m.name = item.name || m.name; library.push(m); mapping.set(item.id, m.id);
    }
    const P = JSON.parse(JSON.stringify(payload.project));
    P.clips.forEach(c => { if (c.mediaId && mapping.has(c.mediaId)) c.mediaId = mapping.get(c.mediaId); });
    openProject(P); toast('Project opened successfully');
  } catch (err) {
    console.error(err); toast(`Could not open project: ${err.message || 'invalid file'}`);
  }
}

// ---------- open / init ----------
export function openProject(P) {
  pause();
  store.project = P; store.history = []; store.future = []; store.selectedId = null;
  T = 0;
  $('#proj-name').value = P.name;
  document.querySelectorAll('.view').forEach((v) => (v.hidden = v.id !== 'view-editor'));
  showPanel('media');
  emit('project', { reason: 'load' });
  select(null);
}

export function initEditor() {
  hiddenBox = document.createElement('div');
  hiddenBox.style.cssText = 'position:fixed;width:1px;height:1px;overflow:hidden;opacity:0;pointer-events:none;left:-10px;top:-10px';
  document.body.appendChild(hiddenBox);
  setupStage(); setupPanels(); setupInspector();
  TL.init({ getT, seek, requestDraw, addMedia, findTrack, addTrack, overlaps });
  on('project', () => { gcEls(); TL.render(); renderInspector(); dirty = true; });
  on('select', () => { renderInspector(); TL.render(); dirty = true; if (currentPanel === 'effects') showPanel('effects'); });
  on('library', () => { if (!$('#view-editor').hidden && (currentPanel === 'media' || currentPanel === 'audio')) showPanel(currentPanel); });
  $('#btn-play').onclick = toggle;
  $('#btn-start').onclick = () => seek(0);
  $('#btn-end').onclick = () => seek(duration());
  $('#btn-prev').onclick = () => seek(T - 1 / 30);
  $('#btn-next').onclick = () => seek(T + 1 / 30);
  $('#btn-undo').onclick = undo; $('#btn-redo').onclick = redo;
  $('#btn-export').onclick = openExport;
  $('#btn-save-project').onclick = saveEditableProject;
  $('#btn-open-project').onclick = () => $('#project-file-in').click();
  $('#project-file-in').addEventListener('change', async (e) => { const f = e.target.files?.[0]; if (f) await loadEditableProject(f); e.target.value = ''; });
  $('#proj-name').addEventListener('input', (e) => { project().name = e.target.value; });
  document.addEventListener('keydown', (e) => {
    if ($('#view-editor').hidden || !store.project) return;
    if (e.target.closest('input, textarea, select, [contenteditable]')) return;
    if ($('#modal-root').childElementCount) return;
    const mod = e.ctrlKey || e.metaKey;
    if (e.code === 'Space') { e.preventDefault(); toggle(); }
    else if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); }
    else if (mod && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); }
    else if (mod && e.key.toLowerCase() === 'd') { e.preventDefault(); duplicateSelected(); }
    else if (mod && e.key.toLowerCase() === 'x') { e.preventDefault(); copySelected(true); }
    else if (mod && e.key.toLowerCase() === 'c') { e.preventDefault(); copySelected(false); }
    else if (mod && e.key.toLowerCase() === 'v') { e.preventDefault(); paste(); }
    else if (e.key.toLowerCase() === 'b' && !mod) { e.preventDefault(); TL.setBlade(!TL.isBlade()); }
    else if (e.key.toLowerCase() === 'q' && !mod) { e.preventDefault(); trimToPlayhead('left'); }
    else if (e.key.toLowerCase() === 'w' && !mod) { e.preventDefault(); trimToPlayhead('right'); }
    else if (e.key.toLowerCase() === 's' && e.shiftKey && !mod) { e.preventDefault(); splitAll(); }
    else if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); deleteSelected(e.shiftKey); }
    else if (e.key.toLowerCase() === 's' && !mod && !e.shiftKey) { e.preventDefault(); splitAt(); }
    else if (e.key.toLowerCase() === 'f' && !mod) { e.preventDefault(); freezeFrame(); }
    else if (e.key.toLowerCase() === 'k' && !mod) { e.preventDefault(); addKeyframe(); }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); seek(T - (e.shiftKey ? 1 : 1 / 30)); }
    else if (e.key === 'ArrowRight') { e.preventDefault(); seek(T + (e.shiftKey ? 1 : 1 / 30)); }
    else if (e.key === 'Home') seek(0);
    else if (e.key === 'End') seek(duration());
    else if (e.key === '+' || e.key === '=') TL.zoom(1.25);
    else if (e.key === '-') TL.zoom(0.8);
    else if (e.key === 'Escape') { if (TL.isBlade()) TL.setBlade(false); else select(null); }
  });
  requestAnimationFrame(loop);
}

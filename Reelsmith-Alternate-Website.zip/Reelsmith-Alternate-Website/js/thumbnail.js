// Thumbnail maker: templates, photo background + cutout, draggable text and stickers
import { FORMATS, newProject, defaultClip, clamp } from './state.js';
import { library, getMedia, importFiles, addDataImage } from './media.js';
import { icon, icons, esc, toast, download } from './ui.js';

const $ = (s, r = document) => r.querySelector(s);

const SIZES = [
  { id: 'yt', label: 'YouTube 1280×720', w: 1280, h: 720, fmt: 'yt-thumb' },
  { id: 'fb', label: 'Facebook link 1200×630', w: 1200, h: 630 },
  { id: 'ig', label: 'Instagram portrait 1080×1350', w: 1080, h: 1350, fmt: 'ig-portrait' },
  { id: 'sq', label: 'Square 1080×1080', w: 1080, h: 1080, fmt: 'ig-post' },
];
const GRADS = [['#ff2d55', '#5a0020'], ['#2d6bff', '#00c2a8'], ['#ffb000', '#d6247a'], ['#1b1b22', '#4a4a58'], ['#f6f1e7', '#d9d2c3'], ['#7a2dff', '#ff5ca8'], ['#0f9d58', '#0b3d2e'], ['#ff5a36', '#ffcf6a']];
const FONTS = ['Anton', 'Bebas Neue', 'Archivo Black', 'Montserrat', 'Oswald', 'Poppins', 'Permanent Marker', 'Pacifico', 'Playfair Display', 'Space Grotesk'];
const STICKERS = ['😱', '🔥', '👀', '💰', '✅', '❌', '👇', '⭐', '🚀', '😂', '💯', '❤️'];

// [name, headline, subline, emoji, sample photo (optional)]
const TOPICS = [
  ['Vlog', 'MY WEEK IN|TOKYO', 'Day in my life', '🎬', 'creator'], ['Tutorial', 'HOW TO|EDIT FASTER', 'Step by step', '📚', ''],
  ['Reaction', 'WAIT FOR|IT…', 'you will not believe this', '😱', 'concert'], ['Promo', 'SPECIAL|OFFER', 'Tap to learn more', '🔥', 'product'],
  ['Big sale', '50% OFF', 'Today only', '💰', 'product'], ['Travel', 'LOST IN|THE ALPS', 'Travel diary', '✈️', 'travel'],
  ['Food', 'BEST STREET|FOOD EVER', 'Recipe inside', '🍜', 'food'], ['Fitness', '30 DAY|CHALLENGE', 'No excuses', '💪', 'fitness'],
  ['Gaming', 'EPIC WIN', 'Clutch moment', '🎮', ''], ['Podcast', 'EPISODE 24', 'Listen now', '🎙️', ''],
  ['Review', 'HONEST|REVIEW', 'Is it worth it?', '⭐', 'product'], ['Birthday', 'HAPPY|BIRTHDAY', 'Make a wish', '🎂', ''],
  ['Quote', 'KEEP|GOING', 'Daily motivation', '💡', ''], ['News', 'BREAKING', 'What you need to know', '📰', ''],
  ['Unboxing', 'UNBOXING', 'First look', '📦', 'product'], ['Recipe', '5 MIN|DINNER', 'Easy and fast', '🍳', 'coffee'],
];

const L = (t, x, y, sz, c, o = {}) => ({ t, x, y, sz, c, font: 'Anton', stroke: true, box: false, sticker: false, ...o });
function fromTopic(i, v) {
  const [, head, sub, em, photo] = TOPICS[i];
  const gi = (i + v * 3) % GRADS.length, light = gi === 4, ink = light ? '#1b1b22' : '#ffffff', hot = light ? '#c2185b' : '#ffe14d';
  const x = v ? 0.5 : 0.3;
  return {
    size: 'yt', grad: gi, bg: v === 0 && photo ? 'sample_' + photo : null, cut: null, cutScale: 0.85, cutSide: 'right', dim: 0.4,
    layers: [
      L(head, x, 0.4, v ? 0.17 : 0.19, hot, { stroke: !light }),
      L(sub, x, 0.84, 0.07, ink, { font: 'Bebas Neue', stroke: !light, box: false }),
      L(em, v ? 0.85 : 0.82, 0.24, 0.22, '#ffffff', { sticker: true, stroke: false }),
    ],
  };
}
const TEMPLATES = TOPICS.flatMap((t, i) => [{ id: `t${i}a`, name: t[0], build: () => fromTopic(i, 0) }, { id: `t${i}b`, name: t[0] + ' · centered', build: () => fromTopic(i, 1) }]);

const S = { ...fromTopic(0, 0), sel: 0 };
const size = (st = S) => SIZES.find((z) => z.id === st.size) || SIZES[0];

function cover(ctx, im, x, y, w, h) {
  const iw = im.naturalWidth || im.width, ih = im.naturalHeight || im.height, r = Math.max(w / iw, h / ih), dw = iw * r, dh = ih * r;
  ctx.drawImage(im, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
}

// Draws one text layer, returns its bounding box
function drawLayer(ctx, l, W, H) {
  const lines = l.t.split('|'), x = l.x * W, y = l.y * H;
  let px = l.sz * H;
  const fam = l.sticker ? '"Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif' : `"${l.font}",Impact,sans-serif`;
  const f = (p) => `${l.sticker ? 400 : 700} ${p}px ${fam}`;
  ctx.font = f(px);
  let mw = Math.max(...lines.map((s) => ctx.measureText(s).width), 1);
  if (mw > W * 0.95) { px *= (W * 0.95) / mw; ctx.font = f(px); mw = W * 0.95; }
  const lh = px * (l.sticker ? 1.1 : 1.05), y0 = y - ((lines.length - 1) * lh) / 2;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
  lines.forEach((s, i) => {
    const yy = y0 + i * lh, w = ctx.measureText(s).width;
    if (l.box) { ctx.fillStyle = 'rgba(0,0,0,0.72)'; ctx.fillRect(x - w / 2 - px * 0.3, yy - lh / 2, w + px * 0.6, lh); }
    if (!l.sticker) { ctx.shadowColor = 'rgba(0,0,0,0.45)'; ctx.shadowBlur = px * 0.18; ctx.shadowOffsetY = px * 0.05; }
    if (l.stroke && !l.sticker) { ctx.lineWidth = px / 5; ctx.strokeStyle = '#000'; ctx.strokeText(s, x, yy); }
    ctx.fillStyle = l.c; ctx.fillText(s, x, yy);
    ctx.shadowColor = 'transparent'; ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;
  });
  return [x - mw / 2, y0 - lh / 2, x + mw / 2, y0 + lines.length * lh - lh / 2];
}

export function drawThumb(ctx, W, H, st, preview) {
  const g = ctx.createLinearGradient(0, 0, W, H);
  const gr = GRADS[st.grad] || GRADS[0];
  g.addColorStop(0, gr[0]); g.addColorStop(1, gr[1]);
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  const bg = st.bg && getMedia(st.bg);
  if (bg?.el) {
    cover(ctx, bg.el, 0, 0, W, H);
    ctx.fillStyle = `rgba(0,0,0,${st.dim})`; ctx.fillRect(0, 0, W, H);
    ctx.globalAlpha = 0.22; ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1;
  }
  const cut = st.cut && getMedia(st.cut);
  if (cut?.el) {
    const ch = H * st.cutScale, cw = ch * cut.w / cut.h, cx = st.cutSide === 'left' ? W * 0.03 : W - cw - W * 0.03;
    ctx.save(); ctx.shadowColor = 'rgba(0,0,0,0.5)'; ctx.shadowBlur = 30 * (W / 1280);
    ctx.drawImage(cut.el, cx, H - ch, cw, ch); ctx.restore();
  }
  st.layers.forEach((l) => { l.bb = drawLayer(ctx, l, W, H); });
  if (preview && st.layers[S.sel]?.bb) {
    const b = st.layers[S.sel].bb, k = W / 1280;
    ctx.save(); ctx.setLineDash([10 * k, 8 * k]); ctx.strokeStyle = '#fff'; ctx.lineWidth = 3 * k;
    ctx.strokeRect(b[0] - 8 * k, b[1] - 4 * k, b[2] - b[0] + 16 * k, b[3] - b[1] + 8 * k); ctx.restore();
  }
}

let ds = 1;
function redraw() {
  const cv = $('#th-canvas'), stg = $('#th-stage'); if (!cv || !stg.clientWidth) return;
  const Z = size(); ds = Math.max(0.05, Math.min((stg.clientWidth - 32) / Z.w, (stg.clientHeight - 32) / Z.h));
  const dpr = Math.min(2, devicePixelRatio || 1), cw = Math.round(Z.w * ds), ch = Math.round(Z.h * ds);
  cv.style.width = cw + 'px'; cv.style.height = ch + 'px';
  cv.width = Math.min(Z.w, Math.round(cw * dpr)); cv.height = Math.round(cv.width * Z.h / Z.w);
  const k = cv.width / Z.w, ctx = cv.getContext('2d');
  ctx.setTransform(k, 0, 0, k, 0, 0);
  drawThumb(ctx, Z.w, Z.h, S, true);
}

function renderOut(W, H) { const c = document.createElement('canvas'); c.width = W; c.height = H; drawThumb(c.getContext('2d'), W, H, S, false); return c; }

const rng = (label, k, v, min, max, step = 1) => `<label class="field"><span>${label}</span><div class="range"><input type="range" data-tk="${k}" min="${min}" max="${max}" step="${step}" value="${v}"><input type="number" data-tk="${k}" min="${min}" max="${max}" step="${step}" value="${v}"></div></label>`;
const photos = () => library.filter((m) => m.type === 'image');

function leftHTML() {
  return `<div class="panel-head"><h3>Templates</h3><span class="muted" style="font-size:11px">${TEMPLATES.length} designs</span></div>
  <p class="hint">Tap a design, then change the words, photo and colours on the right.</p>
  <div class="th-grid">${TEMPLATES.map((t) => `<button class="th-card" data-tt="${t.id}" title="${esc(t.name)}"><canvas data-ttc="${t.id}" width="240" height="135"></canvas><span>${esc(t.name)}</span></button>`).join('')}</div>`;
}
function drawCards() {
  document.querySelectorAll('#th-left canvas[data-ttc]').forEach((cv) => {
    const t = TEMPLATES.find((x) => x.id === cv.dataset.ttc), st = t.build(), Z = size(st), k = cv.width / Z.w;
    cv.height = Math.round(cv.width * Z.h / Z.w);
    const ctx = cv.getContext('2d'); ctx.setTransform(k, 0, 0, k, 0, 0); drawThumb(ctx, Z.w, Z.h, st, false);
  });
}
function rightHTML() {
  const l = S.layers[S.sel], ps = photos();
  const pick = (key, cur) => `<div class="th-photos">${ps.map((m) => `<button class="th-ph ${cur === m.id ? 'on' : ''}" data-${key}="${m.id}" title="${esc(m.name)}"><img src="${m.thumb}" alt="${esc(m.name)}"></button>`).join('')}</div>`;
  return `<div class="insp-head"><h3>Thumbnail</h3></div><div class="insp-body">
  <h4 class="sub">Size</h4><div class="chips">${SIZES.map((z) => `<button class="chip ${S.size === z.id ? 'on' : ''}" data-tsize="${z.id}">${z.label}</button>`).join('')}</div>
  <h4 class="sub">Background</h4>
  <div class="bg-grid small">${GRADS.map((g, i) => `<button class="bg-sw ${S.grad === i && !S.bg ? 'on' : ''}" data-grad="${i}" style="background:linear-gradient(135deg,${g[0]},${g[1]})" aria-label="Gradient ${i + 1}"></button>`).join('')}</div>
  <div class="btn-row"><label class="btn btn-sm">${icon('upload')}<span>Import photos</span><input type="file" id="th-file" accept="image/*" multiple></label>${S.bg ? '<button class="btn btn-sm" data-act="nobg">Remove photo</button>' : ''}</div>
  ${pick('bgm', S.bg)}${S.bg ? rng('Darken photo', 'dim', Math.round(S.dim * 100), 0, 80) : ''}
  <h4 class="sub">Cutout photo</h4><p class="hint">Pick a photo to place at the bottom corner. Use a PNG with a transparent background for a clean cutout.</p>
  ${pick('cutm', S.cut)}
  ${S.cut ? `${rng('Cutout size', 'cutScale', Math.round(S.cutScale * 100), 30, 100)}<div class="btn-row"><button class="btn btn-sm ${S.cutSide === 'left' ? 'btn-primary' : ''}" data-side="left">Left</button><button class="btn btn-sm ${S.cutSide === 'right' ? 'btn-primary' : ''}" data-side="right">Right</button><button class="btn btn-sm" data-act="nocut">Remove</button></div>` : ''}
  <h4 class="sub">Text and stickers</h4>
  <div class="btn-row"><button class="btn btn-sm btn-primary" data-act="addtext">${icon('type')}<span>Add text</span></button><button class="btn btn-sm" data-act="dup">Duplicate</button><button class="btn btn-sm" data-act="front">Bring to front</button><button class="btn btn-sm" data-act="del">Delete</button></div>
  <div class="chips">${STICKERS.map((s) => `<button class="chip" data-stk="${s}" aria-label="Add ${s}">${s}</button>`).join('')}</div>
  ${l ? `<h4 class="sub">Selected layer</h4>
  <label class="field"><span>Text (use | for a new line)</span><input type="text" id="th-text" value="${esc(l.t)}"></label>
  ${l.sticker ? '' : `<label class="field"><span>Font</span><select id="th-font">${FONTS.map((f) => `<option ${f === l.font ? 'selected' : ''}>${f}</option>`).join('')}</select></label>`}
  ${rng('Size', 'sz', Math.round(l.sz * 1000) / 10, 3, 60, 0.5)}
  ${l.sticker ? '' : `<div class="grid2"><label class="field field-inline"><span>Color</span><input type="color" id="th-color" value="${l.c}"></label><div><label class="toggle"><input type="checkbox" id="th-stroke" ${l.stroke ? 'checked' : ''}><span>Outline</span></label><label class="toggle"><input type="checkbox" id="th-box" ${l.box ? 'checked' : ''}><span>Dark box</span></label></div></div>`}` : '<p class="hint">Tap text on the thumbnail to edit it, and drag to move it.</p>'}
  </div>`;
}
function renderPanels(cards = false) {
  if (cards) { $('#th-left').innerHTML = leftHTML(); drawCards(); }
  $('#th-right').innerHTML = rightHTML(); icons();
}

function loadTemplate(t) { const keepSel = 0; Object.assign(S, t.build(), { sel: keepSel }); renderPanels(); redraw(); }
const layer = () => S.layers[S.sel];

export function openThumbnail(opts = {}) {
  if (opts.bg) S.bg = opts.bg;
  if (opts.cut) S.cut = opts.cut;
  document.querySelectorAll('.view').forEach((v) => (v.hidden = v.id !== 'view-thumb'));
  renderPanels(false);
  requestAnimationFrame(redraw);
}

export function initThumbnail() {
  const left = $('#th-left'), right = $('#th-right'), stage = $('#th-stage'), cv = $('#th-canvas');
  new ResizeObserver(redraw).observe(stage);
  left.addEventListener('click', (e) => { const c = e.target.closest('[data-tt]'); if (c) loadTemplate(TEMPLATES.find((t) => t.id === c.dataset.tt)); });
  right.addEventListener('click', (e) => {
    const t = e.target, q = (s) => t.closest(s);
    let redo = true;
    if (q('[data-tsize]')) S.size = q('[data-tsize]').dataset.tsize;
    else if (q('[data-grad]')) { S.grad = +q('[data-grad]').dataset.grad; S.bg = null; }
    else if (q('[data-bgm]')) S.bg = q('[data-bgm]').dataset.bgm;
    else if (q('[data-cutm]')) S.cut = q('[data-cutm]').dataset.cutm;
    else if (q('[data-side]')) S.cutSide = q('[data-side]').dataset.side;
    else if (q('[data-stk]')) { S.layers.push(L(q('[data-stk]').dataset.stk, 0.7, 0.3, 0.28, '#ffffff', { sticker: true, stroke: false })); S.sel = S.layers.length - 1; }
    else if (q('[data-act]')) {
      const a = q('[data-act]').dataset.act;
      if (a === 'nobg') S.bg = null;
      else if (a === 'nocut') S.cut = null;
      else if (a === 'addtext') { S.layers.push(L('NEW TEXT', 0.5, 0.5, 0.12, '#ffffff')); S.sel = S.layers.length - 1; }
      else if (a === 'dup' && layer()) { S.layers.push({ ...layer(), x: Math.min(0.9, layer().x + 0.04), y: Math.min(0.9, layer().y + 0.04) }); S.sel = S.layers.length - 1; }
      else if (a === 'front' && layer()) { const [l] = S.layers.splice(S.sel, 1); S.layers.push(l); S.sel = S.layers.length - 1; }
      else if (a === 'del' && layer()) { S.layers.splice(S.sel, 1); S.sel = Math.max(0, S.sel - 1); }
    } else redo = false;
    if (redo) { renderPanels(); redraw(); }
  });
  right.addEventListener('input', (e) => {
    const t = e.target, k = t.dataset.tk, l = layer();
    if (k) {
      const v = parseFloat(t.value); if (isNaN(v)) return;
      if (k === 'sz' && l) l.sz = v / 100; else if (k === 'dim') S.dim = v / 100; else if (k === 'cutScale') S.cutScale = v / 100;
      right.querySelectorAll(`[data-tk="${k}"]`).forEach((o) => o !== t && (o.value = v));
    }
    if (t.id === 'th-text' && l) l.t = t.value;
    if (t.id === 'th-color' && l) l.c = t.value;
    redraw();
  });
  right.addEventListener('change', async (e) => {
    const t = e.target, l = layer();
    if (t.id === 'th-file') { const a = await importFiles([...t.files].filter((f) => f.type.startsWith('image/'))); if (a[0]) S.bg = a[0].id; toast(`Added ${a.length} photo${a.length === 1 ? '' : 's'}`); renderPanels(); redraw(); return; }
    if (t.id === 'th-font' && l) l.font = t.value;
    if (t.id === 'th-stroke' && l) l.stroke = t.checked;
    if (t.id === 'th-box' && l) l.box = t.checked;
    redraw();
  });
  // drag layers on the canvas
  let drag = null;
  const pt = (e) => { const r = cv.getBoundingClientRect(), Z = size(); return [(e.clientX - r.left) / ds, (e.clientY - r.top) / ds, Z]; };
  cv.addEventListener('pointerdown', (e) => {
    const [x, y, Z] = pt(e);
    for (let i = S.layers.length - 1; i >= 0; i--) {
      const b = S.layers[i].bb;
      if (b && x >= b[0] && x <= b[2] && y >= b[1] && y <= b[3]) {
        S.sel = i; drag = { dx: x - S.layers[i].x * Z.w, dy: y - S.layers[i].y * Z.h }; cv.setPointerCapture(e.pointerId);
        renderPanels(); redraw(); return;
      }
    }
  });
  cv.addEventListener('pointermove', (e) => { if (!drag) return; const [x, y, Z] = pt(e), l = layer(); l.x = clamp((x - drag.dx) / Z.w, 0, 1); l.y = clamp((y - drag.dy) / Z.h, 0, 1); redraw(); });
  const end = () => (drag = null);
  cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
  cv.addEventListener('wheel', (e) => { const l = layer(); if (!l) return; e.preventDefault(); l.sz = clamp(l.sz * (e.deltaY < 0 ? 1.05 : 0.95), 0.03, 0.6); redraw(); }, { passive: false });
  document.addEventListener('keydown', (e) => {
    if ($('#view-thumb').hidden || /INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) return;
    if ((e.key === 'Delete' || e.key === 'Backspace') && layer()) { e.preventDefault(); S.layers.splice(S.sel, 1); S.sel = Math.max(0, S.sel - 1); renderPanels(); redraw(); }
  });
  $('#th-export').onclick = () => { const Z = size(); renderOut(Z.w, Z.h).toBlob((b) => { download(b, `thumbnail-${Z.w}x${Z.h}.png`); toast('Thumbnail exported as PNG'); }, 'image/png'); };
  $('#th-export-jpg').onclick = () => { const Z = size(); renderOut(Z.w, Z.h).toBlob((b) => { download(b, `thumbnail-${Z.w}x${Z.h}.jpg`); toast('Thumbnail exported as JPG'); }, 'image/jpeg', 0.92); };
  $('#th-to-editor').onclick = async () => {
    const Z = size(), fmt = FORMATS.find((f) => f.id === Z.fmt) || { id: 'custom', platform: 'Custom', name: Z.label, w: Z.w, h: Z.h };
    const m = await addDataImage(renderOut(Z.w, Z.h).toDataURL('image/jpeg', 0.92), 'Thumbnail');
    const P = newProject(fmt, 'Thumbnail video'), v1 = P.tracks.find((t) => t.name === 'V1');
    P.clips.push(defaultClip({ trackId: v1.id, kind: 'image', mediaId: m.id, x: Z.w / 2, y: Z.h / 2, w: Z.w, h: Z.h, dur: 5, combo: 'ken-burns', animIn: { type: 'fade', dur: 0.6 } }));
    const { openProject } = await import('./editor.js'); openProject(P); toast('Thumbnail added to a new video project');
  };
  loadTemplate(TEMPLATES[0]); renderPanels(true);
}
